// YHOD on Vercel — the serverless entry point.
//
// Vercel does not run "node server.js": there is no long-lived process and no port to listen on. Instead it
// calls one function for each request. This file is that function. vercel.json sends every address to it
// (pages, their files and /api/…), and it hands the request to the same handler that server.js uses when it
// runs as a server of its own — so the two ways of running YHOD cannot drift apart.
//
// What is different on Vercel is decided in src/config.js (it looks at the VERCEL environment variable):
//   • the code folder is read-only, so anything written goes to /tmp or to the database;
//   • saved data needs a database that outlives the function (TURSO_DATABASE_URL + TURSO_AUTH_TOKEN);
//   • the Gemini API key comes from the project's Environment Variables (GEMINI_API_KEY) and stays on the server.
import { yhod } from '../server.js';

export default function handler(req, res) {
  return yhod(req, res);
}
