// YHOD — talks to the YHOD server. The Gemini API key lives only on the server;
// the browser never sees it and never calls Google directly.

export class ApiError extends Error {
  constructor(message, status, info = {}, data = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = info.code || 'ERROR';
    this.info = info; // { code, message, detail, attempts, retryAfterSec, fields … }
    this.data = data; // the whole response body (may carry safety information alongside the error)
  }
}

const EMBEDDED = (() => { try { return window.self !== window.top; } catch { return true; } })();
// The fingerprint of the site's files this page was built from: it is part of this very file's address,
// /a/<fingerprint>/js/api.js. "plain" means the file was reached through an address without a fingerprint.
export const build = (/\/a\/([A-Za-z0-9]{8,24})\//.exec(import.meta.url) || [])[1] || 'plain';
const TOKEN_KEY = 'yhod.session';
// The sign-in for this tab, used only where the session cookie cannot do the job (see adoptSession below).
let tabToken = null;
try { tabToken = sessionStorage.getItem(TOKEN_KEY); } catch { tabToken = null; }
function setTabToken(token) {
  tabToken = token || null;
  try { if (tabToken) sessionStorage.setItem(TOKEN_KEY, tabToken); else sessionStorage.removeItem(TOKEN_KEY); } catch { /* storage is blocked: the sign-in then lasts until this page is reloaded */ }
}

// YHOD never closes by itself. If the server answers "not signed in" while someone is using YHOD, the app asks
// for the password in place (app.js installs that question here) and the refused request is then sent again,
// so nothing is lost and nothing has to be done twice.
let askAgain = null;   // () => Promise<boolean>: true once the person is signed in again
let asking = null;     // one question, shared by all the requests that were refused at the same moment
export function whenSignedOut(ask) { askAgain = ask; }

function headers(json, useToken = true) {
  const h = { 'X-YHOD': '1', 'X-YHOD-Proto': location.protocol.replace(':', ''), 'X-YHOD-Build': build };
  if (EMBEDDED) h['X-YHOD-Embedded'] = '1';
  if (json) h['Content-Type'] = 'application/json';
  // YHOD's own header, not "Authorization". Behind a hosted live preview, neither the session cookie nor an
  // Authorization header got through to the server (seen 2026-11-14: every request after a successful sign-up
  // was answered "not signed in"), while the app's own "X-YHOD" header did arrive.
  if (tabToken && useToken) h['X-YHOD-Tab'] = tabToken;
  return h;
}

async function request(method, path, body, opts = {}) {
  const { timeout = 75000, raw = false, useToken = true, again = true } = opts;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: headers(method !== 'GET', useToken),
      body: method === 'GET' ? undefined : JSON.stringify(body ?? {}),
      credentials: 'same-origin',
      cache: 'no-store',
      signal: ctrl.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new ApiError('The server took too long to answer. Your information is safe — please try again.', 0, { code: 'CLIENT_TIMEOUT' });
    throw new ApiError('YHOD could not reach its server. Check your internet connection and try again.', 0, { code: 'NETWORK' });
  }
  clearTimeout(timer);
  if (res.ok && raw) return res;
  let data = null;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) {
    const info = data?.error || {};
    if (res.status === 401 && info.code === 'NOT_SIGNED_IN' && askAgain && again) {
      // The server did nothing with this request. Ask once, then send the very same request again.
      asking ||= Promise.resolve().then(askAgain).catch(() => false).finally(() => { asking = null; });
      if (await asking) return request(method, path, body, { ...opts, again: false });
      // The question was closed without an answer. YHOD stays open; this one action could not be carried out.
      throw new ApiError('YHOD needs your password before it can do this. Please try again and enter it when you are asked.', res.status, info, data || {});
    }
    throw new ApiError(info.message || `The server answered with an error (${res.status}).`, res.status, info, data || {});
  }
  return data;
}

export const api = {
  get: (path, opts) => request('GET', path, undefined, opts),
  post: (path, body, opts) => request('POST', path, body, opts),
  put: (path, body, opts) => request('PUT', path, body, opts),
  patch: (path, body, opts) => request('PATCH', path, body, opts),
  del: (path, opts) => request('DELETE', path, {}, opts),
  /** binary GET → { blob, headers } */
  async blob(path) {
    const res = await request('GET', path, undefined, { raw: true });
    return { blob: await res.blob(), headers: res.headers };
  },
  embedded: EMBEDDED,
};

/**
 * Keep the sign-in that the server has just created (its answer carries the session token).
 *  1. The server also set an httpOnly session cookie. If that cookie comes back by itself, only the cookie is
 *     used, and no script can ever read the session.
 *  2. Otherwise the token is kept for this tab only and sent in YHOD's own header. That is the case when a
 *     browser blocks cookies for a site shown inside another site's frame, and when a gateway in front of the
 *     server does not let Cookie and Authorization headers through (observed with a hosted live preview).
 *  3. If neither way reaches the server, say so here, on the sign-in card. YHOD is only ever opened with a
 *     sign-in that is known to work.
 * Returns 'cookie' or 'header'. A network failure while checking is passed on as it is.
 */
export async function adoptSession(token) {
  setTabToken(null);
  const signedInAs = async (useToken) => (await request('GET', '/api/auth/me', undefined, { useToken, timeout: 25000 })).user || null;
  if (await signedInAs(false)) return 'cookie';
  if (token) {
    setTabToken(token);
    if (await signedInAs(true)) return 'header';
    setTabToken(null);
  }
  throw new ApiError('Your account details were accepted, but your sign-in is not reaching the YHOD server from this page: neither the session cookie nor YHOD\'s own header got through. Please open YHOD in its own browser tab, or use another browser.', 0, { code: 'SESSION_NOT_KEPT' });
}

export function forgetSession() {
  setTabToken(null);
}

export const timeZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } };
