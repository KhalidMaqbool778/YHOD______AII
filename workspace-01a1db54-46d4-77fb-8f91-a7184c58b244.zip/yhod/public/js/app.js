// YHOD — the main site after the introduction: navigation, sections and shared state.
import { h, $, $$, icon, swap, openModal, toast, busy, reveal, scrollToEl, errorNote } from './dom.js';
import { api, forgetSession, adoptSession, whenSignedOut, timeZone } from './api.js';
import { voice } from './voice.js';
import { createMicLogo } from './miclogo.js';
import { mountHome } from './home.js';
import { mountCheckin } from './checkin.js';
import { mountDashboard } from './dashboard.js';
import { mountStartYhod } from './startyhod.js';
import { openRecords } from './records.js';
import { GENERAL_DISCLAIMER } from '../shared/copy.js';
import { PASSWORD_MAX, passwordProblem } from '../shared/account.js';

const NAV = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'checkin', label: 'Daily Check-in', short: 'Check-in', icon: 'form' },
  { id: 'dashboard', label: 'Dashboard', icon: 'chart' },
  { id: 'start-yhod', label: 'START YHOD', short: 'START', icon: 'heart' },
];

function statusModal(ctx) {
  const body = h('div');
  const paint = (s, usage) => {
    const g = s?.gemini;
    const ago = (iso) => { const m = Math.round((Date.now() - Date.parse(iso)) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : `${Math.round(m / 60)} h ago`; };
    const rows = [];
    if (!s) rows.push(h('div.note.danger', icon('alert'), h('div', h('strong', 'The YHOD server could not be reached.'), h('div', 'Check your connection and try again.'))));
    else if (!g.configured) rows.push(h('div.note.danger', icon('alert'), h('div', h('strong', 'Gemini is not configured.'), h('div', g.error?.message || 'GEMINI_API_KEY is not set on the server.'))));
    else if (!g.ok) rows.push(h('div.note.danger', icon('alert'), h('div', h('strong', 'Gemini answered with an error.'), h('div', g.error?.message || 'Unknown error'), g.error?.status ? h('div.faint', { style: { marginTop: '4px', fontSize: '12px' } }, `HTTP ${g.error.status} · ${g.error.code || ''}`) : null)));
    else rows.push(h('div.note', icon('check'), h('div', h('strong', 'Connected to Google Gemini.'), h('div', 'Every analysis, conversation, photo assessment and spoken sentence in YHOD is produced by a live request from the YHOD server to the Gemini API. The API key stays on the server.'))));
    if (g?.configured) {
      const dl = h('dl.kv');
      const add = (k, v) => { if (v) dl.append(h('dt', k), h('dd', v)); };
      add('API', g.api);
      add('Daily feedback', g.models?.analysis || 'no model available right now');
      add('Assessments', g.models?.assessment || 'no model available right now');
      add('Photo analysis', g.models?.vision || 'no model available right now');
      add('Conversation', g.models?.conversation || 'no model available right now');
      add('Voice', g.models?.voice ? `${g.models.voice} · voice “${g.models.voiceName}”` : 'no model available right now');
      for (const [purpose, v] of Object.entries(g.lastSuccess || {})) add(`Last ${purpose}`, `${v.model} · ${v.ms} ms · ${ago(v.at)}`);
      for (const r of g.resting || []) add('Resting', `${r.model} — ${({ QUOTA: 'quota reached', UNAVAILABLE: 'busy', TIMEOUT: 'no answer', SLOW: 'slow', MODEL_UNAVAILABLE: 'not available', NETWORK: 'network' })[r.reason] || r.reason}, retry in ${r.seconds > 90 ? Math.ceil(r.seconds / 60) + ' min' : r.seconds + ' s'}`);
      if (usage) for (const [k, v] of Object.entries(usage)) add(({ text: 'Your AI requests today', image: 'Your photo analyses today', voice: 'Your voice requests today', transcribe: 'Your voice inputs today' })[k] || k, `${v.used} of ${v.limit}`);
      rows.push(dl);
    }
    swap(body, rows);
  };
  paint(ctx.status, null);
  const again = h('button.btn.btn-sm', { type: 'button', onclick: async () => {
    busy(again, true, 'Checking…');
    await ctx.refreshStatus(true);
    let usage = null;
    try { usage = (await api.get('/api/auth/me')).usage; } catch { usage = null; }
    busy(again, false);
    paint(ctx.status, usage);
  } }, icon('refresh'), 'Check again');
  openModal({ title: 'AI connection', body, actions: [again] });
  api.get('/api/auth/me').then((r) => paint(ctx.status, r.usage)).catch(() => {});
}

function targetsModal(ctx) {
  const t = ctx.user.targets;
  const field = (key, label, unit, step, min, max) => {
    const input = h('input.input', { type: 'number', inputmode: 'decimal', step: String(step), min: String(min), max: String(max), value: String(t[key]), 'data-key': key });
    return h('label.field', h('span', `${label} (${unit})`), input);
  };
  const error = h('div.form-error', { role: 'alert' });
  const unit = h('select.select', h('option', { value: 'C' }, 'Celsius (°C)'), h('option', { value: 'F' }, 'Fahrenheit (°F)'));
  unit.value = ctx.user.tempUnit || 'C';
  const form = h('form', { style: { display: 'grid', gap: '14px' } },
    h('p.muted', { style: { fontSize: '14px' } }, 'YHOD compares your daily check-in with these personal targets. Change them to suit you or the plan your doctor gave you.'),
    h('div.grid2',
      field('water', 'Water', 'glasses a day', 1, 1, 30), field('sleep', 'Sleep', 'hours a night', 0.5, 3, 14),
      field('activity', 'Walking + exercise', 'minutes a day', 5, 5, 600), field('steps', 'Steps', 'a day', 500, 500, 100000),
      field('fruitVeg', 'Fruit and vegetables', 'servings a day', 1, 1, 20), h('label.field', h('span', 'Temperature unit'), unit)),
    error,
  );
  const save = h('button.btn.btn-primary', { type: 'button', onclick: async () => {
    const targets = {};
    for (const i of $$('input[data-key]', form)) targets[i.dataset.key] = i.value;
    busy(save, true, 'Saving…');
    try {
      const r = await api.patch('/api/account', { targets, tempUnit: unit.value });
      Object.assign(ctx.user, r.user);
      ctx.bus.dispatchEvent(new CustomEvent('targets'));
      toast('Your targets were saved.', 'ok');
      m.close();
    } catch (e) { busy(save, false); error.textContent = e.message; }
  } }, 'Save targets');
  const m = openModal({ title: 'My daily targets', body: form, actions: [h('button.btn.btn-ghost', { type: 'button', onclick: () => m.close() }, 'Cancel'), save] });
}

export async function startApp(root, user, { status, introDone }) {
  const ctx = {
    user,
    status,
    introDone,
    bus: new EventTarget(),
    go: (id) => { const el = document.getElementById(id); if (el) scrollToEl(el); },
    openRecords: (tab) => openRecords(ctx, tab),
    openTargets: () => targetsModal(ctx),
    async refreshStatus(force = false) {
      try { ctx.status = await api.get(`/api/status?tz=${encodeURIComponent(user.tz || '')}${force ? '&refresh=1' : ''}`); } catch { ctx.status = null; }
      paintStatus();
      return ctx.status;
    },
  };

  // ── navigation ──
  const pill = h('button.status-pill', { type: 'button', title: 'AI connection', onclick: () => statusModal(ctx) }, h('span.dot'), h('b', 'Gemini'));
  function paintStatus() {
    const g = ctx.status?.gemini;
    pill.classList.toggle('ok', !!g?.ok);
    pill.classList.toggle('bad', !g?.ok);
    swap(pill, h('span.dot'), h('b', g?.ok ? 'Gemini live' : ctx.status ? 'Gemini problem' : 'Offline'));
    pill.setAttribute('aria-label', g?.ok ? 'Gemini is connected. Show details.' : 'There is a problem with the AI connection. Show details.');
  }
  const sound = h('button.icon-btn', { type: 'button', onclick: () => { voice.unlock(); voice.toggleMuted(); } });
  const paintSound = () => { swap(sound, icon(voice.muted ? 'mute' : 'volume')); sound.setAttribute('aria-label', voice.muted ? 'Sound is off. Turn sound on.' : 'Sound is on. Turn sound off.'); sound.title = voice.muted ? 'Sound off' : 'Sound on'; sound.classList.toggle('is-on', !voice.muted); };
  voice.addEventListener('change', paintSound);
  paintSound();

  let menuEl = null;
  const closeMenu = () => { if (menuEl) { menuEl.remove(); menuEl = null; avatar.setAttribute('aria-expanded', 'false'); document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', esc, true); } };
  const outside = (e) => { if (menuEl && !menuEl.contains(e.target) && !avatar.contains(e.target)) closeMenu(); };
  const esc = (e) => { if (e.key === 'Escape') { closeMenu(); avatar.focus(); } };
  const avatar = h('button.avatar', { type: 'button', 'aria-haspopup': 'menu', 'aria-expanded': 'false', 'aria-label': 'Account menu', onclick: () => {
    if (menuEl) return closeMenu();
    const item = (ic, label, fn, cls = '') => h(`button${cls}`, { type: 'button', role: 'menuitem', onclick: () => { closeMenu(); fn(); } }, icon(ic), label);
    menuEl = h('div.menu', { role: 'menu' },
      h('div.menu-head', h('b', ctx.user.name), h('span', ctx.user.email)),
      item('target', 'My daily targets', () => targetsModal(ctx)),
      item('folder', 'My records', () => openRecords(ctx)),
      item('shield', 'Privacy, export and delete', () => openRecords(ctx, 'privacy')),
      item('sparkle', 'AI connection', () => statusModal(ctx)),
      item('logout', 'Log out', logout, '.danger'),
    );
    avatarWrap.append(menuEl);
    avatar.setAttribute('aria-expanded', 'true');
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('keydown', esc, true);
  } }, (ctx.user.name || '?').trim().charAt(0).toUpperCase());
  const avatarWrap = h('div', { style: { position: 'relative' } }, avatar);

  async function logout() {
    voice.stop();
    try { await api.post('/api/auth/logout', {}); } catch { /* the session is forgotten locally either way */ }
    forgetSession();
    try { for (const k of Object.keys(localStorage)) if (k.startsWith('yhod.draft.')) localStorage.removeItem(k); } catch { /* ignore */ }
    location.reload();
  }

  // ── staying open ──
  // YHOD closes only when the person chooses "Log out". Should the server no longer know this sign-in (it has
  // run out after many days, or the workspace was logged out somewhere else), everything stays on screen as it
  // is and the password is asked for right here. The request that was refused is then sent again by api.js.
  whenSignedOut(() => new Promise((resolve) => {
    let settled = false;
    const finish = (ok) => { if (!settled) { settled = true; resolve(ok); } };
    const error = h('div.form-error', { role: 'alert', 'aria-live': 'assertive' });
    const password = h('input.input', { type: 'password', name: 'password', autocomplete: 'current-password', maxlength: String(PASSWORD_MAX), placeholder: 'Your YHOD password' });
    const go = h('button.btn.btn-primary', { type: 'submit' }, 'CONTINUE');
    const leave = h('button.btn.btn-ghost', { type: 'button', onclick: () => { modal.close(); logout(); } }, 'Log out');
    const form = h('form.stay-form', { novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      const problem = passwordProblem(password.value);
      if (problem) { error.textContent = problem; password.focus(); return; }
      error.textContent = '';
      busy(go, true, 'Checking…');
      try {
        const r = await api.post('/api/auth/enter', { email: ctx.user.email, password: password.value, tz: timeZone() }, { again: false });
        await adoptSession(r.token);
        finish(true);
        modal.close();
        toast('Thank you. You can carry on where you were.', 'ok');
      } catch (err) {
        busy(go, false);
        error.textContent = err.code === 'WRONG_PASSWORD' ? 'That is not the password of this workspace. Please try again.'
          : err.code === 'NO_WORKSPACE' ? 'This workspace does not exist any more: it was deleted. Choose "Log out" to start a new one.'
            : err.message;
        password.focus();
        password.select();
      }
    } },
      h('p.muted', 'YHOD needs to check that it is still you. Your workspace stays open, and nothing you have typed is lost.'),
      h('label.field', h('span', 'E-mail'), h('input.input', { type: 'email', name: 'email', autocomplete: 'username', value: ctx.user.email, readonly: true, tabindex: '-1' })),
      h('label.field', h('span', 'Password'), password),
      error,
      h('div.modal-actions', leave, go),
    );
    const modal = openModal({ title: 'Please enter your password again', body: form, cls: 'stay', onClose: () => finish(false) });
    requestAnimationFrame(() => password.focus({ preventScroll: true })); // the cursor belongs in the one field to fill in
  }));

  const links = NAV.map((n) => h('a', { href: `#${n.id}`, 'data-nav': n.id, onclick: (e) => { e.preventDefault(); ctx.go(n.id); } }, n.label));
  const recordsLink = h('a', { href: '#records', onclick: (e) => { e.preventDefault(); openRecords(ctx); } }, 'My Records');
  const nav = h('header.nav', h('div.nav-in',
    h('a.brand', { href: '#home', 'aria-label': 'YHOD home', onclick: (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); } }, h('span.brand-orb', icon('mic')), 'YHOD'),
    h('nav.nav-links', { 'aria-label': 'Sections' }, links, recordsLink),
    h('div.nav-right', pill, sound, avatarWrap),
  ));
  const tabs = h('nav.tabbar', { 'aria-label': 'Sections' },
    NAV.map((n) => h('a', { href: `#${n.id}`, 'data-nav': n.id, onclick: (e) => { e.preventDefault(); ctx.go(n.id); } }, icon(n.icon), n.short || n.label)),
    h('a', { href: '#records', onclick: (e) => { e.preventDefault(); openRecords(ctx); } }, icon('folder'), 'Records'),
  );

  // ── sections ──
  const home = h('section.hero#home');
  const checkin = h('section.section#checkin');
  const dashboard = h('section.section#dashboard');
  const start = h('section.section#start-yhod');
  const footer = h('footer.footer', h('div.wrap.footer-in',
    h('div', { style: { display: 'grid', gap: '12px' } }, h('span.brand', h('span.brand-orb', icon('mic')), 'YHOD'), h('p', GENERAL_DISCLAIMER)),
    h('div', { style: { display: 'grid', gap: '6px', justifyItems: 'start' } }, h('span.mono', { style: { fontSize: '11px', letterSpacing: '.2em' } }, 'YOUR HEALTH, OUR DUTY'), h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => openRecords(ctx, 'privacy') }, icon('shield'), 'Privacy and my data')),
  ));

  // floating mini assistant: appears when the main logo has scrolled away
  const dockMic = createMicLogo({ interactive: true, label: 'YHOD assistant. Go to the assistant.', waves: false });
  const bubble = h('div.dock-bubble', { hidden: true, 'aria-hidden': 'true' });
  const dock = h('div.dock', dockMic, bubble);
  dockMic.addEventListener('click', () => ctx.go('home'));
  let heroVisible = true;
  let startVisible = false; // in START YHOD every spoken reply is already on screen as text
  const paintDock = () => {
    dock.classList.toggle('is-in', !heroVisible && !startVisible);
    const text = voice.caption;
    if (!heroVisible && !startVisible && text) {
      bubble.hidden = false;
      swap(bubble, h('div', text), h('div.row', h('button', { type: 'button', onclick: () => voice.stop() }, 'Stop'), h('button', { type: 'button', onclick: () => voice.toggleMuted() }, voice.muted ? 'Unmute' : 'Mute')));
    } else bubble.hidden = true;
  };
  voice.addEventListener('change', paintDock);

  swap(root, nav, h('main', home, h('div.wrap', h('div.divider')), checkin, h('div.wrap', h('div.divider')), dashboard, h('div.wrap', h('div.divider')), start), footer, tabs, dock);

  mountHome(home, ctx);
  mountCheckin(checkin, ctx);
  mountDashboard(dashboard, ctx);
  mountStartYhod(start, ctx);

  if ('IntersectionObserver' in window) {
    const spy = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (e.isIntersecting && e.intersectionRatio > 0) {
          const id = e.target.id;
          for (const a of $$('[data-nav]')) a.classList.toggle('is-active', a.dataset.nav === id);
        }
      }
    }, { rootMargin: '-38% 0px -52% 0px', threshold: [0, 0.12, 0.5] });
    for (const s of [home, checkin, dashboard, start]) spy.observe(s);
    // the small floating logo takes over whenever the large assistant is out of sight
    const heroSpy = new IntersectionObserver(([e]) => { heroVisible = e.isIntersecting; paintDock(); }, { threshold: 0.05 });
    heroSpy.observe(home.querySelector('.assistant') || home);
    const startSpy = new IntersectionObserver(([e]) => { startVisible = e.isIntersecting; paintDock(); }, { rootMargin: '-45% 0px -45% 0px' });
    startSpy.observe(start);
  }

  paintStatus();
  if (!ctx.status) ctx.refreshStatus();
  reveal(root);
  root.classList.add('is-in');
  return ctx;
}

export { errorNote };
