// YHOD — shows an assessment (symptoms, photo, skin) and the emergency notice.
import { h, icon, busy, toast, errorNote, fmtDateTime, AI_MODEL_LABEL } from './dom.js';
import { api } from './api.js';
import { voice, speak } from './voice.js';
import { MEDICINE_DISCLAIMER } from '../shared/copy.js';
import { emergencyNumbers } from '../shared/safety.js';
import { timeZone } from './api.js';

export const LEVELS = {
  self_care: 'Monitor at home',
  routine_appointment: 'Routine appointment',
  prompt_assessment: 'Prompt assessment',
  emergency: 'Emergency',
};
const LEVEL_ORDER = ['self_care', 'routine_appointment', 'prompt_assessment', 'emergency'];
const KIND_TITLE = { symptom: 'Your symptom assessment', skin: 'Skin concern assessment', image: 'Photo assessment' };

/** The emergency notice: fixed, clear instructions and local emergency numbers. */
export function emergencyCard(em = {}, { title = 'This may be a medical emergency', onContinue } = {}) {
  const numbers = em.numbers && em.numbers.length ? em.numbers : emergencyNumbers(timeZone());
  const local = numbers[0];
  const steps = em.steps && em.steps.length ? em.steps : ['Call your local emergency number now, or go to the nearest emergency department.', 'Do not drive yourself. If someone is with you, ask them to stay and help.'];
  return h('div.urgent', { role: 'alert' },
    h('h3', icon('alert'), title),
    em.reasons && em.reasons.length ? h('p', `Why YHOD is saying this: ${em.reasons.join('; ')}.`) : null,
    h('ol', steps.map((s) => h('li', s))),
    h('div.call-row',
      local.numbers.map((n) => h('a.call', { href: `tel:${n.n}` }, icon('phone'), `Call ${n.n}`, h('small', `${n.label} · ${local.region}`))),
      numbers.slice(1, 4).map((r) => h('a.call.alt', { href: `tel:${r.numbers[0].n}` }, `${r.numbers[0].n}`, h('small', r.region))),
    ),
    onContinue ? h('div', h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: onContinue }, 'I have read this')) : null,
  );
}

const sec = (ic, title, ...kids) => h('div.asec', h('h4', icon(ic), title), kids);
const list = (items, ordered = false) => h(ordered ? 'ol' : 'ul', (items || []).map((x) => h('li', x)));

function treatmentResult(t, a) {
  const who = { self_care: ['Self-care', 'ok'], pharmacist: ['Ask a pharmacist', 'cyan'], doctor: ['Doctor decides', 'violet'] };
  return h('div', { style: { display: 'grid', gap: '16px' } },
    h('p', { style: { fontSize: '15px', lineHeight: '1.6', color: '#DCE1EA' } }, t.overview),
    h('div.topt', t.options.map((o) => h('div', h('b', o.category, h(`span.chip.${who[o.who_provides]?.[1] || 'cyan'}`, who[o.who_provides]?.[0] || o.who_provides)), h('span', o.what_it_is), h('small', `Take care: ${o.cautions}`)))),
    h('div.med-grid',
      h('div.med-item', h('h5', 'How a pharmacist can help'), h('p', t.pharmacist_help)),
      h('div.med-item', h('h5', 'What a doctor may consider'), h('p', t.doctor_may_consider)),
      t.personal_cautions.length ? h('div.med-item', h('h5', 'Cautions for you'), list(t.personal_cautions)) : null,
      t.when_to_see_specialist ? h('div.med-item', h('h5', 'When a specialist should examine this'), h('p', t.when_to_see_specialist)) : null,
    ),
    h('div.fb-actions',
      h('button.btn.btn-sm', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(t.spoken_summary, { source: 'treatment', id: a.id }, `t:${a.id}:${t.generatedAt}`); } }, icon('volume'), 'Listen'),
      h('span.ai-tag', icon('sparkle'), `${AI_MODEL_LABEL(t.model)} · ${fmtDateTime(t.generatedAt)}`),
    ),
    h('div.disclaimer', { role: 'note' }, icon('shield'), h('span', t.disclaimer || a.disclaimer || MEDICINE_DISCLAIMER)),
  );
}

/**
 * Render one assessment.
 *   a = { id, kind, createdAt, model, imageId, input, result, treatment }
 *   opts.onClearerPhoto — shows a "take a clearer photo" action when the photo was poor
 */
export function assessmentCard(a, { onClearerPhoto, emergency, autoPhoto = true } = {}) {
  const r = a.result;
  const isPhoto = a.kind !== 'symptom';
  const card = h('article.assess.card.glow', { 'aria-label': KIND_TITLE[a.kind] || 'Assessment' });

  card.append(h('div.assess-top',
    h('div', h('span.eyebrow', isPhoto ? 'Gemini looked at your photo' : 'Gemini assessed your answers'), h('h3', { style: { marginTop: '6px' } }, KIND_TITLE[a.kind] || 'Assessment')),
    h(`span.level.${r.seriousness_level}`, h('span.dot'), LEVELS[r.seriousness_level] || r.seriousness_level),
  ));

  if (r.seriousness_level === 'emergency') card.append(emergencyCard(emergency || { reasons: r.safetyFlags || [] }));

  if (isPhoto && (r.image_quality === 'poor' || r.image_quality === 'not_health_related' || r.needs_clearer_photo)) {
    card.append(h('div.note.warn', icon('camera'), h('div', { style: { flex: '1' } },
      h('strong', r.image_quality === 'not_health_related' ? 'This photo does not seem to show a health concern.' : r.image_quality === 'poor' ? 'YHOD could not see this photo clearly.' : 'A clearer photo would help.'),
      h('div', { style: { marginTop: '3px' } }, r.quality_note || 'Use good light, hold the camera steady and close, and keep the area in focus.'),
      onClearerPhoto ? h('div', { style: { marginTop: '11px' } }, h('button.btn.btn-sm', { type: 'button', onclick: onClearerPhoto }, icon('camera'), 'Take a clearer photo')) : null)));
  }

  if (isPhoto && a.imageId && autoPhoto) {
    const img = h('img.thumb', { alt: 'The photo you saved with this assessment' });
    api.blob(`/api/images/${a.imageId}`).then(({ blob }) => { img.src = URL.createObjectURL(blob); card.insertBefore(img, card.children[1] || null); }).catch(() => {});
  }
  if (isPhoto && a.input?.symptoms) card.append(sec('chat', 'WHAT YOU TOLD YHOD', h('p', `“${a.input.symptoms}”`)));
  if (!isPhoto && r.summary) card.append(sec('chat', 'WHAT YOU TOLD YHOD', h('p', r.summary)));
  if (isPhoto) card.append(sec('eye', 'WHAT I CAN SEE', list(r.what_i_can_see)));

  card.append(sec('search', 'POSSIBLE EXPLANATIONS',
    h('div.expl', r.possible_explanations.map((e) => h('div', h('b', e.name), h('span', e.why)))),
    h('p.faint', { style: { fontSize: '13px' } }, isPhoto ? 'These are possibilities, not a diagnosis. A photograph cannot confirm a condition — only an examination by a professional can.' : 'These are possibilities, not a diagnosis. Only a healthcare professional who examines you can confirm the cause.'),
  ));

  const idx = LEVEL_ORDER.indexOf(r.seriousness_level);
  card.append(sec('pulse', 'HOW SERIOUS IT MAY BE',
    h('div.scale', { role: 'img', 'aria-label': `Seriousness: ${LEVELS[r.seriousness_level]}` }, LEVEL_ORDER.map((k, i) => h(`div${i === idx ? '.on' : ''}`, h('i'), LEVELS[k]))),
    h('p', r.seriousness),
    r.levelRaisedBySafetyRules ? h('p.faint', { style: { fontSize: '13px' } }, `YHOD's fixed safety rules raised this to Emergency (Gemini suggested “${LEVELS[r.level_from_model] || r.level_from_model}”).`) : null,
  ));
  card.append(sec('stethoscope', 'WHICH DOCTOR SHOULD I CONSULT?', h('p', r.which_doctor)));
  card.append(sec('check', 'WHAT SHOULD I DO NOW?', list(r.what_to_do_now, true)));

  // ── medicines and treatment information ──
  const personalOut = h('div');
  const f = (name, label, placeholder, value = '') => h('label.field', h('span', label), h('input.input', { name, placeholder, value, maxlength: '300', autocomplete: 'off' }));
  const known = a.input?.answers || {};
  const prev = a.treatment?.details || {};
  const question = h('textarea.textarea', { name: 'question', maxlength: '500', placeholder: 'Optional — for example: Is it safe for me to use an anti-itch cream?', style: { minHeight: '70px' } }, prev.question || '');
  const formErr = h('div');
  const go = h('button.btn.btn-primary', { type: 'submit' }, icon('sparkle'), 'GET INFORMATION FOR ME');
  const form = h('form', { style: { display: 'grid', gap: '12px' }, onsubmit: async (e) => {
    e.preventDefault();
    const body = { assessmentId: a.id, question: question.value };
    for (const i of form.querySelectorAll('input[name]')) body[i.name] = i.value;
    busy(go, true, 'Gemini is preparing this…');
    formErr.replaceChildren();
    try {
      const out = await api.post('/api/treatment', body);
      a.treatment = out.treatment;
      personalOut.replaceChildren(treatmentResult(out.treatment, a));
      voice.unlock();
      speak(out.treatment.spoken_summary, { source: 'treatment', id: a.id }, `t:${a.id}:${out.treatment.generatedAt}`, { auto: true });
    } catch (err) {
      formErr.replaceChildren(errorNote(err, { title: 'The treatment information could not be prepared' })); // what was typed stays in the form
    }
    busy(go, false);
  } },
    h('div.grid2', f('age', 'Age', 'e.g. 34', prev.age || known.age || ''), f('allergies', 'Allergies', 'e.g. penicillin, or none', prev.allergies || ''), f('conditions', 'Health conditions', 'e.g. asthma, diabetes, or none', prev.conditions || known.conditions || ''), f('medicines', 'Medicines you take now', 'e.g. salbutamol inhaler, or none', prev.medicines || known.medicines || '')),
    f('other', 'Anything else (pregnancy, breastfeeding …)', 'Optional', prev.other || ''),
    h('label.field', h('span', 'Your question'), question),
    formErr,
    h('div', go),
  );
  if (a.treatment) personalOut.append(treatmentResult(a.treatment, a));
  card.append(h('div.med',
    h('h4', icon('pill'), 'MEDICINES AND TREATMENT INFORMATION'),
    h('div.med-grid',
      h('div.med-item', h('h5', 'Common treatment categories'), list(r.treatment_options)),
      h('div.med-item', h('h5', 'What a doctor may consider'), h('p', r.doctor_may_consider || 'A doctor will decide on any tests or prescription treatment after examining you.')),
      h('div.med-item', h('h5', 'When a pharmacist can help'), h('p', r.pharmacist_help)),
      h('div.med-item', h('h5', 'Precautions and possible side effects'), list(r.precautions)),
      r.specialist_note ? h('div.med-item', { style: { gridColumn: '1 / -1' } }, h('h5', a.kind === 'skin' ? 'When a dermatologist should examine this' : 'When a specialist should examine this'), h('p', r.specialist_note)) : null,
    ),
    h('div.disclaimer', { role: 'note' }, icon('shield'), h('span', a.disclaimer || MEDICINE_DISCLAIMER)),
    h('details.personal', { open: !!a.treatment }, h('summary', icon('chevron'), 'Make this information fit me (age, allergies, conditions, current medicines)'), form, personalOut),
  ));

  card.append(sec('alert', 'GET URGENT HELP IF YOU NOTICE', list(r.watch_for)));

  card.append(h('div.assess-foot',
    h('div.fb-actions',
      h('button.btn.btn-sm', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(r.spoken_summary, { source: 'assessment', id: a.id }, `a:${a.id}`); } }, icon('volume'), 'Listen'),
      h('span.ai-tag', icon('sparkle'), `${AI_MODEL_LABEL(a.model)} · ${fmtDateTime(a.createdAt)}`),
    ),
    h('span.faint', { style: { fontSize: '12.5px' } }, isPhoto ? (a.imageId ? 'Saved to your records with the photo, as you chose.' : 'Saved to your records. The photo itself was not kept.') : 'Saved to your records.'),
  ));
  return card;
}
