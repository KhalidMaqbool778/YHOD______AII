// YHOD — the entrance. A person types their name, their e-mail and their own password.
//   First time:  YHOD asks once, then creates their private workspace.
//   Afterwards:  the same e-mail and password open that workspace again, with everything saved in it.
// The rules for the three fields live in /shared/account.js and are the same ones the server applies.
import { h, icon, busy, swap } from './dom.js';
import { api, adoptSession, timeZone } from './api.js';
import { createMicLogo } from './miclogo.js';
import { NAME_MAX, EMAIL_MAX, PASSWORD_MAX, cleanName, cleanEmail, nameProblem, emailProblem, emailSuggestion, passwordProblem, passwordLength } from '../shared/account.js';

export function showAuth(root, { onAuthed, ready = null }) {
  const error = h('div.form-error', { role: 'alert', 'aria-live': 'assertive' });
  const name = h('input.input', { type: 'text', name: 'name', autocomplete: 'name', maxlength: String(NAME_MAX), placeholder: 'What should YHOD call you?' });
  const email = h('input.input', { type: 'email', name: 'email', autocomplete: 'email', maxlength: String(EMAIL_MAX), placeholder: 'you@example.com', inputmode: 'email', autocapitalize: 'off', spellcheck: 'false' });
  const password = h('input.input', { type: 'password', name: 'password', autocomplete: 'current-password', maxlength: String(PASSWORD_MAX), placeholder: 'Any password you choose' });
  const eye = h('button', { type: 'button', 'aria-label': 'Show password', onclick: () => {
    const show = password.type === 'password';
    password.type = show ? 'text' : 'password';
    eye.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    swap(eye, icon(show ? 'eyeOff' : 'eye'));
  } }, icon('eye'));

  // "Did you mean name@gmail.com?" for a mistyped well-known mail domain. Only ever a suggestion.
  const didYouMean = h('div.field-hint', { hidden: true, 'aria-live': 'polite' });
  const suggest = () => {
    const better = emailProblem(email.value) ? null : emailSuggestion(email.value);
    didYouMean.hidden = !better;
    if (better) swap(didYouMean, 'Did you mean ', h('b', better), '? ', h('button', { type: 'button', onclick: () => { email.value = better; suggest(); error.textContent = ''; password.focus(); } }, 'Use this e-mail'));
  };
  email.addEventListener('blur', suggest);
  email.addEventListener('input', () => { if (!didYouMean.hidden) suggest(); });

  const submit = h('button.btn.btn-primary.btn-lg.btn-block', { type: 'submit' }, 'OPEN MY YHOD');
  const details = () => ({ name: cleanName(name.value), email: cleanEmail(email.value), password: password.value, tz: timeZone() });

  const form = h('form', { novalidate: true, onsubmit: (e) => { e.preventDefault(); enter(false); } },
    h('label.field', h('span', 'Your name'), name),
    h('label.field', h('span', 'E-mail'), email, didYouMean),
    h('label.field', h('span', 'Password'), h('div.pw', password, eye)),
    error,
    submit,
    h('p.auth-help', h('b', 'First time here?'), ' YHOD creates your private workspace. ', h('b', 'Been here before?'), ' The same e-mail and password open it again, with everything you saved.'),
  );
  const body = h('div.auth-body', form);

  function showForm(message = '', field = null) {
    busy(submit, false);
    if (!body.contains(form)) swap(body, form);
    card.classList.remove('is-confirming');
    error.textContent = message;
    if (field) field.focus({ preventScroll: true });
  }

  /** Send the three details. `create` is true only after the person has confirmed a new workspace. */
  async function enter(create, button = submit) {
    const d = details();
    for (const [field, problem] of [[name, nameProblem(d.name)], [email, emailProblem(d.email)], [password, passwordProblem(d.password)]]) {
      if (problem) return showForm(problem, field);
    }
    error.textContent = '';
    busy(button, true, create ? 'Creating your workspace…' : 'Opening your YHOD…');
    try {
      const r = await api.post('/api/auth/enter', { ...d, create });
      await adoptSession(r.token);
      onAuthed(r.user, { isNew: !!r.isNew });
    } catch (err) {
      busy(button, false);
      if (err.code === 'NO_WORKSPACE' && !create) return confirmNew(d);
      showForm(err.message, err.code === 'INVALID_NAME' ? name : err.code === 'INVALID_EMAIL' ? email : ['WRONG_PASSWORD', 'INVALID_PASSWORD', 'EMAIL_IN_USE'].includes(err.code) ? password : null);
      if (err.code === 'WRONG_PASSWORD') password.select();
    }
  }

  /** Nothing has been opened with this e-mail yet: a typing mistake in the e-mail, or a new person. Ask before creating. */
  function confirmNew(d) {
    const count = passwordLength(d.password);
    const dots = '•'.repeat(Math.min(count, 28));
    const shown = h('span.pw-shown', dots);
    const reveal = h('button', { type: 'button', 'aria-pressed': 'false', onclick: () => {
      const show = reveal.getAttribute('aria-pressed') !== 'true';
      reveal.setAttribute('aria-pressed', String(show));
      reveal.textContent = show ? 'Hide' : 'Show';
      shown.textContent = show ? d.password : dots;
    } }, 'Show');
    const better = emailSuggestion(d.email);
    const create = h('button.btn.btn-primary.btn-lg.btn-block', { type: 'button', onclick: () => enter(true, create) }, 'CREATE MY WORKSPACE');
    const back = h('button.btn.btn-ghost.btn-block', { type: 'button', onclick: () => showForm('', email) }, 'Change my details');
    const view = h('div.auth-confirm', { role: 'group', 'aria-label': 'Create a new workspace', onkeydown: (e) => { if (e.key === 'Escape') showForm('', email); } },
      h('h2', 'No YHOD workspace has been opened with this e-mail yet'),
      h('p', h('b', 'Used YHOD before?'), ' Then this e-mail has a typing mistake: go back and correct it, and your workspace will open. ', h('b', 'New here?'), ' YHOD will create your private workspace with these details:'),
      better ? h('div.note.warn', icon('alert'), h('div', 'Did you mean ', h('strong', better), '? ', h('button.linkish', { type: 'button', onclick: () => { email.value = better; suggest(); showForm(); enter(false); } }, 'Use this e-mail'))) : null,
      h('dl.who',
        h('div', h('dt', 'Name'), h('dd', d.name)),
        h('div', h('dt', 'E-mail'), h('dd', d.email)),
        h('div', h('dt', 'Password'), h('dd', shown, h('small', ` ${count} character${count === 1 ? '' : 's'} `), reveal)),
      ),
      create,
      back,
      h('p.small', count < 8 ? 'Any password is accepted, but a short one is easier for someone else to guess. ' : null, h('b', 'Keep your password safe:'), ' YHOD stores it only in scrambled form and has no way to show or reset it.'),
    );
    card.classList.add('is-confirming');
    swap(body, view);
    create.focus({ preventScroll: true });
  }

  const card = h('div.auth-card.glass.glow',
    h('div.auth-head', createMicLogo({ label: 'YHOD', waves: false }), h('h1', 'Open your YHOD'), h('p', 'Your name, your e-mail and your own password open your private health workspace.')),
    body,
    h('div.auth-foot', icon('lock'), h('span', 'Passwords are stored only as salted hashes. Your daily answers, AI feedback and assessments are encrypted on the server, belong to your workspace alone, and can be exported or deleted by you at any time.')),
  );
  swap(root, h('main.auth', card));
  // Put the cursor in the first field once the introduction has left the screen (so it never takes the
  // focus away from the intro's own buttons). Not on touch screens, where it would open the keyboard.
  const touch = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
  Promise.resolve(ready).then(() => { if (!touch) setTimeout(() => { if (body.contains(form) && document.activeElement === document.body) name.focus({ preventScroll: true }); }, 300); });
}
