// YHOD — camera capture and image preparation.
// The camera is only started after the person presses OPEN CAMERA and accepts the
// browser's own permission prompt. It is switched off as soon as a photo is taken
// or the window is closed.
import { h, icon, swap, openModal } from './dom.js';
import { mediaErrorText } from './recorder.js';

export const ACCEPT = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_EDGE = 1600;

export function cameraSupported() {
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
}

/**
 * Opens the camera window.
 *   onUse(blob)   — called with the captured JPEG when the person presses USE PHOTO
 *   onUpload()    — offered as an alternative when the camera cannot be used
 */
export function openCamera({ onUse, onUpload }) {
  let stream = null;
  let facing = 'environment';
  let shot = null; // { blob, url }
  let closed = false;
  let cameras = 1;

  const video = h('video', { autoplay: true, playsinline: true, muted: true, 'aria-label': 'Live camera preview' });
  video.muted = true;
  video.setAttribute('playsinline', '');
  const view = h('div.cam-view');
  const bar = h('div.cam-bar');
  const flash = h('div.cam-flash');
  const status = h('div.sr-only', { role: 'status', 'aria-live': 'polite' });

  const stop = () => { if (stream) { for (const t of stream.getTracks()) t.stop(); stream = null; } video.srcObject = null; };
  const close = () => { closed = true; stop(); if (shot) URL.revokeObjectURL(shot.url); modal.close(); };

  function message(ic, title, text, actions = []) {
    swap(view, h('div.cam-msg', icon(ic), h('b', title), h('div', text), actions.length ? h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '9px', justifyContent: 'center', marginTop: '6px' } }, actions) : null));
  }

  async function start() {
    if (closed) return;
    stop();
    if (shot) { URL.revokeObjectURL(shot.url); shot = null; }
    swap(bar, h('div.side'), h('button.shutter', { type: 'button', disabled: true, 'aria-label': 'Take photo' }), h('div.side.r', h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: close }, 'Close')));
    if (!cameraSupported() || !window.isSecureContext) {
      message('camera', 'The camera is not available here', window.isSecureContext ? 'This browser does not let websites use the camera.' : 'The camera only works on a secure (https) connection.', fallbacks());
      return;
    }
    message('camera', 'Waiting for your permission', 'Your browser is asking whether YHOD may use the camera. YHOD only uses it while this window is open, and nothing is sent until you press USE PHOTO.');
    status.textContent = 'Asking for camera permission';
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1920 }, height: { ideal: 1440 } }, audio: false });
    } catch (e) {
      if (closed) return;
      status.textContent = 'The camera could not be started';
      message('alert', 'The camera could not be started', mediaErrorText(e, 'camera'), [h('button.btn.btn-sm', { type: 'button', onclick: start }, icon('refresh'), 'Try again'), ...fallbacks()]);
      return;
    }
    if (closed) { stop(); return; }
    video.srcObject = stream;
    const settings = stream.getVideoTracks()[0]?.getSettings?.() || {};
    video.style.transform = settings.facingMode === 'user' ? 'scaleX(-1)' : ''; // mirror the selfie preview only
    swap(view, video, h('div.frame'), flash);
    try { await video.play(); } catch { /* autoplay with muted+playsinline is allowed */ }
    // the window takes the shape of the picture the camera really delivers (portrait on a phone held upright)
    const fit = () => { if (video.videoWidth && video.videoHeight) view.style.aspectRatio = `${video.videoWidth} / ${video.videoHeight}`; };
    fit();
    video.addEventListener('loadedmetadata', fit, { once: true });
    video.addEventListener('resize', fit);
    try { cameras = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput').length; } catch { cameras = 1; }
    status.textContent = 'Camera is live';
    const shutter = h('button.shutter', { type: 'button', 'aria-label': 'Take photo', onclick: capture });
    swap(bar,
      h('div.side', cameras > 1 ? h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { facing = facing === 'environment' ? 'user' : 'environment'; start(); } }, icon('swap'), 'Switch') : null),
      shutter,
      h('div.side.r', h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: close }, 'Close')));
    shutter.focus({ preventScroll: true });
  }

  function fallbacks() {
    const out = [];
    let framed = false;
    try { framed = window.self !== window.top; } catch { framed = true; }
    if (framed) out.push(h('a.btn.btn-sm', { href: location.href, target: '_blank', rel: 'noopener' }, icon('external'), 'Open YHOD in its own tab'));
    if (onUpload) out.push(h('button.btn.btn-sm', { type: 'button', onclick: () => { close(); onUpload(); } }, icon('upload'), 'Upload an image instead'));
    return out;
  }

  function capture() {
    if (!stream || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go');
    canvas.toBlob((blob) => {
      if (!blob || closed) return;
      stop(); // the camera goes off as soon as the photo is taken
      shot = { blob, url: URL.createObjectURL(blob) };
      swap(view, h('img', { src: shot.url, alt: 'The photo you just took' }));
      status.textContent = 'Photo taken. Choose retake or use photo.';
      const use = h('button.btn.btn-primary', { type: 'button', onclick: () => { const b = shot.blob; closed = true; stop(); URL.revokeObjectURL(shot.url); modal.close(); onUse(b); } }, icon('check'), 'USE PHOTO');
      swap(bar, h('div.side', h('button.btn', { type: 'button', onclick: start }, icon('replay'), 'RETAKE')), h('span'), h('div.side.r', use));
      use.focus({ preventScroll: true });
    }, 'image/jpeg', 0.92);
  }

  const modal = openModal({ title: '', cls: 'cam', body: h('div', view, bar, status), onClose: () => { closed = true; stop(); } });
  modal.el.querySelector('.modal-close')?.remove();
  modal.el.firstElementChild.style.marginTop = '0';
  start();
  return { close };
}

/**
 * Prepares a photo for sending: fixes its rotation, limits it to 1600 px and
 * re-encodes it as JPEG. Re-encoding also removes hidden details stored inside
 * photo files, such as the GPS location.
 * Resolves to { base64, blob, width, height }.
 */
export async function prepareImage(blob) {
  const toB64 = (b) => new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result).split(',')[1]); r.onerror = () => reject(r.error); r.readAsDataURL(b); });
  try {
    let source;
    let w;
    let hgt;
    if ('createImageBitmap' in window) {
      try { source = await createImageBitmap(blob, { imageOrientation: 'from-image' }); } catch { source = null; }
    }
    if (!source) {
      source = await new Promise((resolve, reject) => { const img = new Image(); const url = URL.createObjectURL(blob); img.onload = () => { URL.revokeObjectURL(url); resolve(img); }; img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode failed')); }; img.src = url; });
    }
    w = source.width || source.naturalWidth;
    hgt = source.height || source.naturalHeight;
    const k = Math.min(1, MAX_EDGE / Math.max(w, hgt));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(w * k));
    canvas.height = Math.max(1, Math.round(hgt * k));
    const c = canvas.getContext('2d');
    c.fillStyle = '#fff'; // transparent PNG areas become white, not black
    c.fillRect(0, 0, canvas.width, canvas.height);
    c.imageSmoothingQuality = 'high';
    c.drawImage(source, 0, 0, canvas.width, canvas.height);
    if (source.close) source.close();
    const out = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.88));
    if (!out) throw new Error('encode failed');
    return { base64: await toB64(out), blob: out, width: canvas.width, height: canvas.height };
  } catch {
    // the browser could not decode it: send the original file untouched (the server validates it)
    return { base64: await toB64(blob), blob, width: null, height: null };
  }
}
