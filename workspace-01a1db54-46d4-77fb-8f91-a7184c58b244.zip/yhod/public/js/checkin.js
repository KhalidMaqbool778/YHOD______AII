// YHOD — the daily health check-in (60 fill-in sentences) and the Gemini analysis of it.
import { h, $, $$, icon, swap, append, busy, toast, debounce, scrollToEl, errorNote, fmtDateTime, pad2, AI_MODEL_LABEL, reveal } from './dom.js';
import { api } from './api.js';
import { voice, speak } from './voice.js';
import { emergencyCard } from './assessview.js';
import { SECTIONS, QUESTIONS, TOTAL_QUESTIONS, normaliseAnswer, normaliseAnswers } from '../shared/questions.js';
import { EMERGENCY_VOICE_TEXT } from '../shared/copy.js';

const BLANK = '____';

/** Build one question row. Returns { el, q, get, set, clear, error }. */
function questionRow(q, { onChange, tempUnit }) {
  const row = h('div.q', { 'data-id': String(q.id) });
  const sentence = h('div.q-sentence');
  const err = h('div.q-err', { hidden: true, role: 'alert' });
  const label = q.text.replace(BLANK, 'blank');
  let get = () => undefined;
  let set = () => {};
  const text = (s) => { const t = String(s || '').trim(); return t ? h(`span.t${/^[.,;:!?]+$/.test(t) ? '.p' : ''}`, t) : null; };
  const [before, afterRaw] = q.text.includes(BLANK) ? q.text.split(BLANK) : [q.text, null];
  const after = afterRaw;
  const changed = () => { paint(); onChange(q.id); };

  const buttons = (options, { square = false, end = false } = {}) => {
    let value;
    const group = h(`div.q-opts${end ? '.end' : ''}`, { role: 'group', 'aria-label': label });
    const btns = options.map((o) => h(`button.q-opt${square ? '.sq' : ''}`, { type: 'button', 'aria-pressed': 'false', onclick: () => { value = value === o ? undefined : o; sync(); changed(); } }, String(o)));
    const sync = () => btns.forEach((b, i) => b.setAttribute('aria-pressed', String(options[i] === value)));
    get = () => value;
    set = (v) => { value = options.find((o) => String(o).toLowerCase() === String(v ?? '').toLowerCase()); sync(); };
    group.append(...btns);
    return group;
  };

  switch (q.type) {
    case 'number': {
      const input = h(`input.q-in.num${q.wide ? '.wide' : ''}`, { type: 'text', inputmode: q.step < 1 ? 'decimal' : 'numeric', autocomplete: 'off', placeholder: '—', 'aria-label': label, maxlength: '8', enterkeyhint: 'next' });
      input.addEventListener('input', () => { const v = input.value.replace(/[^\d.,]/g, ''); if (v !== input.value) input.value = v; changed(); });
      get = () => (input.value.trim() === '' ? undefined : input.value.trim());
      set = (v) => { input.value = v === undefined || v === null ? '' : String(v); };
      append(sentence, text(before), input, text(after));
      break;
    }
    case 'rating': {
      append(sentence, text(before), buttons(Array.from({ length: q.max }, (_, i) => i + 1), { square: true }), text(after));
      break;
    }
    case 'choice': {
      if (after === null) append(sentence, text(before), buttons(q.options, { end: true }));
      else append(sentence, text(before), buttons(q.options), text(after));
      break;
    }
    case 'select': {
      const sel = h('select.q-in.is-empty', { 'aria-label': label }, h('option', { value: '' }, 'choose'), q.options.map((o) => h('option', { value: o }, o.toLowerCase())));
      sel.addEventListener('change', () => { sel.classList.toggle('is-empty', !sel.value); changed(); });
      get = () => sel.value || undefined;
      set = (v) => { sel.value = v || ''; sel.classList.toggle('is-empty', !sel.value); };
      append(sentence, text(before), sel, text(after));
      break;
    }
    case 'time': {
      const input = h('input.q-in.time', { type: 'time', 'aria-label': label });
      input.addEventListener('input', changed);
      input.addEventListener('change', changed);
      get = () => input.value || undefined;
      set = (v) => { input.value = v || ''; };
      append(sentence, text(before), input, text(after));
      break;
    }
    case 'temperature': {
      let unit = tempUnit === 'F' ? 'F' : 'C';
      const input = h('input.q-in.num', { type: 'text', inputmode: 'decimal', autocomplete: 'off', placeholder: '—', 'aria-label': 'My body temperature was blank', maxlength: '6' });
      const bC = h('button.q-opt.sq', { type: 'button', 'aria-pressed': 'false', 'aria-label': 'degrees Celsius', onclick: () => { unit = 'C'; sync(); changed(); } }, '°C');
      const bF = h('button.q-opt.sq', { type: 'button', 'aria-pressed': 'false', 'aria-label': 'degrees Fahrenheit', onclick: () => { unit = 'F'; sync(); changed(); } }, '°F');
      const sync = () => { bC.setAttribute('aria-pressed', String(unit === 'C')); bF.setAttribute('aria-pressed', String(unit === 'F')); };
      sync();
      input.addEventListener('input', () => { const v = input.value.replace(/[^\d.,]/g, ''); if (v !== input.value) input.value = v; changed(); });
      get = () => (input.value.trim() === '' ? undefined : { value: input.value.trim(), unit });
      set = (v) => { if (v && typeof v === 'object') { input.value = v.value ?? ''; unit = v.unit === 'F' ? 'F' : 'C'; } else input.value = ''; sync(); };
      append(sentence, text(before), input, h('div.q-opts', { role: 'group', 'aria-label': 'Temperature unit' }, bC, bF), text('.'));
      break;
    }
    default: { // text
      let input;
      if (q.long) {
        input = h('textarea.q-in.txt.long', { rows: '1', maxlength: String(q.maxLength), placeholder: 'type here', 'aria-label': label });
        // One line tall as set by the stylesheet (35 px, 40 px on phones); it only gets an inline height when the text needs more room.
        const grow = () => {
          input.style.height = '';
          const base = parseFloat(getComputedStyle(input).height);
          if (!base || !input.scrollHeight) return; // not laid out yet: the stylesheet height applies
          const want = Math.min(160, input.scrollHeight + 2);
          if (want > base + 1) input.style.height = `${want}px`;
        };
        input.addEventListener('input', () => { grow(); changed(); });
        set = (v) => { input.value = v || ''; requestAnimationFrame(grow); };
      } else {
        const attrs = { type: 'text', maxlength: String(q.maxLength), placeholder: 'type here', 'aria-label': label, autocomplete: 'off' };
        if (q.suggestions) attrs.list = `q${q.id}-list`;
        input = h('input.q-in.txt', attrs);
        input.addEventListener('input', changed);
        set = (v) => { input.value = v || ''; };
        if (q.suggestions) row.append(h('datalist', { id: `q${q.id}-list` }, q.suggestions.map((s) => h('option', { value: s }))));
      }
      get = () => (input.value.trim() === '' ? undefined : input.value);
      const tail = (after || '').trim();
      append(sentence, text(before), input, q.long ? null : text(tail === '.' ? '.' : after));
    }
  }

  // a full stop (or other closing punctuation) stays attached to the field before it, so it can never wrap onto a line of its own
  for (const p of [...sentence.children]) {
    if (!p.classList.contains('p') || !p.previousElementSibling) continue;
    const keep = h('span.q-nb');
    p.previousElementSibling.before(keep);
    keep.append(keep.nextElementSibling, p);
  }

  const clearBtn = h('button.q-clear', { type: 'button', 'aria-label': `Clear answer ${q.id}`, title: 'Clear (skip this one)', onclick: () => { set(undefined); changed(); } }, icon('x'));
  const paint = () => {
    row.classList.toggle('is-filled', get() !== undefined);
    if (row.classList.contains('is-error')) { row.classList.remove('is-error'); err.hidden = true; }
  };
  row.append(h('span.q-num', { 'aria-hidden': 'true' }, pad2(q.id)), h('div.q-bar', icon('search', { class: 'q-icon' }), sentence, clearBtn), err);
  return {
    el: row, q,
    get: () => get(),
    set: (v) => { set(v); paint(); },
    error: (msg) => { row.classList.toggle('is-error', !!msg); err.hidden = !msg; err.textContent = msg || ''; },
  };
}

function feedbackView(feedback, date, { onAgain, numbers }) {
  const f = feedback;
  const out = h('div', { style: { display: 'grid', gap: '18px' } });
  if (f.urgency === 'emergency') out.append(emergencyCard({ numbers, reasons: (f.notices || []).filter((n) => n.level === 'emergency').map((n) => n.title) }, { title: f.urgent_advice || 'Please get medical help now' }));
  else if (f.urgency === 'urgent') out.append(h('div.urgent.amber', { role: 'alert' }, h('h3', icon('alert'), 'Please contact a doctor today'), h('p', f.urgent_advice || 'Something you recorded today should be checked by a doctor today.')));
  const rules = (f.notices || []).map((n) => h('li.rule', h('small', 'Safety notice'), h('strong', n.title + '. '), n.text));
  const card = (cls, ic, title, items, extra = []) => h(`div.fb.card.${cls}`, h('div.fb-head', h('div.fb-ico', icon(ic)), h('h3', title)), h('ul', extra, items.map((t) => h('li', t))));
  out.append(h('div.fb-grid',
    card('right', 'check', 'WHAT YOU ARE DOING RIGHT', f.doing_right),
    card('improve', 'trend', 'WHAT YOU SHOULD IMPROVE', f.improve),
    card('careful', 'alert', 'WHAT YOU SHOULD BE CAREFUL ABOUT', f.be_careful, rules),
  ));
  out.append(h('div.fb-message.card.glow',
    h('div.fb-head', h('div.fb-ico', { style: { color: 'var(--cyan)', background: 'var(--cyan-soft)', borderColor: 'rgba(0,217,255,.3)' } }, icon('heart')), h('h3', 'YOUR PERSONALIZED HEALTH MESSAGE')),
    h('blockquote', f.personal_message),
    h('div.fb-actions',
      h('button.btn.btn-sm.btn-primary', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(f.spoken_summary, { source: 'checkin', date }, `fb:${date}:${f.generatedAt}`); } }, icon('volume'), 'Listen to my feedback'),
      onAgain ? h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: onAgain }, icon('refresh'), 'Analyse again') : null,
      h('span.ai-tag', icon('sparkle'), `Analysed by ${AI_MODEL_LABEL(f.model)} · ${fmtDateTime(f.generatedAt)} · ${f.answered} of ${TOTAL_QUESTIONS} answers`),
    ),
  ));
  return out;
}
export { feedbackView };

export function mountCheckin(root, ctx) {
  const rows = new Map();
  let today = null;
  let savedAt = null;
  const draftKey = () => `yhod.draft.${ctx.user.id}.${today}`;
  const count = h('div.form-count');
  const fill = h('i');
  const tabs = h('div.sec-tabs', { role: 'navigation', 'aria-label': 'Check-in sections' });
  const tabEls = {};
  const state = h('span.faint', { style: { fontSize: '12.5px', whiteSpace: 'nowrap' } });
  const analysis = h('div.analysis', { 'aria-live': 'polite' });
  const submit = h('button.btn.btn-primary.submit-big', { type: 'submit' }, 'SUBMIT MY DAILY HEALTH FORM');
  const formErr = h('div', { style: { width: '100%' } });

  const values = () => { const v = {}; for (const [id, r] of rows) { const x = r.get(); if (x !== undefined) v[id] = x; } return v; };
  const saveDraft = debounce(() => { if (!today) return; try { localStorage.setItem(draftKey(), JSON.stringify({ at: Date.now(), values: values() })); state.textContent = 'Draft kept on this device'; } catch { /* storage unavailable */ } }, 450);
  const progress = () => {
    let n = 0;
    for (const s of SECTIONS) {
      const ids = QUESTIONS.filter((q) => q.section === s.id);
      const done = ids.filter((q) => rows.get(q.id).get() !== undefined).length;
      n += done;
      const t = tabEls[s.id];
      t.querySelector('em').textContent = `${done}/${ids.length}`;
      t.classList.toggle('is-done', done === ids.length);
      t.classList.toggle('has-some', done > 0 && done < ids.length);
    }
    swap(count, h('b', String(n)), ` of ${TOTAL_QUESTIONS} answered`);
    fill.style.width = `${(n / TOTAL_QUESTIONS) * 100}%`;
    return n;
  };
  const onChange = () => { progress(); saveDraft(); };

  const sections = SECTIONS.map((s) => {
    const qs = QUESTIONS.filter((q) => q.section === s.id);
    const list = h('div.qlist');
    for (const q of qs) { const r = questionRow(q, { onChange, tempUnit: ctx.user.tempUnit }); rows.set(q.id, r); list.append(r.el); }
    const el = h('div.qsec.card.reveal', { id: `sec-${s.id}` }, h('div.qsec-head', h('div.qsec-icon', icon(s.icon)), h('div', h('h3', s.title), h('span', `Sentences ${pad2(qs[0].id)}–${pad2(qs[qs.length - 1].id)} · fill in what you want, skip the rest`))), list);
    tabEls[s.id] = h('button.sec-tab', { type: 'button', onclick: () => scrollToEl(el, 96) }, icon(s.icon), s.short, h('em', `0/${qs.length}`));
    tabs.append(tabEls[s.id]);
    return el;
  });

  const formBar = h('div.form-bar.glass', h('div.form-bar-top', count, h('div.meter', { role: 'progressbar', 'aria-label': 'Answered sentences', 'aria-valuemin': '0', 'aria-valuemax': String(TOTAL_QUESTIONS) }, fill), state), tabs);
  const barMark = h('div', { 'aria-hidden': 'true', style: { height: '1px', marginBottom: '-1px' } });
  if ('IntersectionObserver' in window) {
    // know when the progress bar is pinned under the navigation (it then hides what scrolls behind it)
    const navH = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--nav-h')) || 68;
    new IntersectionObserver(([e]) => formBar.classList.toggle('is-stuck', !e.isIntersecting && e.boundingClientRect.top < navH + 40), { rootMargin: `-${Math.round(navH + 12)}px 0px 0px 0px`, threshold: 0 }).observe(barMark);
  }
  const form = h('form', { novalidate: true, onsubmit: (e) => { e.preventDefault(); run(); } },
    barMark, formBar,
    sections,
    h('div.form-foot', formErr, submit, h('p', 'Every sentence is optional. When you submit, your answers are saved to your account and sent to Gemini, which writes your feedback from exactly what you entered.')),
  );
  // Enter inside a single-line field moves on instead of submitting half a form
  form.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.target.tagName !== 'INPUT') return;
    e.preventDefault();
    const fields = $$('input.q-in, select.q-in, textarea.q-in', form);
    const next = fields[fields.indexOf(e.target) + 1];
    if (next) next.focus();
  });

  swap(root, h('div.wrap',
    h('div.section-head.reveal', h('span.eyebrow', 'Daily check-in'), h('h2', 'YOUR DAILY HEALTH CHECK-IN'), h('p', 'Tell YHOD about your day and let your AI companion help you understand your health habits.')),
    form, analysis));
  progress();

  const numbers = () => ctx.status?.emergencyNumbers;
  const showFeedback = (feedback, date) => swap(analysis, feedbackView(feedback, date, { numbers: numbers(), onAgain: () => analyse(date, { force: true }) }));

  function steps(stage, notices = []) {
    const step = (i, label) => h(`div.step${stage > i ? '.done' : stage === i ? '.now' : ''}`, h('span.ico', stage > i ? icon('check') : stage === i ? h('span.spinner', { style: { width: '13px', height: '13px' } }) : null), label);
    const emergency = notices.filter((n) => n.level === 'emergency');
    swap(analysis,
      emergency.length ? emergencyCard({ numbers: numbers(), reasons: emergency.map((n) => n.title) }) : null,
      h('div.steps.card', step(1, 'Saving your answers to your account'), step(2, 'Gemini is reading what you entered and writing your feedback'), step(3, 'Updating your dashboard')));
  }

  async function analyse(date, { force = false, notices = [], waitFor = null } = {}) {
    steps(2, notices);
    try {
      const r = await api.post(`/api/checkins/${date}/analysis`, force ? { force: true } : {}, { timeout: 80000 });
      showFeedback(r.feedback, date);
      ctx.bus.dispatchEvent(new CustomEvent('analysis', { detail: { date, dashboard: r.dashboard } }));
      scrollToEl(analysis);
      reveal(analysis);
      if (!r.cached || force) {
        if (waitFor) await waitFor; // let the emergency sentence finish first
        speak(r.feedback.spoken_summary, { source: 'checkin', date }, `fb:${date}:${r.feedback.generatedAt}`, { auto: true });
      }
      return true;
    } catch (e) {
      const emergency = notices.filter((n) => n.level === 'emergency');
      swap(analysis,
        emergency.length ? emergencyCard({ numbers: numbers(), reasons: emergency.map((n) => n.title) }) : null,
        errorNote(e, { title: 'Your answers are saved, but Gemini could not analyse them yet', retry: () => analyse(date, { force, notices }), retryLabel: 'Try the analysis again' }));
      scrollToEl(analysis);
      return false;
    }
  }

  async function run() {
    formErr.replaceChildren();
    for (const r of rows.values()) r.error(null);
    const raw = values();
    const { errors } = normaliseAnswers(raw);
    const bad = Object.keys(errors).filter((k) => k !== '_');
    if (bad.length) {
      for (const id of bad) rows.get(Number(id))?.error(errors[id]);
      const first = rows.get(Number(bad[0]));
      scrollToEl(first.el, 110);
      first.el.querySelector('input, select, textarea, button.q-opt')?.focus({ preventScroll: true });
      return toast(bad.length === 1 ? 'One answer needs another look.' : `${bad.length} answers need another look.`, 'error');
    }
    if (!Object.keys(raw).length) {
      formErr.replaceChildren(h('div.note.warn', icon('info'), h('div', 'Fill in at least one sentence, then submit.')));
      return undefined;
    }
    voice.unlock();
    busy(submit, true, 'Saving and analysing…');
    steps(1);
    scrollToEl(analysis);
    let saved;
    try {
      saved = await api.put('/api/checkins/today', { answers: raw });
    } catch (e) {
      busy(submit, false);
      if (e.info?.fields) for (const [id, msg] of Object.entries(e.info.fields)) rows.get(Number(id))?.error(msg);
      swap(analysis, errorNote(e, { title: 'Your answers could not be saved', retry: run }));
      return undefined; // everything typed is still in the form (and in the draft on this device)
    }
    today = saved.date;
    savedAt = new Date();
    try { localStorage.removeItem(draftKey()); } catch { /* ignore */ }
    state.textContent = `Saved ${savedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    ctx.bus.dispatchEvent(new CustomEvent('checkin', { detail: { date: saved.date, dashboard: saved.dashboard } }));
    let emergencyVoice = null;
    if (saved.notices.some((n) => n.level === 'emergency')) emergencyVoice = speak(EMERGENCY_VOICE_TEXT, { source: 'emergency' }, 'emergency').catch(() => {});
    await analyse(saved.date, { notices: saved.notices, waitFor: emergencyVoice });
    busy(submit, false);
    return undefined;
  }

  // load today's saved check-in (if any) and any draft kept on this device
  (async () => {
    try {
      const r = await api.get('/api/checkins/today');
      today = r.date;
      let draft = null;
      try { draft = JSON.parse(localStorage.getItem(draftKey()) || 'null'); } catch { draft = null; }
      const source = draft?.values && Object.keys(draft.values).length ? draft.values : r.checkin?.answers;
      if (source) for (const [id, v] of Object.entries(source)) rows.get(Number(id))?.set(v);
      progress();
      if (r.checkin) {
        state.textContent = draft ? 'Unsaved changes on this device' : `Saved today ${new Date(r.checkin.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        if (r.checkin.feedback) showFeedback(r.checkin.feedback, r.date);
        else swap(analysis, h('div.note', icon('info'), h('div', { style: { flex: '1' } }, h('strong', "Today's answers are saved, but they have not been analysed yet."), h('div', { style: { marginTop: '10px' } }, h('button.btn.btn-sm.btn-primary', { type: 'button', onclick: () => analyse(r.date) }, icon('sparkle'), 'Analyse with Gemini')))));
      } else if (draft) state.textContent = 'Draft kept on this device';
      // keep the old-day drafts from piling up
      try { for (const k of Object.keys(localStorage)) if (k.startsWith(`yhod.draft.${ctx.user.id}.`) && k !== draftKey()) localStorage.removeItem(k); } catch { /* ignore */ }
    } catch (e) {
      formErr.replaceChildren(errorNote(e, { title: "Today's saved check-in could not be loaded" }));
    }
  })();

  ctx.bus.addEventListener('records', async () => { // a record was deleted elsewhere
    try { const r = await api.get('/api/checkins/today'); if (!r.checkin) { analysis.replaceChildren(); state.textContent = ''; } } catch { /* ignore */ }
  });
  ctx.bus.addEventListener('targets', () => {});
}
