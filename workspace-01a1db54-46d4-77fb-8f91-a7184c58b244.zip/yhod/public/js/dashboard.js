// YHOD — the health dashboard. Every number shown here is computed on the server
// from the check-ins saved in the person's account (nothing is sample data).
import { h, icon, swap, busy, toast, num, fmtDate, fmtShort, parseDate, errorNote, reveal, scrollToEl, fmtDateTime, AI_MODEL_LABEL, prefersReducedMotion } from './dom.js';
import { api } from './api.js';
import { voice, speak } from './voice.js';

const SVG = 'http://www.w3.org/2000/svg';
let gid = 0;
const svg = (tag, attrs = {}, ...kids) => { const el = document.createElementNS(SVG, tag); for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v); el.append(...kids); return el; };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const shift = (s, n) => { const d = parseDate(s); d.setDate(d.getDate() + n); return iso(d); };
const yn = (v) => (v === true ? 'Yes' : v === false ? 'No' : '—');
const known = (v) => v !== null && v !== undefined;

function ring(pct, { from = '#00D9FF', to = '#2F7BFF', label, sub }) {
  const id = `rg${++gid}`;
  const r = 62;
  const c = 2 * Math.PI * r;
  const shown = known(pct) ? Math.max(0, Math.min(100, pct)) : 0;
  const val = svg('circle', { class: 'val', cx: 74, cy: 74, r, stroke: `url(#${id})`, 'stroke-dasharray': c.toFixed(1), 'stroke-dashoffset': c.toFixed(1) });
  const el = h('div.ring', { role: 'img', 'aria-label': `${label}: ${known(pct) ? pct + ' percent of target' : 'not recorded'}` });
  el.append(
    svg('svg', { viewBox: '0 0 148 148' }, svg('defs', {}, svg('linearGradient', { id, x1: '0', y1: '0', x2: '1', y2: '1' }, svg('stop', { offset: '0', 'stop-color': from }), svg('stop', { offset: '1', 'stop-color': to }))), svg('circle', { class: 'track', cx: 74, cy: 74, r }), val),
    h('div.ring-mid', known(pct) ? h('b', String(pct), h('sup', '%')) : h('b', { style: { color: 'var(--text-3)' } }, '—'), h('span', sub)),
  );
  const go = () => val.setAttribute('stroke-dashoffset', (c * (1 - shown / 100)).toFixed(1));
  if (prefersReducedMotion()) go(); else requestAnimationFrame(() => requestAnimationFrame(go));
  return el;
}

const bar = (pct, cls = '') => { const i = h('i'); const el = h(`div.bar${cls}${known(pct) && pct >= 100 ? '.done' : ''}`, i); requestAnimationFrame(() => requestAnimationFrame(() => { i.style.width = `${known(pct) ? Math.min(100, pct) : 0}%`; })); return el; };
const fact = (k, v) => h('div.fact', h('span', k), h('b', v));
const pips = (v, max = 5, warm = false) => h(`div.pips${warm ? '.warm' : ''}`, Array.from({ length: max }, (_, i) => h(`i${known(v) && i < v ? '.on' : ''}`)));
const stat = (ic, label, value, unit, extra) => h(`div.stat${known(value) && value !== '—' ? '' : '.na'}`, h('span', icon(ic), label), h('b', known(value) ? [String(value), unit ? h('small', unit) : null] : 'not recorded'), extra || null);

const SERIES = {
  water: { label: 'Water', unit: 'glasses', target: (t) => t.water, get: (d) => d.water },
  sleep: { label: 'Sleep', unit: 'hours', target: (t) => t.sleep, get: (d) => d.sleepHours },
  activity: { label: 'Activity', unit: 'minutes', target: (t) => t.activity, get: (d) => d.activeMinutes },
  steps: { label: 'Steps', unit: 'steps', target: (t) => t.steps, get: (d) => d.steps },
  mood: { label: 'Mood', unit: 'of 5', target: () => null, get: (d) => d.moodScore, max: 5, names: ['', 'Very low', 'Low', 'Okay', 'Good', 'Great'] },
};

function chart(week, key, targets, today) {
  const s = SERIES[key];
  const W = 700, H = 230, padL = 12, padR = 12, top = 30, bottom = 42;
  const vals = week.map((d) => s.get(d));
  const target = s.target(targets);
  const max = s.max || Math.max(target || 0, ...vals.filter(known), 1) * 1.18;
  const slot = (W - padL - padR) / 7;
  const bw = Math.min(54, slot * 0.56);
  const y = (v) => top + (H - top - bottom) * (1 - v / max);
  const id = `cg${++gid}`;
  const root = svg('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': `${s.label} for the last seven days: ${week.map((d, i) => `${fmtShort(d.date)} ${known(vals[i]) ? vals[i] + ' ' + s.unit : 'not recorded'}`).join(', ')}` });
  root.append(svg('defs', {}, svg('linearGradient', { id, x1: '0', y1: '0', x2: '0', y2: '1' }, svg('stop', { offset: '0', 'stop-color': '#00D9FF' }), svg('stop', { offset: '1', 'stop-color': '#8B5CF6', 'stop-opacity': '.75' })), svg('linearGradient', { id: id + 'd', x1: '0', y1: '0', x2: '0', y2: '1' }, svg('stop', { offset: '0', 'stop-color': '#3CE6A6' }), svg('stop', { offset: '1', 'stop-color': '#00D9FF', 'stop-opacity': '.7' }))));
  for (let g = 0; g <= 3; g++) { const gy = top + ((H - top - bottom) * g) / 3; root.append(svg('line', { x1: padL, x2: W - padR, y1: gy, y2: gy, stroke: 'rgba(255,255,255,.06)', 'stroke-width': 1 })); }
  if (target) {
    root.append(svg('line', { x1: padL, x2: W - padR, y1: y(target), y2: y(target), stroke: 'rgba(255,255,255,.42)', 'stroke-width': 1.2, 'stroke-dasharray': '5 6' }));
    const t = svg('text', { x: W - padR, y: y(target) - 7, 'text-anchor': 'end' }); t.textContent = `your target ${num(target)}`; root.append(t);
  }
  week.forEach((d, i) => {
    const cx = padL + slot * i + slot / 2;
    const v = vals[i];
    const date = parseDate(d.date);
    const lab = svg('text', { x: cx, y: H - 22, 'text-anchor': 'middle' }); lab.textContent = date.toLocaleDateString(undefined, { weekday: 'short' }).toUpperCase();
    const lab2 = svg('text', { x: cx, y: H - 7, 'text-anchor': 'middle', style: d.date === today ? 'fill:#00D9FF' : '' }); lab2.textContent = String(date.getDate());
    root.append(lab, lab2);
    if (!known(v)) {
      root.append(svg('rect', { x: cx - bw / 2, y: H - bottom - 8, width: bw, height: 8, rx: 4, fill: 'rgba(255,255,255,.07)' }));
      return;
    }
    const hgt = Math.max(6, H - bottom - y(v));
    const rect = svg('rect', { class: 'b', x: cx - bw / 2, y: H - bottom, width: bw, height: 0, rx: Math.min(10, bw / 2), fill: `url(#${target && v >= target ? id + 'd' : id})` });
    const txt = svg('text', { class: 'val-label', x: cx, y: H - bottom - hgt - 8, 'text-anchor': 'middle' }); txt.textContent = s.names ? s.names[v] : num(v);
    root.append(rect, txt);
    const go = () => { rect.setAttribute('y', H - bottom - hgt); rect.setAttribute('height', hgt); };
    if (prefersReducedMotion()) go(); else requestAnimationFrame(() => requestAnimationFrame(go));
  });
  return h('div.chart', root);
}

export function mountDashboard(root, ctx) {
  const body = h('div');
  const top = h('div.dash-top');
  swap(root, h('div.wrap',
    h('div.section-head.reveal', h('span.eyebrow.violet', 'Dashboard'), h('h2', 'YOUR HEALTH DASHBOARD'), h('p', 'Built only from the answers you saved. Pick a day to look back at any earlier record.')),
    top, body));
  let data = null;
  let comparison = null;
  let canCompare = false;
  let chartKey = 'water';
  let selected = null;

  function paintTop() {
    const today = data.today;
    const days = [];
    for (let i = 13; i >= 0; i--) days.push(shift(today, -i));
    const strip = h('div.days', { role: 'tablist', 'aria-label': 'Choose a day' }, days.map((d) => {
      const dt = parseDate(d);
      return h(`button.day${data.availableDates.includes(d) ? '.has' : ''}${d === data.date ? '.is-active' : ''}`, { type: 'button', role: 'tab', 'aria-selected': String(d === data.date), 'aria-label': `${fmtDate(d)}${data.availableDates.includes(d) ? ', check-in saved' : ', no check-in'}`, onclick: () => load(d) },
        h('small', d === today ? 'Today' : dt.toLocaleDateString(undefined, { weekday: 'short' })), h('b', String(dt.getDate())), h('i'));
    }));
    swap(top, strip,
      h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => ctx.openRecords('checkins') }, icon('folder'), 'All records'),
      h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => ctx.openTargets() }, icon('target'), 'My targets'));
    requestAnimationFrame(() => { const a = strip.querySelector('.is-active'); if (a) strip.scrollLeft = a.offsetLeft - strip.clientWidth + a.clientWidth + 60; });
  }

  function infoCards() {
    const f = data.feedback;
    const cards = [];
    const info = (accent, ic, title, content, span = 'c4') => h(`div.info.card.${span}.wide-md`, { style: { '--accent': accent } }, h('h4', icon(ic), title), content);
    if (f) {
      cards.push(info('var(--ok)', 'check', 'What you are doing right', h('ul', f.doing_right.slice(0, 4).map((x) => h('li', x)))));
      cards.push(info('#B79CFF', 'trend', 'What to improve', h('ul', f.improve.slice(0, 4).map((x) => h('li', x)))));
      cards.push(info('var(--warn)', 'alert', 'Be careful about', h('ul', [...(f.notices || []).map((n) => n.title), ...f.be_careful].slice(0, 4).map((x) => h('li', x)))));
      cards.push(info('var(--cyan)', 'heart', 'Your health message', [h('p', f.personal_message), h('div.fb-actions', { style: { marginTop: '4px' } },
        h('button.btn.btn-sm', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(f.spoken_summary, { source: 'checkin', date: data.date }, `fb:${data.date}:${f.generatedAt}`); } }, icon('volume'), 'Listen'),
        h('span.ai-tag', icon('sparkle'), `${AI_MODEL_LABEL(f.model)} · ${fmtDateTime(f.generatedAt)}`))], 'c6'));
    } else if (data.hasCheckin) {
      const btn = h('button.btn.btn-sm.btn-primary', { type: 'button', onclick: async () => {
        busy(btn, true, 'Gemini is analysing…');
        try { const r = await api.post(`/api/checkins/${data.date}/analysis`, {}, { timeout: 80000 }); data = r.dashboard; paint(); ctx.bus.dispatchEvent(new CustomEvent('analysis-elsewhere')); }
        catch (e) { busy(btn, false); holder.replaceChildren(errorNote(e, { title: 'Gemini could not analyse this day' })); }
      } }, icon('sparkle'), 'Analyse this day with Gemini');
      const holder = h('div');
      cards.push(info('var(--cyan)', 'sparkle', 'AI feedback', [h('p', 'The answers for this day are saved, but they have not been analysed yet.'), h('div', btn), holder], 'c6'));
    }
    // trends: Gemini compares the saved days
    const trend = h('div');
    const paintTrend = (err) => {
      if (comparison) {
        const c = comparison;
        const block = (title, items) => (items.length ? [h('p.faint', { style: { fontSize: '11px', letterSpacing: '.12em', textTransform: 'uppercase', marginTop: '6px' } }, title), h('ul', items.map((x) => h('li', x)))] : null);
        swap(trend, h('p', c.overview), block('Improving', c.improving), block('Slipping', c.declining), block('Steady', c.steady),
          h('p', { style: { marginTop: '6px' } }, h('strong', { style: { color: '#fff' } }, 'Focus: '), c.focus),
          h('div.fb-actions', { style: { marginTop: '6px' } },
            h('button.btn.btn-sm', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(c.spoken_summary, { source: 'compare' }, `cmp:${c.generatedAt}`); } }, icon('volume'), 'Listen'),
            h('span.ai-tag', icon('sparkle'), `${AI_MODEL_LABEL(c.model)} · ${c.days} days · ${fmtShort(c.from)} – ${fmtShort(c.to)}`)));
        return;
      }
      const btn = h('button.btn.btn-sm.btn-primary', { type: 'button', disabled: !canCompare, onclick: async () => {
        busy(btn, true, 'Gemini is comparing your days…');
        try { comparison = (await api.post('/api/history/compare', {}, { timeout: 80000 })).comparison; paintTrend(); voice.unlock(); speak(comparison.spoken_summary, { source: 'compare' }, `cmp:${comparison.generatedAt}`, { auto: true }); }
        catch (e) { paintTrend(e); }
      } }, icon('sparkle'), 'Compare my recent days');
      swap(trend, h('p', canCompare ? 'Let Gemini compare your saved check-ins and tell you what is improving, what is slipping and what to focus on.' : 'After two days of check-ins, Gemini can compare them and show you how your habits are changing.'), h('div', btn), err ? errorNote(err, { title: 'The comparison could not be made' }) : null);
    };
    paintTrend();
    cards.push(info('var(--cyan)', 'trend', 'Health history comparison', trend, f ? 'c6' : data.hasCheckin ? 'c6' : 'c12'));
    return cards;
  }

  function paint() {
    paintTop();
    const t = data.targets;
    const m = data.metrics;
    if (!data.consistency.totalCheckins) {
      swap(body, h('div.empty.card.glow', h('div.orb', icon('chart')), h('h3', 'Your dashboard appears after your first check-in'), h('p', 'Fill in today’s sentences and submit them. YHOD will analyse your day with Gemini and build this dashboard from your answers.'), h('button.btn.btn-primary', { type: 'button', onclick: () => ctx.go('checkin') }, icon('form'), 'Go to my daily check-in')));
      return;
    }
    const tiles = [];
    const head = (ic, title, right) => h('div.tile-head', h('h3', icon(ic), title), right || null);
    const H = (habitKey) => data.habits.find((x) => x.key === habitKey) || {};

    if (!m) {
      tiles.push(h('div.empty.card.c12', { style: { padding: '34px 20px' } }, h('div.orb', icon('calendar')), h('h3', `No check-in on ${fmtDate(data.date)}`), h('p', data.isToday ? 'You have not submitted today’s check-in yet.' : 'Nothing was saved for this day. Choose a day with a dot to see its record.'), data.isToday ? h('button.btn.btn-primary', { type: 'button', onclick: () => ctx.go('checkin') }, icon('form'), 'Fill in today’s check-in') : null));
    } else {
      // water
      const w = H('water');
      const left = known(m.water) ? t.water - m.water : null;
      tiles.push(h('div.tile.card.glow.c4', head('drop', 'Water intake', h('span.chip.cyan', `target ${t.water}`)),
        h('div.ring-wrap', ring(w.pct, { label: 'Water intake', sub: 'of target' }),
          h('div.facts', h('div.big', known(m.water) ? num(m.water) : '—', h('small', `/ ${t.water} glasses`)),
            h('p.muted', { style: { fontSize: '13.5px' } }, !known(m.water) ? 'Water was not recorded for this day.' : left > 0 ? `${num(left)} more ${left === 1 ? 'glass' : 'glasses'} to reach your target.` : 'You reached your water target.'),
            fact('Other fluids', known(m.otherFluids) ? `${num(m.otherFluids)} glasses` : '—'), fact('Sugary drinks', known(m.sugaryDrinks) ? num(m.sugaryDrinks) : '—')))));
      // sleep
      const s = H('sleep');
      tiles.push(h('div.tile.card.c4', head('moon', 'Sleep duration', h('span.chip.violet', `target ${t.sleep} h`)),
        h('div.big', known(m.sleepHours) ? num(m.sleepHours, 2) : '—', h('small', known(m.sleepHours) ? `hours${m.sleepFromTimes ? ' (from your bed and wake times)' : ''}` : 'not recorded')),
        bar(s.pct, '.violet'),
        m.bedtime || m.wakeTime ? h('div.sleep-arc', h('span', m.bedtime || '—'), h('span.line'), h('span', m.wakeTime || '—')) : null,
        h('div.facts', fact('Sleep quality', m.sleepQuality || '—'), fact('Woke up at night', known(m.nightWakings) ? `${num(m.nightWakings)} ${m.nightWakings === 1 ? 'time' : 'times'}` : '—'), fact('Felt rested', yn(m.rested)), fact('Nap', known(m.napMinutes) ? `${num(m.napMinutes)} min` : '—'))));
      // activity
      const a = H('activity');
      const st = H('steps');
      tiles.push(h('div.tile.card.c4', head('run', 'Physical activity', h('span.chip.cyan', `target ${t.activity} min`)),
        h('div.ring-wrap', ring(a.pct, { from: '#8B5CF6', to: '#00D9FF', label: 'Physical activity', sub: 'of target' }),
          h('div.facts', h('div.big', known(m.activeMinutes) ? num(m.activeMinutes) : '—', h('small', 'active min')),
            fact('Walking', known(m.walkMinutes) ? `${num(m.walkMinutes)} min` : '—'), fact('Exercise', known(m.exerciseMinutes) ? `${num(m.exerciseMinutes)} min` : '—'), fact('Stretching', known(m.stretchMinutes) ? `${num(m.stretchMinutes)} min` : '—'),
            fact('Steps', known(m.steps) ? `${num(m.steps)}${known(st.pct) ? ` · ${st.pct}%` : ''}` : '—')))));
      // daily statistics
      const temp = m.temperature ? `${m.temperature.value}` : null;
      tiles.push(h('div.tile.card.c8', head('pulse', 'Daily health statistics', h('span.faint', { style: { fontSize: '12px' } }, `${m.answered} of 60 sentences answered`)),
        h('div.stats',
          stat('food', 'Meals', m.meals), stat('heart', 'Fruit & vegetables', m.fruitVeg, 'servings'), stat('smile', 'Mood', m.mood), stat('thermo', 'Temperature', temp, m.temperature ? `°${m.temperature.unit}` : ''),
          stat('bolt', 'Stress', m.stress, '/ 5', pips(m.stress, 5, true)), stat('spark', 'Energy', m.energy, '/ 5', pips(m.energy)), stat('focus', 'Concentration', m.concentration, '/ 5', pips(m.concentration)), stat('pulse', 'Symptoms', m.symptomsAnswered ? m.symptoms.length : null, m.symptomsAnswered ? 'reported' : ''),
          stat('chair', 'Sitting', m.sittingHours, 'h'), stat('sun', 'Outdoors', m.outdoorMinutes, 'min'), stat('screen', 'Screens before sleep', m.screenMinutes, 'min'), stat('moon', 'Relaxation', m.relaxMinutes, 'min')),
        m.symptoms.length ? h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '7px' } }, m.symptoms.map((x) => h('span.chip.warn', x)), known(m.severity) ? h('span.chip', `severity ${m.severity}/10`) : null, m.trend ? h('span.chip', m.trend.toLowerCase()) : null) : null));
      // habit progress
      tiles.push(h('div.tile.card.c4', head('target', 'Habit progress'),
        h('div.habits', data.habits.map((x) => h('div.habit', h('div.habit-top', h('span', x.label), h('b', known(x.value) ? `${num(x.value, 2)} ` : '— ', h('em', `/ ${num(x.target)} ${x.unit}`))), bar(x.pct))))));
    }

    // weekly charts
    const chartHolder = h('div');
    const tabs = h('div.chart-tabs', { role: 'tablist', 'aria-label': 'Weekly chart' });
    const paintChart = () => {
      swap(tabs, Object.entries(SERIES).map(([k, v]) => h(`button.chip${k === chartKey ? '.is-active' : ''}`, { type: 'button', role: 'tab', 'aria-selected': String(k === chartKey), onclick: () => { chartKey = k; paintChart(); } }, v.label)));
      swap(chartHolder, chart(data.week, chartKey, t, data.today));
    };
    paintChart();
    tiles.push(h('div.tile.card.c8', head('chart', 'Weekly charts', h('span.faint', { style: { fontSize: '12px' } }, `${fmtShort(data.week[0].date)} – ${fmtShort(data.week[6].date)}`)), tabs, chartHolder));

    // seven-day consistency
    const c = data.consistency;
    tiles.push(h('div.tile.card.c4', head('flame', 'Seven-day consistency', h('span.chip.cyan', `${c.doneThisWeek} of 7`)),
      h('div.week', { role: 'img', 'aria-label': `Check-ins completed on ${c.doneThisWeek} of these seven days` }, c.days.map((d) => h(`div.wd${d.done ? '.done' : ''}${d.date === data.today ? '.today' : ''}`, h('small', parseDate(d.date).toLocaleDateString(undefined, { weekday: 'short' }).slice(0, 2)), h('i', icon('check'))))),
      h('div.streaks', h('div', h('b', String(c.streak)), h('span', 'day streak')), h('div', h('b', String(c.bestStreak)), h('span', 'best streak')), h('div', h('b', String(c.totalCheckins)), h('span', 'check-ins')))));

    tiles.push(...infoCards());
    swap(body, h('div.dash', tiles));
  }

  async function load(date) {
    selected = date || null;
    try {
      const r = await api.get(`/api/dashboard${date ? `?date=${date}` : ''}`);
      data = r.dashboard; comparison = r.comparison; canCompare = r.canCompare;
      paint();
    } catch (e) {
      swap(body, errorNote(e, { title: 'Your dashboard could not be loaded', retry: () => load(date) }));
    }
  }

  const refresh = (e) => {
    if (e?.detail?.dashboard) { data = e.detail.dashboard; canCompare = data.consistency.totalCheckins >= 2; comparison = null; paint(); api.get(`/api/dashboard?date=${data.date}`).then((r) => { comparison = r.comparison; canCompare = r.canCompare; if (comparison) paint(); }).catch(() => {}); } else load(selected);
  };
  ctx.bus.addEventListener('checkin', refresh);
  ctx.bus.addEventListener('analysis', refresh);
  ctx.bus.addEventListener('targets', () => load(selected));
  ctx.bus.addEventListener('records', () => load(null));
  ctx.showDay = (date) => { load(date); scrollToEl(root); };
  load(null).then(() => reveal(root));
}
