// YHOD — small DOM toolkit: element builder, icons, toasts, modals, formatting.

/** h('div.card.glow', { onclick }, child, 'text', [more]) */
export function h(spec, ...rest) {
  let attrs = {};
  if (rest.length && rest[0] && typeof rest[0] === 'object' && !(rest[0] instanceof Node) && !Array.isArray(rest[0])) attrs = rest.shift();
  // "tag#id.class.class" — the #id and the .classes may come in any order
  const parts = String(spec).match(/[#.]?[^#.]+/g) || [];
  const tag = parts.length && !/^[#.]/.test(parts[0]) ? parts[0] : 'div';
  const el = document.createElement(tag);
  const classes = [];
  for (const part of parts) { if (part[0] === '#') el.id = part.slice(1); else if (part[0] === '.') classes.push(part.slice(1)); }
  if (classes.length) el.className = classes.join(' ');
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = (el.className ? el.className + ' ' : '') + v;
    else if (k === 'style' && typeof v === 'object') { for (const [prop, val] of Object.entries(v)) { if (prop.startsWith('--')) el.style.setProperty(prop, val); else el.style[prop] = val; } }
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k === 'html') el.innerHTML = v; // only ever used with trusted, static markup (icons)
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k in el && !['list', 'form', 'type'].includes(k) && typeof v !== 'string') el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  add(el, rest);
  return el;
}
/** Like el.append(), but skips null / undefined / false and flattens arrays. */
export function append(el, ...kids) { add(el, kids); return el; }
function add(el, kids) {
  for (const k of kids) {
    if (k === null || k === undefined || k === false) continue;
    if (Array.isArray(k)) add(el, k);
    else el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function swap(el, ...kids) { clear(el); add(el, kids); return el; }

// ── icons (inline SVG, 24px grid, stroke) ───────────────────────────
const P = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
  drop: '<path d="M12 3s6.5 6.6 6.5 11.2A6.5 6.5 0 0 1 12 20.7a6.5 6.5 0 0 1-6.5-6.5C5.5 9.6 12 3 12 3z"/>',
  run: '<circle cx="14.5" cy="4.5" r="2"/><path d="m7 21 3-6 3 2.5V21"/><path d="m5.5 12 2.5-4 4-1 3.5 3.5 3 1"/><path d="m12 7-2 5.5 3 2"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/>',
  pulse: '<path d="M3 12h4l2.5-6 4 12 2.5-6H21"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  alert: '<path d="M12 3.5 2.5 20h19L12 3.5z"/><path d="M12 10v4.5M12 17.4v.1"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.6v.1"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7"/>',
  micOff: '<path d="M9 9v2a3 3 0 0 0 5.1 2.1M15 10.5V6a3 3 0 0 0-5.7-1.3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 10.9 4.8M18.5 11.5c0 .9-.2 1.8-.5 2.6M12 18v3M8.5 21h7M3 3l18 18"/>',
  send: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  arrowUp: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  camera: '<path d="M4 8h3l1.7-2.5h6.6L17 8h3a1 1 0 0 1 1 1v9.5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.6"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4.5 15.5v3a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5v-3"/>',
  image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="m4 17 5-4.5 4 3.5 3-2.5 4.5 4"/>',
  replay: '<path d="M4 12a8 8 0 1 0 2.6-5.9"/><path d="M4 4.5V9h4.5"/>',
  volume: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
  mute: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>',
  chat: '<path d="M20 12.2A7.6 7.6 0 0 1 8.6 18.8L4 20l1.3-4.3A7.6 7.6 0 1 1 20 12.2z"/>',
  chevron: '<path d="m9 6 6 6-6 6"/>',
  chevronL: '<path d="m15 6-6 6 6 6"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
  logout: '<path d="M14 4.5h4.5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H14M10 8l-4 4 4 4M6 12h10"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r=".8"/>',
  trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l.8 12a1.5 1.5 0 0 0 1.5 1.4h6.4a1.5 1.5 0 0 0 1.5-1.4l.8-12M10 11v5.5M14 11v5.5"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4.5 20h15"/>',
  shield: '<path d="M12 3 4.5 6v5.5c0 4.6 3.2 8 7.5 9.5 4.3-1.500 7.5-4.9 7.500-9.5V6L12 3z"/><path d="m9 12 2.200 2.200 4-4.400"/>',
  clock: '<circle cx="12" cy="12" r="8.500"/><path d="M12 7.500V12l3 2"/>',
  play: '<path d="M7.500 5.500v13l11-6.500-11-6.500z"/>',
  stop: '<rect x="6.500" y="6.500" width="11" height="11" rx="2"/>',
  flame: '<path d="M12 21a6 6 0 0 0 6-6c0-3-2-4.500-3-7-1 1.500-1.500 2.500-3 3 .500-3-1-5.500-3-7 .200 3-3 5.500-3 11a6 6 0 0 0 6 6z"/>',
  stethoscope: '<path d="M6 3.500v5a4 4 0 0 0 8 0v-5M10 12.500v2a5 5 0 0 0 10 0V13"/><circle cx="20" cy="11" r="2"/>',
  pill: '<rect x="3" y="8.500" width="18" height="7" rx="3.500" transform="rotate(-45 12 12)"/><path d="m9.500 9.500 5 5"/>',
  eye: '<path d="M2.500 12S6 5.500 12 5.500 21.500 12 21.500 12 18 18.500 12 18.500 2.500 12 2.500 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M4 4l16 16M9.900 5.800A9 9 0 0 1 12 5.500c6 0 9.500 6.500 9.500 6.500a15 15 0 0 1-2.600 3.300M6.300 7.400A15 15 0 0 0 2.500 12S6 18.500 12 18.500a9 9 0 0 0 3.500-.700M9.900 9.900a3 3 0 0 0 4.200 4.200"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.600-5.900"/><path d="M20 4.500V9h-4.500"/>',
  phone: '<path d="M5 4h4l1.500 4.500-2.300 1.500a12 12 0 0 0 5.800 5.800l1.500-2.300L20 15v4a1 1 0 0 1-1 1A15 15 0 0 1 4 5a1 1 0 0 1 1-1z"/>',
  lock: '<rect x="5" y="10.500" width="14" height="10" rx="2.500"/><path d="M8 10.500V8a4 4 0 0 1 8 0v2.500"/>',
  home: '<path d="m4 11 8-7 8 7v8.500a1 1 0 0 1-1 1h-4.500V14h-5v6.500H5a1 1 0 0 1-1-1V11z"/>',
  form: '<rect x="5" y="3.500" width="14" height="17" rx="2.500"/><path d="M9 8.500h6M9 12.500h6M9 16.500h3.500"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M21 20H3"/>',
  heart: '<path d="M12 20s-7.500-4.600-7.500-10.200A4.300 4.300 0 0 1 12 7.300a4.300 4.300 0 0 1 7.500 2.500C19.500 15.400 12 20 12 20z"/>',
  folder: '<path d="M3.500 7a1.500 1.500 0 0 1 1.500-1.500h4.500l2 2.500H19a1.500 1.500 0 0 1 1.500 1.500v8A1.500 1.500 0 0 1 19 19H5a1.500 1.500 0 0 1-1.500-1.500V7z"/>',
  sparkle: '<path d="M12 3.500 13.800 9l5.700 1.800-5.700 1.800L12 18l-1.800-5.400L4.500 10.800 10.200 9 12 3.500z"/><path d="M19 16.500l.700 1.800 1.800.700-1.800.700-.700 1.800-.700-1.800-1.800-.700 1.800-.700.700-1.800z"/>',
  thermo: '<path d="M10 14V5.500a2 2 0 0 1 4 0V14a4 4 0 1 1-4 0z"/><path d="M12 9v7.500"/>',
  food: '<path d="M7 3.500v7.500a2 2 0 0 0 4 0V3.500M9 11v9.500M17 3.500c-1.700 1.500-2.500 3.800-2.500 6.500v2.500H17v8"/>',
  steps: '<path d="M8.500 15.500c-1.700 0-2.500-1.800-2.500-4.500S7 5 8.500 5 11 7 11 10.500s-.800 5-2.500 5zM6.500 18.500h4M15.500 12.500c-1.700 0-2.500-1.800-2.500-4.500S14 2.500 15.500 2.500 18 4.500 18 8s-.800 4.500-2.500 4.500zM13.500 15.500h4"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.500v2.500M12 19v2.500M2.500 12H5M19 12h2.500M5.300 5.300 7 7M17 17l1.700 1.700M18.700 5.300 17 7M7 17l-1.700 1.700"/>',
  screen: '<rect x="3.500" y="5" width="17" height="11.500" rx="2"/><path d="M9 20h6M12 16.500V20"/>',
  chair: '<path d="M7 4v9h10V4M5 13h14v3H5zM7 16v4.500M17 16v4.500"/>',
  smile: '<circle cx="12" cy="12" r="8.500"/><path d="M8.500 14.500a4.500 4.500 0 0 0 7 0M9 9.800v.1M15 9.800v.1"/>',
  bolt: '<path d="M13 3 5 13.500h6L10.500 21l8-10.500h-6L13 3z"/>',
  focus: '<path d="M4 9V5.500A1.500 1.500 0 0 1 5.500 4H9M15 4h3.500A1.500 1.500 0 0 1 20 5.500V9M20 15v3.500a1.500 1.500 0 0 1-1.500 1.500H15M9 20H5.500A1.500 1.500 0 0 1 4 18.500V15"/><circle cx="12" cy="12" r="2.500"/>',
  swap: '<path d="M4 8h13M13 4l4 4-4 4M20 16H7M11 12l-4 4 4 4"/>',
  external: '<path d="M14 4.500h5.500V10M19.500 4.500 11 13M17 14v4.500a1 1 0 0 1-1 1H5.500a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1H10"/>',
  trend: '<path d="m3.500 16.500 5.500-5.500 4 4 7.500-8"/><path d="M15 7h5.500v5.500"/>',
};
export function icon(name, attrs = {}) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  el.setAttribute('viewBox', '0 0 24 24');
  el.setAttribute('fill', 'none');
  el.setAttribute('stroke', 'currentColor');
  el.setAttribute('stroke-width', attrs.stroke || '1.700');
  el.setAttribute('stroke-linecap', 'round');
  el.setAttribute('stroke-linejoin', 'round');
  el.setAttribute('aria-hidden', 'true');
  if (attrs.class) el.setAttribute('class', attrs.class);
  el.innerHTML = P[name] || P.info;
  return el;
}

// ── toasts ──────────────────────────────────────────────────────────
let toastHost = null;
export function toast(message, kind = 'info', ms = 4600) {
  if (!toastHost) { toastHost = h('div.toasts', { role: 'status', 'aria-live': 'polite' }); document.body.append(toastHost); }
  const el = h(`div.toast.${kind}`, icon(kind === 'error' ? 'alert' : kind === 'ok' ? 'check' : 'info'), h('div', message));
  toastHost.append(el);
  const close = () => { el.classList.add('is-out'); setTimeout(() => el.remove(), 300); };
  setTimeout(close, ms);
  el.addEventListener('click', close);
}

// ── modal ───────────────────────────────────────────────────────────
const openModals = [];
/** openModal({ title, body, actions, wide, onClose }) → { el, close } */
export function openModal({ title, body, actions, wide = false, cls = '', onClose, dismissable = true } = {}) {
  const previous = document.activeElement;
  const modal = h(`div.modal${wide ? '.wide' : ''}${cls ? '.' + cls : ''}`, { role: 'dialog', 'aria-modal': 'true', 'aria-label': title || 'Dialog', tabindex: '-1' });
  const overlay = h('div.overlay', modal);
  let closed = false;
  const close = (result) => {
    if (closed) return;
    closed = true;
    overlay.classList.add('is-out');
    document.removeEventListener('keydown', onKey, true);
    const i = openModals.indexOf(api); if (i >= 0) openModals.splice(i, 1);
    if (!openModals.length) document.body.classList.remove('is-locked');
    setTimeout(() => overlay.remove(), 200);
    if (previous && previous.focus) { try { previous.focus({ preventScroll: true }); } catch { /* ignore */ } }
    if (onClose) onClose(result);
  };
  const onKey = (e) => {
    if (openModals[openModals.length - 1] !== api) return;
    if (e.key === 'Escape' && dismissable) { e.stopPropagation(); close(); }
    if (e.key === 'Tab') {
      const f = $$('button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])', modal).filter((x) => x.offsetParent !== null);
      if (!f.length) return;
      const first = f[0];
      const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  };
  if (title) modal.append(h('h3', title));
  if (dismissable) modal.append(h('button.icon-btn.modal-close', { type: 'button', 'aria-label': 'Close', onclick: () => close() }, icon('x')));
  if (body) modal.append(h('div', { style: { marginTop: title ? '16px' : '0' } }, body));
  if (actions && actions.length) modal.append(h('div.modal-actions', actions));
  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay && dismissable) close(); });
  document.addEventListener('keydown', onKey, true);
  (document.getElementById('overlays') || document.body).append(overlay);
  document.body.classList.add('is-locked');
  const api = { el: modal, overlay, close };
  openModals.push(api);
  requestAnimationFrame(() => { const f = modal.querySelector('[autofocus], input, textarea, select, button.btn-primary'); (f || modal).focus({ preventScroll: true }); });
  return api;
}

/** confirmDialog({title, text, confirm, danger}) → Promise<boolean> */
export function confirmDialog({ title, text, confirm = 'Confirm', cancel = 'Cancel', danger = false }) {
  return new Promise((resolve) => {
    let done = false;
    const m = openModal({
      title,
      body: h('p.muted', { style: { lineHeight: '1.6' } }, text),
      actions: [
        h('button.btn.btn-ghost', { type: 'button', onclick: () => m.close() }, cancel),
        h(`button.btn.${danger ? 'btn-danger' : 'btn-primary'}`, { type: 'button', onclick: () => { done = true; resolve(true); m.close(); } }, confirm),
      ],
      onClose: () => { if (!done) resolve(false); },
    });
  });
}

/** A note describing a failed request, including the real error details from Gemini when present. */
export function errorNote(err, { title = 'Something went wrong', retry, retryLabel = 'Try again' } = {}) {
  const e = err?.info || {};
  const detail = e.detail || (e.attempts && e.attempts.length ? e.attempts.map((a) => `${a.model}: ${a.status ? 'HTTP ' + a.status + ' — ' : ''}${a.message}`).join('\n') : '');
  const secs = Number(e.retryAfterSec) || 0;
  const span = secs <= 90 ? `${Math.ceil(secs)} seconds` : secs < 5400 ? `${Math.ceil(secs / 60)} minutes` : `${Math.round(secs / 3600)} hours`;
  // for Gemini's own quota this is the wait Google announces in its refusal, so it is worded as Google's statement
  const wait = !secs ? '' : e.code === 'GEMINI_QUOTA' ? ` Google reports that the free allowance returns in about ${span}.` : ` You can try again in about ${span}.`;
  return h('div.note.danger', { role: 'alert' }, icon('alert'), h('div', { style: { flex: '1', minWidth: '0' } },
    h('strong', title), h('div', { style: { marginTop: '3px' } }, (err?.message || 'Please try again.') + wait),
    detail ? h('details', h('summary', `Technical details${e.code ? ' (' + e.code + ')' : ''}`), h('pre', detail)) : null,
    retry ? h('div', { style: { marginTop: '12px' } }, h('button.btn.btn-sm', { type: 'button', onclick: retry }, icon('refresh'), retryLabel)) : null,
  ));
}

// ── formatting ──────────────────────────────────────────────────────
export const pad2 = (n) => String(n).padStart(2, '0');
export function parseDate(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }
export const fmtDate = (s, opts = { weekday: 'long', day: 'numeric', month: 'long' }) => parseDate(s).toLocaleDateString(undefined, opts);
export const fmtShort = (s) => parseDate(s).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
export const fmtDateTime = (iso) => new Date(iso).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
export const num = (v, digits = 1) => (v === null || v === undefined ? '—' : Number.isInteger(v) ? v.toLocaleString() : Number(v).toLocaleString(undefined, { maximumFractionDigits: digits }));
export const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export const prefersReducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export function scrollToEl(el, offset = 0) {
  if (!el) return;
  const nav = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--nav-h')) || 64;
  const y = el.getBoundingClientRect().top + window.scrollY - nav - 14 - offset;
  window.scrollTo({ top: Math.max(0, y), behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
}
export function busy(btn, on, label) {
  if (!btn) return;
  if (on) {
    if (!btn._kids) btn._kids = [...btn.childNodes];
    btn.classList.add('is-busy');
    btn.setAttribute('aria-busy', 'true');
    swap(btn, h('span.spinner'), label || 'Working…');
  } else if (btn._kids) {
    btn.classList.remove('is-busy');
    btn.removeAttribute('aria-busy');
    swap(btn, btn._kids);
    btn._kids = null;
  }
}
let observer = null;
export function reveal(root = document) {
  if (prefersReducedMotion() || !('IntersectionObserver' in window)) { $$('.reveal', root).forEach((el) => el.classList.add('is-in')); return; }
  if (!observer) observer = new IntersectionObserver((entries) => { for (const e of entries) if (e.isIntersecting) { e.target.classList.add('is-in'); observer.unobserve(e.target); } }, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });
  $$('.reveal:not(.is-in)', root).forEach((el) => observer.observe(el));
}
export const AI_MODEL_LABEL = (m) => (m ? `Gemini · ${m}` : 'Gemini');
