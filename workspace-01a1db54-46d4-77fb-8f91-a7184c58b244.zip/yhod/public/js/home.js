// YHOD — welcome area and the AI microphone assistant
// (replay, mute, text conversation, microphone input).
import { h, icon, swap, toast, fmtDate, errorNote, openModal, AI_MODEL_LABEL } from './dom.js';
import { api } from './api.js';
import { voice, speak } from './voice.js';
import { createMicLogo, setMicState } from './miclogo.js';
import { Recorder, micSupported, mediaErrorText, MAX_SECONDS } from './recorder.js';
import { emergencyCard } from './assessview.js';

export function mountHome(root, ctx) {
  // ── welcome copy ──
  const meta = h('div.hero-meta');
  const title = h('h1', h('span.shimmer', { style: { display: 'block', height: '1.1em', width: '90%' } }, '.'), h('span.shimmer', { style: { display: 'block', height: '1.1em', width: '70%', marginTop: '.3em' } }, '.'));
  const note = h('div.hero-note', { hidden: true });
  const stats = h('div.hero-stats');
  const cta = h('div.hero-cta',
    h('button.btn.btn-primary.btn-lg', { type: 'button', onclick: () => ctx.go('checkin') }, icon('form'), "TODAY'S CHECK-IN"),
    h('button.btn.btn-lg', { type: 'button', onclick: () => ctx.go('start-yhod') }, icon('heart'), 'FEELING UNWELL?'),
  );
  const copy = h('div.hero-copy.reveal', meta, title, note, cta, stats);

  // ── assistant ──
  const logo = createMicLogo({ interactive: true, label: 'Talk to YHOD. Press to start or stop microphone input.' });
  const captions = h('div.captions', { 'aria-live': 'polite' }, h('p.idle', 'Your AI companion is ready.'));
  const foot = h('div.assistant-foot');
  const bReplay = h('button.ctrl', { type: 'button' }, icon('replay'), 'Replay');
  const bMute = h('button.ctrl', { type: 'button' });
  const bChat = h('button.ctrl', { type: 'button' }, icon('chat'), 'Text conversation');
  const bMic = h('button.ctrl', { type: 'button' });
  const panel = h('div.assistant.glass.glow.reveal',
    h('div.assistant-title', h('span.eyebrow', 'AI voice assistant'), h('span.ai-tag', icon('sparkle'), 'Gemini')),
    h('div.assistant-stage', logo),
    captions,
    h('div.controls', { role: 'group', 'aria-label': 'Assistant controls' }, bReplay, bMute, bChat, bMic),
    foot,
  );
  swap(root, h('div.wrap.hero-grid', copy, panel));

  let welcome = null;
  let lastSaid = ''; // the full sentence(s) most recently spoken, shown when idle
  let voiceNote = null;
  let recorder = null;
  let phase = 'idle'; // idle | recording | transcribing | thinking

  const paintMute = () => { swap(bMute, icon(voice.muted ? 'mute' : 'volume'), voice.muted ? 'Unmute' : 'Mute'); bMute.classList.toggle('is-on', voice.muted); bMute.setAttribute('aria-pressed', String(voice.muted)); };
  const paintMic = () => {
    const rec = phase === 'recording';
    swap(bMic, phase === 'transcribing' || phase === 'thinking' ? h('span.spinner') : icon(rec ? 'stop' : 'mic'), rec ? 'Stop and send' : phase === 'transcribing' ? 'Listening…' : phase === 'thinking' ? 'Thinking…' : 'Microphone input');
    bMic.classList.toggle('is-rec', rec);
    bMic.disabled = phase === 'transcribing' || phase === 'thinking';
    setMicState(logo, phase === 'transcribing' || phase === 'thinking' ? 'thinking' : null);
  };
  const paintCaptions = () => {
    if (phase === 'recording') return swap(captions, h('p', 'Listening… speak now, then press the microphone again.'));
    if (phase === 'transcribing') return swap(captions, h('p.idle', 'Gemini is turning your words into text…'));
    if (phase === 'thinking') return swap(captions, h('p.idle', voiceNote || 'YHOD is thinking…'));
    if (voice.caption) {
      const p = captions.firstElementChild;
      if (!p || p.dataset.t !== voice.caption) { const el = h('p', voice.caption); el.dataset.t = voice.caption; swap(captions, el); }
      return undefined;
    }
    if (voice.state === 'loading') return swap(captions, h('p.idle', 'Preparing the voice…'));
    if (voice.error && voice.failed) return swap(captions, h('p.err', `The voice is unavailable right now: ${voice.error.message}`));
    return swap(captions, h('p.idle', voice.muted ? 'Sound is off. Subtitles will appear here.' : lastSaid ? 'Press Replay to hear that again, or talk to YHOD.' : 'Your AI companion is ready.'));
  };
  const paintFoot = () => swap(foot, voice.model ? h('span.ai-tag', icon('volume'), `Voice: ${voice.model}`) : null);
  voice.addEventListener('change', () => { paintMute(); paintCaptions(); paintFoot(); });
  paintMute(); paintMic();

  bReplay.addEventListener('click', async () => {
    voice.unlock();
    if (!voice.last) return toast('There is nothing to replay yet.');
    if (voice.muted) toast('Sound is off, so this is shown as subtitles. Press Unmute to hear it.');
    await voice.replay();
  });
  bMute.addEventListener('click', () => { voice.unlock(); voice.toggleMuted(); });
  bChat.addEventListener('click', () => openChat());

  // ── microphone input ──
  async function toggleMic() {
    if (phase === 'transcribing' || phase === 'thinking') return;
    if (phase === 'recording') return finishRecording();
    if (!micSupported()) return toast('This browser cannot record audio. You can use the text conversation instead.', 'error');
    recorder = new Recorder();
    try {
      await recorder.start({ onAutoStop: () => { toast(`Recording stopped after ${MAX_SECONDS} seconds.`); finishRecording(); } });
      phase = 'recording';
    } catch (e) {
      phase = 'idle';
      toast(mediaErrorText(e, 'microphone'), 'error', 7000);
    }
    paintMic(); paintCaptions();
  }
  async function finishRecording() {
    const rec = recorder.stop();
    if (!rec) { phase = 'idle'; paintMic(); paintCaptions(); return toast('That was too short. Press the microphone, speak, then press it again.'); }
    phase = 'transcribing'; paintMic(); paintCaptions();
    try {
      const t = await api.post('/api/transcribe', { audio: rec.audio });
      if (!t.speechDetected || !t.transcript) { phase = 'idle'; paintMic(); paintCaptions(); return toast('YHOD could not hear any words. Please try again a little closer to the microphone.'); }
      voiceNote = `You said: “${t.transcript}”`;
      phase = 'thinking'; paintMic(); paintCaptions();
      await ask(t.transcript, { viaVoice: true });
    } catch (e) {
      phase = 'idle'; paintMic(); paintCaptions();
      openModal({ title: 'Voice input did not work', body: errorNote(e, { title: 'Gemini could not process the recording' }) });
    }
  }
  bMic.addEventListener('click', toggleMic);
  logo.addEventListener('click', () => { voice.unlock(); toggleMic(); });

  // ── conversation with the assistant (shared by voice and text) ──
  let history = null;
  let drawer = null;
  async function ask(text, { viaVoice = false } = {}) {
    const r = await api.post('/api/assistant/chat', { text });
    const [mine, reply] = r.messages;
    if (history) history.push(mine, reply);
    if (drawer) drawer.append(mine, reply, r.emergency);
    phase = 'idle'; voiceNote = null; paintMic();
    lastSaid = reply.text;
    if (r.emergency && !drawer) openModal({ title: 'This may be an emergency', body: emergencyCard(r.emergency) });
    speak(reply.text, { source: 'message', id: reply.id }, `m:${reply.id}`, { auto: true });
    if (viaVoice && reply.suggestStartYhod) toast('For a guided symptom check, type START YHOD in the START YHOD section.', 'info', 7000);
    return reply;
  }

  async function openChat() {
    if (drawer) return;
    const body = h('div.drawer-body', { role: 'log', 'aria-live': 'polite' });
    const input = h('textarea', { rows: '1', placeholder: 'Ask YHOD about your health habits…', maxlength: '1000', 'aria-label': 'Message to YHOD' });
    const send = h('button.send', { type: 'submit', 'aria-label': 'Send', disabled: true }, icon('arrowUp'));
    const err = h('div');
    const smallMic = createMicLogo({ waves: false, label: 'YHOD' });
    const bubble = (m) => {
      const mine = m.role === 'user';
      const el = h(`div.msg.${mine ? 'me' : 'bot'}${m.emergency ? '.alert' : ''}`, h('div.bubble', m.text));
      if (!mine) {
        el.append(h('div.msg-meta',
          h('button', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(m.text, { source: 'message', id: m.id }, `m:${m.id}`); } }, icon('volume'), 'Listen'),
          m.model ? h('span.ai-tag', AI_MODEL_LABEL(m.model)) : null,
        ));
        if (m.suggestStartYhod) el.append(h('div.quick', h('button', { type: 'button', onclick: () => { close(); ctx.go('start-yhod'); } }, 'Open START YHOD')));
      }
      return el;
    };
    const scroll = () => { body.scrollTop = body.scrollHeight; };
    const empty = () => h('div.empty', { style: { padding: '30px 10px' } }, h('div.orb', icon('chat')), h('h3', 'Talk with YHOD'), h('p', 'Ask about your habits, your saved check-ins, or how to use YHOD. Answers come from Gemini and use your own records.'),
      h('div.quick', { style: { justifyContent: 'center' } }, ['How was my day today?', 'How can I sleep better?', 'What should I focus on this week?'].map((q) => h('button', { type: 'button', onclick: () => submit(q) }, q))));
    const close = () => { if (!drawer) return; wrap.remove(); drawer = null; document.body.classList.remove('is-locked'); document.removeEventListener('keydown', onKey, true); bChat.focus({ preventScroll: true }); };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    let busyNow = false;
    async function submit(text) {
      text = String(text || '').trim();
      if (!text || busyNow) return;
      busyNow = true; send.disabled = true; err.replaceChildren();
      if (body.querySelector('.empty')) body.replaceChildren();
      const pending = h('div.msg.me', h('div.bubble', text));
      const typing = h('div.typing', { 'aria-label': 'YHOD is writing' }, h('i'), h('i'), h('i'));
      body.append(pending, typing); scroll();
      input.value = ''; grow();
      try {
        voice.unlock();
        await ask(text);
        pending.remove();
      } catch (e) {
        pending.remove();
        input.value = text; grow(); // nothing is lost: the message is back in the box
        err.replaceChildren(errorNote(e, { title: 'YHOD could not answer', retry: () => submit(input.value) }));
      }
      typing.remove();
      busyNow = false; send.disabled = !input.value.trim(); scroll();
      input.focus({ preventScroll: true });
    }
    const grow = () => { input.style.height = 'auto'; input.style.height = Math.min(140, input.scrollHeight) + 'px'; };
    input.addEventListener('input', () => { grow(); send.disabled = busyNow || !input.value.trim(); });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(input.value); } });
    const form = h('form.composer', { onsubmit: (e) => { e.preventDefault(); submit(input.value); } }, input, send);
    const clearBtn = h('button.icon-btn', { type: 'button', 'aria-label': 'Clear this conversation', title: 'Clear conversation', onclick: async () => {
      try { await api.del('/api/assistant/history'); history = []; body.replaceChildren(empty()); toast('The conversation was cleared.', 'ok'); } catch (e) { toast(e.message, 'error'); }
    } }, icon('trash'));
    const wrap = h('div.drawer-wrap', { onmousedown: (e) => { if (e.target === wrap) close(); } },
      h('aside.drawer', { role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Text conversation with YHOD' },
        h('div.drawer-head', smallMic, h('div', { style: { flex: '1', minWidth: '0' } }, h('h3', 'Text conversation'), h('p', 'YHOD · answers by Gemini')), clearBtn, h('button.icon-btn', { type: 'button', 'aria-label': 'Close', onclick: close }, icon('x'))),
        body,
        h('div.drawer-foot', err, form, h('span.faint', { style: { fontSize: '11.5px', textAlign: 'center' } }, 'General health information only — not a diagnosis.'))));
    drawer = {
      append(mine, reply, emergency) { body.append(bubble(mine), bubble(reply)); if (emergency) body.append(emergencyCard(emergency)); scroll(); },
    };
    document.getElementById('overlays').append(wrap);
    document.body.classList.add('is-locked');
    document.addEventListener('keydown', onKey, true);
    body.append(h('div.typing', h('i'), h('i'), h('i')));
    try {
      if (!history) history = (await api.get('/api/assistant/history')).messages;
      body.replaceChildren(...(history.length ? history.map(bubble) : [empty()]));
    } catch (e) {
      body.replaceChildren(errorNote(e, { title: 'The conversation could not be loaded' }));
    }
    scroll();
    input.focus({ preventScroll: true });
  }

  // ── welcome message, chosen by the server from the saved visit and check-in dates ──
  function paintWelcome() {
    const s = welcome.stats;
    const name = ctx.user.name;
    const i = welcome.message.indexOf(name);
    swap(title, i >= 0 ? [welcome.message.slice(0, i), h('em', name), welcome.message.slice(i + name.length)] : welcome.message);
    swap(meta,
      h('span.chip.cyan', icon('calendar'), fmtDate(s.today)),
      s.checkinStreak > 0 ? h('span.chip.violet', icon('flame'), `${s.checkinStreak}-day check-in streak`) : null,
      h('span.chip', icon(s.todayCheckinDone ? 'check' : 'clock'), s.todayCheckinDone ? "Today's check-in is done" : "Today's check-in is waiting"),
    );
    swap(stats,
      h('div.hero-stat', h('b', String(s.visitDays)), h('span', s.visitDays === 1 ? 'day with YHOD' : 'days with YHOD')),
      h('div.hero-stat', h('b', String(s.totalCheckins)), h('span', s.totalCheckins === 1 ? 'check-in completed' : 'check-ins completed')),
      h('div.hero-stat', h('b', s.lastCheckin ? fmtDate(s.lastCheckin, { day: 'numeric', month: 'short' }) : '—'), h('span', 'last check-in')),
    );
    cta.firstElementChild.lastChild.textContent = s.todayCheckinDone ? "UPDATE TODAY'S CHECK-IN" : "TODAY'S CHECK-IN";
  }
  function paintNote(n, err) {
    note.hidden = false;
    if (err) return swap(note, h('span.ai-tag', icon('sparkle'), 'Personal note'), h('p.muted', { style: { fontSize: '13.5px' } }, `Gemini could not write your note just now: ${err.message}`), h('div', h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => loadNote(true) }, icon('refresh'), 'Try again')));
    if (!n) return swap(note, h('span.ai-tag', icon('sparkle'), 'Gemini is writing a note for you…'), h('div.shimmer', { style: { width: '96%' } }, '.'), h('div.shimmer', { style: { width: '72%' } }, '.'));
    return swap(note, h('span.ai-tag', icon('sparkle'), `A note for you · ${AI_MODEL_LABEL(n.model)}`), h('p', n.text));
  }
  async function loadNote(force = false) {
    paintNote(null);
    try { paintNote((await api.post('/api/welcome/note', force ? { force: true } : {})).note); } catch (e) { paintNote(null, e); }
  }
  async function loadWelcome({ say = false } = {}) {
    try {
      welcome = await api.post('/api/welcome', {});
      ctx.welcome = welcome;
      paintWelcome();
      if (welcome.note) paintNote(welcome.note); else loadNote();
      if (say) {
        await ctx.introDone; // the personal greeting follows the intro voice
        lastSaid = welcome.message;
        speak(welcome.message, { source: 'welcome' }, `welcome:${welcome.type}:${ctx.user.name}`, { auto: true });
      }
    } catch (e) {
      swap(title, `Welcome to YHOD, ${ctx.user.name}!`);
      note.hidden = false;
      swap(note, errorNote(e, { title: 'Your welcome could not be loaded', retry: () => loadWelcome({ say }) }));
    }
  }
  ctx.bus.addEventListener('checkin', () => loadWelcome());
  ctx.bus.addEventListener('records', () => loadWelcome());
  loadWelcome({ say: true });
  ctx.openChat = openChat;
}
