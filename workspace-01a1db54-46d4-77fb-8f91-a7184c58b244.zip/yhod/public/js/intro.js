// YHOD — cinematic introduction.
// The four words appear one after another (CSS), then ENTER YHOD plays the welcome
// line spoken by Gemini text-to-speech, with subtitles and the animated AI microphone.
import { $, prefersReducedMotion } from './dom.js';
import { api } from './api.js';
import { voice } from './voice.js';
import { createMicLogo, disposeMicLogo } from './miclogo.js';
import { INTRO_VOICE_TEXT } from '../shared/copy.js';

function stars(canvas) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return () => {};
  let w = 0, h = 0, raf = 0, running = true;
  const dots = Array.from({ length: 110 }, () => ({ x: Math.random(), y: Math.random(), r: Math.random() * 1.3 + 0.25, p: Math.random() * Math.PI * 2, s: 0.4 + Math.random() * 1.1, v: (Math.random() - 0.5) * 0.004, c: Math.random() < 0.3 ? '139,92,246' : Math.random() < 0.6 ? '0,217,255' : '255,255,255' }));
  const resize = () => { const d = Math.min(window.devicePixelRatio || 1, 2); w = canvas.width = Math.round(innerWidth * d); h = canvas.height = Math.round(innerHeight * d); };
  resize();
  addEventListener('resize', resize);
  const still = prefersReducedMotion();
  const frame = (t) => {
    if (!running) return;
    ctx.clearRect(0, 0, w, h);
    for (const d of dots) {
      if (!still) { d.y += d.v * 0.016; if (d.y < 0) d.y = 1; if (d.y > 1) d.y = 0; }
      const a = still ? 0.6 : 0.25 + 0.75 * (0.5 + 0.5 * Math.sin(t / 1000 * d.s + d.p));
      ctx.fillStyle = `rgba(${d.c},${a.toFixed(3)})`;
      ctx.beginPath();
      ctx.arc(d.x * w, d.y * h, d.r * (w / innerWidth), 0, 6.283);
      ctx.fill();
    }
    if (!still) raf = requestAnimationFrame(frame);
  };
  raf = requestAnimationFrame(frame);
  return () => { running = false; cancelAnimationFrame(raf); removeEventListener('resize', resize); };
}

/**
 * Runs the introduction.
 * Returns { entered, done }: `entered` resolves when the visitor presses ENTER YHOD
 * (sound is unlocked by that click), `done` when the intro has faded away.
 */
export function runIntro() {
  const el = $('#intro');
  const enter = $('#enter-btn');
  const actions = $('#intro-actions');
  const toggle = $('#sound-toggle');
  const label = $('#sound-label');
  const hint = $('#intro-hint');
  const caption = $('#intro-caption');
  const note = $('#intro-voice-note');
  const skip = $('#intro-skip');
  const stopStars = stars($('#intro-stars'));
  let resolveEntered, resolveDone;
  const entered = new Promise((r) => { resolveEntered = r; });
  const done = new Promise((r) => { resolveDone = r; });
  let left = false;
  let audio = null; // Promise<{audio, model}>

  const loadAudio = () => {
    if (!audio) {
      audio = api.blob('/api/voice/intro').then(async ({ blob, headers }) => ({ audio: await blob.arrayBuffer(), model: headers.get('X-YHOD-Voice-Model') || null }));
      audio.catch(() => { audio = null; });
    }
    return audio;
  };

  const paintSound = () => {
    const on = !voice.muted;
    toggle.setAttribute('aria-pressed', String(on));
    toggle.setAttribute('aria-label', on ? 'Sound on. Press to turn sound off.' : 'Sound off. Press to turn sound on.');
    label.textContent = on ? 'Sound on' : 'Sound off';
    const wave = toggle.querySelector('.on');
    if (wave) wave.setAttribute('d', on ? 'M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11' : 'm16 9.5 5 5M21 9.5l-5 5');
    hint.textContent = on ? 'Plays a short spoken welcome' : 'Sound is off — the welcome will be shown as subtitles';
  };
  paintSound();
  toggle.addEventListener('click', () => {
    voice.toggleMuted();
    paintSound();
    if (!voice.muted && !el.classList.contains('is-speaking')) loadAudio().catch(() => {});
  });
  if (!voice.muted) loadAudio().catch(() => {}); // have the voice ready before the button is pressed

  // the button becomes usable when it has appeared; any key or click before that fast-forwards the words
  const ready = () => { actions.style.pointerEvents = 'auto'; if (!el.classList.contains('is-speaking')) { try { enter.focus({ preventScroll: true }); } catch { /* ignore */ } } };
  actions.style.pointerEvents = 'none';
  const readyTimer = setTimeout(ready, prefersReducedMotion() ? 400 : 5000);
  actions.addEventListener('animationend', ready, { once: true });
  const hurry = (e) => {
    if (e.target.closest && e.target.closest('#sound-toggle')) return;
    for (const node of el.querySelectorAll('.w, .intro-rule, .intro-sub, .intro-actions')) { node.style.animationDelay = '0s'; node.style.animationDuration = '.45s'; }
    el.removeEventListener('pointerdown', hurry);
    removeEventListener('keydown', hurry);
    setTimeout(ready, 480);
  };
  el.addEventListener('pointerdown', hurry);
  addEventListener('keydown', hurry);

  const onVoice = () => {
    if (!el.classList.contains('is-speaking')) return;
    const text = voice.caption;
    if (text && caption.dataset.t !== text) {
      caption.dataset.t = text;
      caption.replaceChildren(Object.assign(document.createElement('span'), { textContent: text }));
    }
  };
  voice.addEventListener('change', onVoice);

  const leave = () => {
    if (left) return;
    left = true;
    clearTimeout(readyTimer);
    voice.removeEventListener('change', onVoice);
    el.removeEventListener('pointerdown', hurry);
    removeEventListener('keydown', hurry);
    el.classList.add('is-leaving');
    document.body.classList.remove('is-locked');
    setTimeout(() => { stopStars(); disposeMicLogo($('#intro-mic .mic')); el.remove(); resolveDone(); }, prefersReducedMotion() ? 50 : 1120);
  };

  enter.addEventListener('click', async () => {
    if (el.classList.contains('is-speaking')) return;
    voice.unlock(); // this click is what allows the browser to play sound
    resolveEntered();
    el.classList.add('is-speaking');
    $('#intro-mic').append(createMicLogo({ label: 'YHOD is speaking' }));
    caption.textContent = '';
    skip.focus({ preventScroll: true });
    const result = await voice.say({ text: INTRO_VOICE_TEXT, key: 'intro', load: loadAudio });
    if (left) return;
    if (result.reason === 'error') {
      note.hidden = false;
      note.textContent = `The welcome voice could not be played: ${result.error?.message || 'unknown error'}`;
      await new Promise((r) => setTimeout(r, 1800));
    }
    await new Promise((r) => setTimeout(r, 450));
    leave();
  });
  skip.addEventListener('click', () => { voice.stop(); leave(); });

  return { entered, done };
}
