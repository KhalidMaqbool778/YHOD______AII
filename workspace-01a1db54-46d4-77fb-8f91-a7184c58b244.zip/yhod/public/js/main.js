// YHOD — start-up: the introduction first, then sign-in or the main site.
import { $, h, icon, swap, toast } from './dom.js';
import { api, timeZone, build } from './api.js';
import { runIntro } from './intro.js';
import { showAuth } from './auth.js';
import { startApp } from './app.js';

async function boot() {
  const root = $('#app');
  const intro = runIntro();
  // while the words animate, find out whether someone is already signed in
  const sessionP = api.get('/api/auth/me').then((r) => r.user).catch(() => null);
  const statusP = api.get(`/api/status?tz=${encodeURIComponent(timeZone())}`).catch(() => null);
  // Is this page built from the files the server has now? If not (something handed out a stored copy of the
  // page, or the site was updated a moment ago), fetch the current page once. Only while the introduction is
  // still on screen, never after ENTER YHOD: from then on YHOD stays exactly where the person is. The new
  // address carries the fingerprint (/?v=…), so the page cannot come out of a store again, and the same
  // fingerprint in the address is the proof that this was already tried: it can never loop.
  let entered = false;
  statusP.then((st) => {
    if (entered || !st || !st.files || st.files === build) return;
    const here = new URL(location.href);
    if (here.searchParams.get('v') === st.files) return;
    here.searchParams.set('v', st.files);
    location.replace(here.href);
  });

  await intro.entered; // ENTER YHOD was pressed (this also unlocks sound)
  entered = true;
  const [user, status] = await Promise.all([sessionP, statusP]);

  const enterApp = async (u, introDone) => {
    root.classList.remove('is-in');
    if (u.tz !== timeZone()) { try { u = (await api.patch('/api/account', { tz: timeZone() })).user; } catch { /* keep the saved time zone */ } }
    await startApp(root, u, { status, introDone });
    window.scrollTo(0, 0);
  };

  if (user) {
    await enterApp(user, intro.done);
  } else {
    showAuth(root, {
      ready: intro.done,
      onAuthed: async (u, { isNew } = {}) => {
        await enterApp(u, Promise.resolve());
        toast(isNew ? 'Your private YHOD workspace is ready. Everything you save stays in it.' : 'Your private YHOD workspace is open, with everything you saved before.', 'ok', 6500);
      },
    });
    intro.done.then(() => root.classList.add('is-in'));
    if (status && status.gemini && !status.gemini.ok) {
      const g = status.gemini;
      root.querySelector('.auth-card')?.append(h('div.note.danger', { role: 'alert' }, icon('alert'), h('div', h('strong', g.configured ? 'Gemini is not answering correctly.' : 'Gemini is not configured on the server.'), h('div', { style: { marginTop: '3px' } }, g.error?.message || 'AI features will not work until this is fixed.'))));
    }
  }
}

boot().catch((e) => {
  console.error(e);
  const root = $('#app');
  document.getElementById('intro')?.remove();
  document.body.classList.remove('is-locked');
  root.classList.add('is-in');
  swap(root, h('main.auth', h('div.auth-card.glass', h('div.note.danger', icon('alert'), h('div', h('strong', 'YHOD could not start.'), h('div', { style: { marginTop: '4px' } }, String(e?.message || e)), h('div', { style: { marginTop: '12px' } }, h('button.btn.btn-sm', { type: 'button', onclick: () => location.reload() }, 'Reload')))))));
});
