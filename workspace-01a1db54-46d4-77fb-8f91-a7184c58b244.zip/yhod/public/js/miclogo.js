// YHOD — the AI microphone logo.
// A glowing circular emblem: purple outline, cyan and electric-blue light, and a
// microphone with the letters "AI" inside it. While YHOD speaks, the logo is driven
// by the real loudness of the audio being played (see voice.js): the border pulses,
// the logo expands and contracts, the light gets brighter and sound waves appear.
// When nothing is playing it falls back to a slow idle animation.
import { voice } from './voice.js';

let uid = 0;
const SVG = 'http://www.w3.org/2000/svg';
const logos = new Set();

function glyph() {
  const id = `mg${++uid}`;
  const svg = document.createElementNS(SVG, 'svg');
  svg.setAttribute('viewBox', '0 0 120 156');
  svg.setAttribute('class', 'mic-glyph');
  svg.setAttribute('aria-hidden', 'true');
  svg.innerHTML = `
    <defs>
      <linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#7DF3FF"/><stop offset=".5" stop-color="#00D9FF"/><stop offset="1" stop-color="#2F7BFF"/>
      </linearGradient>
      <linearGradient id="${id}f" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#0B2A3D" stop-opacity=".95"/><stop offset="1" stop-color="#07101F" stop-opacity=".95"/>
      </linearGradient>
      <linearGradient id="${id}t" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#9BEFFF"/>
      </linearGradient>
    </defs>
    <rect x="29" y="5" width="62" height="92" rx="31" fill="url(#${id}f)" stroke="url(#${id}s)" stroke-width="5"/>
    <text x="60" y="63" text-anchor="middle" font-size="35" letter-spacing="1.500" fill="url(#${id}t)">AI</text>
    <path d="M13 66v5a47 47 0 0 0 94 0v-5" fill="none" stroke="url(#${id}s)" stroke-width="5.500" stroke-linecap="round"/>
    <path d="M60 118v22" stroke="url(#${id}s)" stroke-width="5.500" stroke-linecap="round"/>
    <path d="M36 144h48" stroke="url(#${id}s)" stroke-width="5.500" stroke-linecap="round"/>`;
  return svg;
}

/**
 * createMicLogo({ interactive, label, waves })
 * Returns the element. data-state: idle | speaking | listening | thinking
 */
export function createMicLogo({ interactive = false, label = 'YHOD AI voice assistant', waves = true } = {}) {
  const el = document.createElement(interactive ? 'button' : 'div');
  el.className = 'mic';
  el.dataset.state = 'idle';
  if (interactive) { el.type = 'button'; el.setAttribute('aria-label', label); } else { el.setAttribute('role', 'img'); el.setAttribute('aria-label', label); }
  const canvas = waves ? document.createElement('canvas') : null;
  if (canvas) { canvas.className = 'mic-waves'; canvas.setAttribute('aria-hidden', 'true'); el.append(canvas); }
  for (const cls of ['mic-halo', 'mic-ring-glow', 'mic-ring', 'mic-arc a', 'mic-arc b']) { const d = document.createElement('span'); d.className = cls; d.setAttribute('aria-hidden', 'true'); el.append(d); }
  const core = document.createElement('span');
  core.className = 'mic-core';
  core.append(glyph());
  el.append(core);
  const logo = { el, canvas, ctx: null, w: 0, ripples: [], lastPeak: 0, lastAmp: 0, forced: null };
  el._logo = logo;
  logos.add(logo);
  return el;
}

export function disposeMicLogo(el) { if (el?._logo) logos.delete(el._logo); }
/** Force a state ("thinking" while waiting for Gemini, "listening" while recording); null returns to automatic. */
export function setMicState(el, state) { if (el?._logo) { el._logo.forced = state; el.dataset.state = state || (voice.speaking ? 'speaking' : 'idle'); } }

function sizeCanvas(logo) {
  const rect = logo.canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = Math.round(rect.width * dpr);
  if (w && w !== logo.w) { logo.w = w; logo.canvas.width = w; logo.canvas.height = w; logo.ctx = logo.canvas.getContext('2d'); }
  return logo.w > 0;
}

function draw(logo, amp, bands, now) {
  if (!logo.canvas || !logo.el.isConnected) return;
  if (!sizeCanvas(logo)) return;
  const { ctx, w } = logo;
  ctx.clearRect(0, 0, w, w);
  if (amp <= 0.004 && !logo.ripples.length) return;
  const c = w / 2;
  const r0 = w / 1.9 / 2; // the logo's own radius inside the larger canvas (canvas is 190% of the logo)
  const n = bands.length;

  // sound waves: radial bars around the ring, mirrored left/right
  const count = n * 2;
  ctx.lineCap = 'round';
  for (let i = 0; i < count; i++) {
    const b = i < n ? i : count - 1 - i;
    const v = Math.min(1, bands[b] * 1.5 + amp * 0.18);
    if (v < 0.03) continue;
    const ang = (i / count) * Math.PI * 2 - Math.PI / 2;
    const inner = r0 * 1.085;
    const len = r0 * (0.05 + v * 0.42);
    const hue = 188 + (b / n) * 82; // cyan → electric blue → violet
    ctx.strokeStyle = `hsla(${hue}, 100%, ${58 + v * 16}%, ${0.3 + v * 0.7})`;
    ctx.lineWidth = Math.max(1.2, w * 0.0065);
    ctx.beginPath();
    ctx.moveTo(c + Math.cos(ang) * inner, c + Math.sin(ang) * inner);
    ctx.lineTo(c + Math.cos(ang) * (inner + len), c + Math.sin(ang) * (inner + len));
    ctx.stroke();
  }

  // expanding ripples on loud moments
  if (amp > 0.34 && amp > logo.lastAmp + 0.035 && now - logo.lastPeak > 230) { logo.ripples.push({ t: now, a: amp }); logo.lastPeak = now; }
  logo.lastAmp = amp;
  logo.ripples = logo.ripples.filter((rp) => now - rp.t < 1500);
  for (const rp of logo.ripples) {
    const k = (now - rp.t) / 1500;
    ctx.strokeStyle = `rgba(0, 217, 255, ${(1 - k) * 0.5 * rp.a})`;
    ctx.lineWidth = Math.max(1, w * 0.004);
    ctx.beginPath();
    ctx.arc(c, c, r0 * (1.06 + k * 0.78), 0, Math.PI * 2);
    ctx.stroke();
  }
}

voice.addEventListener('level', () => {
  const amp = voice.level;
  const now = performance.now();
  const active = voice.external ? 'listening' : voice.speaking ? 'speaking' : 'idle';
  for (const logo of logos) {
    if (!logo.el.isConnected) continue;
    logo.el.style.setProperty('--amp', amp.toFixed(3));
    const state = logo.forced && active === 'idle' ? logo.forced : active;
    if (logo.el.dataset.state !== state) logo.el.dataset.state = state;
    draw(logo, amp, voice.bands, now);
  }
});
voice.addEventListener('change', () => {
  const active = voice.external ? 'listening' : voice.speaking ? 'speaking' : voice.state === 'loading' ? 'thinking' : 'idle';
  for (const logo of logos) {
    if (!logo.el.isConnected) continue;
    const state = logo.forced && active === 'idle' ? logo.forced : active;
    if (logo.el.dataset.state !== state) logo.el.dataset.state = state;
    if (active === 'idle' && voice.level === 0) logo.el.style.setProperty('--amp', '0');
  }
});
