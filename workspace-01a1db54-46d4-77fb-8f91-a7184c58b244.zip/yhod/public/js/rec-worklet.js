// YHOD — audio worklet: passes microphone samples to the page while recording.
class YhodRecorder extends AudioWorkletProcessor {
  process(inputs) {
    const channel = inputs[0] && inputs[0][0];
    if (channel && channel.length) this.port.postMessage(channel.slice(0));
    return true;
  }
}
registerProcessor('yhod-rec', YhodRecorder);
