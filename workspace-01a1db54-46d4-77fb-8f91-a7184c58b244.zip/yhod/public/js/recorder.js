// YHOD — microphone recorder.
// Records the microphone only after the person presses the button and the browser's
// permission prompt is accepted. The recording is turned into a small 16 kHz WAV in
// the browser and sent to the YHOD server, where Gemini turns the speech into text.
import { voice } from './voice.js';

const TARGET_RATE = 16000;
export const MAX_SECONDS = 45;

function encodeWav(samples, rate) {
  const buf = new ArrayBuffer(44 + samples.length * 2);
  const v = new DataView(buf);
  const str = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  str(0, 'RIFF'); v.setUint32(4, 36 + samples.length * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, rate, true);
  v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); str(36, 'data'); v.setUint32(40, samples.length * 2, true);
  for (let i = 0; i < samples.length; i++) { const s = Math.max(-1, Math.min(1, samples[i])); v.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true); }
  return buf;
}

function downsample(input, from, to) {
  if (from === to) return input;
  const ratio = from / to;
  const out = new Float32Array(Math.floor(input.length / ratio));
  for (let i = 0; i < out.length; i++) {
    const a = Math.floor(i * ratio);
    const b = Math.min(input.length, Math.floor((i + 1) * ratio));
    let sum = 0;
    for (let j = a; j < b; j++) sum += input[j];
    out[i] = sum / Math.max(1, b - a); // averaging acts as a simple low-pass filter
  }
  return out;
}

function toBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

export function micSupported() {
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && (window.AudioContext || window.webkitAudioContext));
}

/** Friendly explanation for a getUserMedia failure. */
export function mediaErrorText(e, what = 'microphone') {
  const name = e?.name || '';
  if (!window.isSecureContext) return `The ${what} only works on a secure (https) connection.`;
  if (name === 'NotAllowedError' || name === 'SecurityError') {
    let framed = false;
    try { framed = window.self !== window.top; } catch { framed = true; }
    return framed
      ? `Access to the ${what} was blocked. In an embedded preview the browser may not allow it — open YHOD in its own tab, or allow the ${what} for this site.`
      : `Access to the ${what} was not allowed. Allow it in your browser's site settings and try again.`;
  }
  if (name === 'NotFoundError' || name === 'OverconstrainedError') return `No ${what} was found on this device.`;
  if (name === 'NotReadableError' || name === 'AbortError') return `The ${what} is being used by another app. Close that app and try again.`;
  return `The ${what} could not be started (${name || 'unknown error'}).`;
}

export class Recorder {
  constructor() { this.active = false; }

  async start({ onAutoStop } = {}) {
    if (this.active) return;
    if (!micSupported()) throw Object.assign(new Error('This browser cannot record audio.'), { name: 'NotSupportedError' });
    voice.unlock();
    voice.stop();
    const ctx = voice.ctx;
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
    if (ctx.state === 'suspended') { try { await ctx.resume(); } catch { /* ignore */ } }
    this.rate = ctx.sampleRate;
    this.chunks = [];
    this.length = 0;
    this.source = ctx.createMediaStreamSource(this.stream);
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.analyser.smoothingTimeConstant = 0.6;
    this.source.connect(this.analyser);
    this.sink = ctx.createGain();
    this.sink.gain.value = 0; // never played back
    this.sink.connect(ctx.destination);
    const push = (data) => { if (!this.active) return; this.chunks.push(data); this.length += data.length; };
    let worklet = false;
    if (ctx.audioWorklet && window.AudioWorkletNode) {
      try {
        await ctx.audioWorklet.addModule(new URL('./rec-worklet.js', import.meta.url).href); // next to this file, under the same fingerprint
        this.node = new AudioWorkletNode(ctx, 'yhod-rec', { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1 });
        this.node.port.onmessage = (e) => push(e.data);
        worklet = true;
      } catch { worklet = false; }
    }
    if (!worklet) {
      this.node = ctx.createScriptProcessor(4096, 1, 1);
      this.node.onaudioprocess = (e) => push(new Float32Array(e.inputBuffer.getChannelData(0)));
    }
    this.source.connect(this.node);
    this.node.connect(this.sink);
    this.active = true;
    this.startedAt = performance.now();
    voice.attachInput(this.analyser);
    this.timer = setTimeout(() => { if (this.active && onAutoStop) onAutoStop(); }, MAX_SECONDS * 1000);
  }

  /** Stops and returns { audio: base64 WAV, seconds } — or null when nothing useful was recorded. */
  stop() {
    if (!this.active) return null;
    this.active = false;
    clearTimeout(this.timer);
    voice.attachInput(null);
    try { this.source.disconnect(); this.node.disconnect(); this.sink.disconnect(); } catch { /* ignore */ }
    if (this.node.port) this.node.port.onmessage = null; else this.node.onaudioprocess = null;
    for (const t of this.stream.getTracks()) t.stop(); // the microphone indicator goes off
    const all = new Float32Array(this.length);
    let o = 0;
    for (const c of this.chunks) { all.set(c, o); o += c.length; }
    this.chunks = [];
    const seconds = all.length / this.rate;
    if (seconds < 0.4) return null;
    const mono = downsample(all, this.rate, TARGET_RATE);
    let peak = 0;
    for (let i = 0; i < mono.length; i++) { const a = Math.abs(mono[i]); if (a > peak) peak = a; }
    if (peak > 0.02 && peak < 0.5) { const g = Math.min(4, 0.7 / peak); for (let i = 0; i < mono.length; i++) mono[i] *= g; } // gentle normalising for quiet voices
    return { audio: toBase64(encodeWav(mono, TARGET_RATE)), seconds, peak };
  }

  cancel() { if (this.active) this.stop(); }
}
