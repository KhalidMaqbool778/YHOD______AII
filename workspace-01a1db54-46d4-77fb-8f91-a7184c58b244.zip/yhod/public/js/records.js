// YHOD — My records: look at, export and delete everything saved in the account.
import { h, icon, swap, busy, toast, errorNote, confirmDialog, openModal, fmtDate, fmtDateTime, parseDate, num } from './dom.js';
import { api, forgetSession } from './api.js';
import { assessmentCard, LEVELS } from './assessview.js';
import { feedbackView } from './checkin.js';
import { SECTIONS, QUESTIONS, TOTAL_QUESTIONS } from '../shared/questions.js';

const KIND = { symptom: ['Symptom assessment', 'chat'], skin: ['Skin concern (photo)', 'image'], image: ['Photo assessment', 'image'] };
const URGENCY = { emergency: ['Emergency', 'danger'], urgent: ['See a doctor today', 'warn'], see_doctor: ['See a doctor', 'warn'], monitor: ['Keep an eye on it', 'cyan'], none: ['All clear', 'ok'] };
let open = false;

function answersView(answers) {
  return h('div.answers', SECTIONS.map((s) => {
    const qs = QUESTIONS.filter((q) => q.section === s.id && answers[q.id] !== undefined);
    if (!qs.length) return null;
    return h('div', h('h4', s.title), h('ul', qs.map((q) => {
      const v = answers[q.id];
      const shown = q.type === 'temperature' ? `${v.value} °${v.unit}` : String(v);
      if (q.text.includes('____')) {
        const [a, b] = (q.type === 'temperature' ? q.text.replace(' °C/°F', '') : q.text).split('____');
        return h('li', a, h('em', shown), b);
      }
      return h('li', q.text, ' ', h('em', shown));
    })));
  }));
}

export function openRecords(ctx, tab = 'checkins') {
  if (open) return;
  open = true;
  let data = null;
  let current = ['checkins', 'assessments', 'photos', 'privacy'].includes(tab) ? tab : 'checkins';
  const urls = [];
  const body = h('div', { 'aria-live': 'polite' });
  const tabs = h('div.rtabs', { role: 'tablist', 'aria-label': 'Record types' });
  const close = () => {
    if (!open) return;
    open = false;
    wrap.remove();
    for (const u of urls) URL.revokeObjectURL(u);
    document.body.classList.remove('is-locked');
    document.removeEventListener('keydown', onKey, true);
  };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.overlay')) close(); };
  const back = () => paint();
  const changed = () => ctx.bus.dispatchEvent(new CustomEvent('records'));

  const TABS = [['checkins', 'Daily check-ins', 'form'], ['assessments', 'Health assessments', 'stethoscope'], ['photos', 'Saved photos', 'image'], ['privacy', 'Privacy and my data', 'shield']];
  function paintTabs() {
    swap(tabs, TABS.map(([k, label, ic]) => {
      const n = data ? ({ checkins: data.checkins.length, assessments: data.assessments.length, photos: data.images.length })[k] : null;
      return h(`button.chip${k === current ? '.is-active' : ''}`, { type: 'button', role: 'tab', 'aria-selected': String(k === current), onclick: () => { current = k; paint(); } }, icon(ic), label, n !== null && n !== undefined ? ` · ${n}` : '');
    }));
  }
  const empty = (ic, title, text) => h('div.empty.card', h('div.orb', icon(ic)), h('h3', title), h('p', text));
  const dateBox = (d) => { const dt = typeof d === 'string' && d.length === 10 ? parseDate(d) : new Date(d); return h('div.rdate', h('small', dt.toLocaleDateString(undefined, { month: 'short' })), h('b', String(dt.getDate()))); };

  async function showCheckin(date) {
    swap(body, h('div.shimmer', { style: { height: '120px', borderRadius: '18px' } }, '.'));
    try {
      const c = (await api.get(`/api/checkins/${date}`)).checkin;
      const del = h('button.btn.btn-sm.btn-danger', { type: 'button', onclick: async () => {
        if (!(await confirmDialog({ title: `Delete the check-in for ${fmtDate(date)}?`, text: 'The answers and the AI feedback for this day will be removed permanently.', confirm: 'Delete this day', danger: true }))) return;
        try { await api.del(`/api/checkins/${date}`); toast('That day was deleted.', 'ok'); changed(); await load(); } catch (e) { toast(e.message, 'error'); }
      } }, icon('trash'), 'Delete this day');
      swap(body,
        h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '10px', alignItems: 'center', marginBottom: '18px' } },
          h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: back }, icon('chevronL'), 'All check-ins'),
          h('h3', { style: { fontFamily: 'var(--font-display)', fontSize: '19px', flex: '1', minWidth: '200px' } }, fmtDate(date, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })),
          h('button.btn.btn-sm', { type: 'button', onclick: () => { close(); ctx.showDay(date); } }, icon('chart'), 'Show on dashboard'), del),
        h('p.muted', { style: { fontSize: '13.5px', marginBottom: '18px' } }, `${c.answered} of ${TOTAL_QUESTIONS} sentences answered · saved ${fmtDateTime(c.updatedAt)}`),
        c.feedback ? h('div', { style: { marginBottom: '26px' } }, feedbackView(c.feedback, date, { numbers: ctx.status?.emergencyNumbers })) : h('div.note', { style: { marginBottom: '22px' } }, icon('info'), h('div', 'This day has not been analysed by Gemini.')),
        h('div.card', { style: { padding: '22px' } }, h('div.tile-head', { style: { marginBottom: '16px' } }, h('h3', icon('form'), 'Your answers')), answersView(c.answers)));
      wrap.scrollTop = 0;
    } catch (e) { swap(body, errorNote(e, { title: 'That check-in could not be loaded', retry: () => showCheckin(date) })); }
  }

  async function showAssessment(id) {
    swap(body, h('div.shimmer', { style: { height: '120px', borderRadius: '18px' } }, '.'));
    try {
      const a = (await api.get(`/api/assessments/${id}`)).assessment;
      const del = h('button.btn.btn-sm.btn-danger', { type: 'button', onclick: async () => {
        if (!(await confirmDialog({ title: 'Delete this assessment?', text: a.imageId ? 'The assessment and the photo saved with it will be removed permanently.' : 'This assessment will be removed permanently.', confirm: 'Delete', danger: true }))) return;
        try { await api.del(`/api/assessments/${id}`); toast('The assessment was deleted.', 'ok'); changed(); await load(); } catch (e) { toast(e.message, 'error'); }
      } }, icon('trash'), 'Delete');
      swap(body,
        h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '10px', alignItems: 'center', marginBottom: '18px' } },
          h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: back }, icon('chevronL'), 'All assessments'), h('span', { style: { flex: '1' } }), del),
        assessmentCard(a, { emergency: a.result.seriousness_level === 'emergency' ? { numbers: ctx.status?.emergencyNumbers, reasons: a.input?.safetyFlags || a.result.safetyFlags || [] } : null }));
      wrap.scrollTop = 0;
    } catch (e) { swap(body, errorNote(e, { title: 'That assessment could not be loaded', retry: () => showAssessment(id) })); }
  }

  function deleteFlow(scope) {
    const account = scope === 'account';
    const pw = h('input.input', { type: 'password', autocomplete: 'current-password', placeholder: 'Your password', 'aria-label': 'Your password' });
    const err = h('div.form-error', { role: 'alert' });
    const go = h('button.btn.btn-danger', { type: 'button', onclick: async () => {
      if (!pw.value) { err.textContent = 'Please enter your password to confirm.'; return; }
      busy(go, true, 'Deleting…');
      try {
        await api.post('/api/account/delete', { scope, password: pw.value });
        try { for (const k of Object.keys(localStorage)) if (k.startsWith('yhod.draft.')) localStorage.removeItem(k); } catch { /* ignore */ }
        m.close();
        if (account) { forgetSession(); toast('Your account and all its data were deleted.', 'ok'); setTimeout(() => location.reload(), 1300); }
        else { toast('All your health records were deleted.', 'ok'); changed(); await load(); }
      } catch (e) { busy(go, false); err.textContent = e.message; }
    } }, account ? 'Delete my account' : 'Delete my health records');
    const m = openModal({
      title: account ? 'Delete my account' : 'Delete all my health records',
      body: h('div', { style: { display: 'grid', gap: '14px' } },
        h('p.muted', { style: { lineHeight: '1.6' } }, account ? 'This permanently deletes your account, your visit history, every check-in, AI feedback, conversation, assessment and saved photo. It cannot be undone.' : 'This permanently deletes every check-in, AI feedback, conversation, assessment and saved photo. Your account, name and visit dates are kept. It cannot be undone.'),
        h('label.field', h('span', 'Confirm with your password'), pw), err),
      actions: [h('button.btn.btn-ghost', { type: 'button', onclick: () => m.close() }, 'Cancel'), go],
    });
  }

  function paint() {
    paintTabs();
    if (!data) return;
    if (current === 'checkins') {
      if (!data.checkins.length) return swap(body, empty('form', 'No check-ins yet', 'Your daily check-ins will be listed here once you submit the daily health form.'));
      return swap(body, h('div.rlist', data.checkins.map((c) => {
        const u = URGENCY[c.urgency];
        const bits = [c.water !== null ? `${num(c.water)} glasses water` : null, c.sleepHours !== null ? `${num(c.sleepHours, 2)} h sleep` : null, c.activeMinutes !== null ? `${num(c.activeMinutes)} min active` : null, c.mood ? `mood ${c.mood.toLowerCase()}` : null].filter(Boolean);
        return h('button.rrow', { type: 'button', onclick: () => showCheckin(c.date) }, dateBox(c.date),
          h('div.rmain', h('b', fmtDate(c.date, { weekday: 'long', day: 'numeric', month: 'long' })), h('span', bits.length ? bits.join(' · ') : `${c.answered} sentences answered`)),
          h('div.rside', c.symptoms ? h('span.chip.warn', `${c.symptoms} symptom${c.symptoms === 1 ? '' : 's'}`) : null, u ? h(`span.chip.${u[1]}`, u[0]) : h('span.chip', 'Not analysed'), icon('chevron')));
      })));
    }
    if (current === 'assessments') {
      if (!data.assessments.length) return swap(body, empty('stethoscope', 'No assessments yet', 'When you use START YHOD or ask YHOD to look at a photo, the assessment is saved here.'));
      return swap(body, h('div.rlist', data.assessments.map((a) => h('button.rrow', { type: 'button', onclick: () => showAssessment(a.id) }, dateBox(a.createdAt),
        h('div.rmain', h('b', a.title), h('span', `${KIND[a.kind]?.[0] || 'Assessment'} · ${fmtDateTime(a.createdAt)}${a.about ? ' · ' + a.about : ''}`)),
        h('div.rside', a.imageId ? h('span.chip', icon('image'), 'photo saved') : null, a.level ? h(`span.level.${a.level}`, { style: { minHeight: '28px', fontSize: '10.5px', padding: '0 11px' } }, LEVELS[a.level]) : null, icon('chevron'))))));
    }
    if (current === 'photos') {
      if (!data.images.length) return swap(body, empty('image', 'No saved photos', 'Photos are only kept when you tick “save this photo in my private records” before an analysis.'));
      return swap(body, h('p.muted', { style: { fontSize: '13.5px', marginBottom: '14px' } }, 'These photos are stored encrypted and only you can open them.'), h('div.photos', data.images.map((im) => {
        const img = h('img', { alt: `Photo saved ${fmtDateTime(im.createdAt)}` });
        api.blob(`/api/images/${im.id}`).then(({ blob }) => { const u = URL.createObjectURL(blob); urls.push(u); img.src = u; }).catch(() => {});
        return h('div.photo-card', img, h('footer', h('span', fmtDateTime(im.createdAt)), h('button.icon-btn', { type: 'button', style: { width: '32px', height: '32px' }, 'aria-label': 'Delete this photo', onclick: async () => {
          if (!(await confirmDialog({ title: 'Delete this photo?', text: 'The photo will be removed permanently. The written assessment stays.', confirm: 'Delete photo', danger: true }))) return;
          try { await api.del(`/api/images/${im.id}`); toast('The photo was deleted.', 'ok'); await load(); } catch (e) { toast(e.message, 'error'); }
        } }, icon('trash'))));
      })));
    }
    // privacy and my data
    const exp = h('button.btn', { type: 'button', onclick: async () => {
      busy(exp, true, 'Preparing…');
      try {
        const { blob, headers } = await api.blob('/api/account/export');
        const name = /filename="([^"]+)"/.exec(headers.get('Content-Disposition') || '')?.[1] || 'yhod-my-health-records.json';
        const url = URL.createObjectURL(blob);
        const a = h('a', { href: url, download: name });
        document.body.append(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        toast('Your records were downloaded.', 'ok');
      } catch (e) { toast(e.message, 'error'); }
      busy(exp, false);
    } }, icon('download'), 'Export my data');
    return swap(body, h('div.privacy',
      h('div.note', icon('shield'), h('div', h('strong', 'How YHOD keeps your information'), h('div', { style: { marginTop: '4px' } }, 'Your name, visit dates, daily answers, AI feedback, conversations and assessments are saved in your account so your dashboard and history work. Health records are encrypted on the server, and only your own account can read them. Photos are kept only if you tick the box to save them. To produce AI answers, the YHOD server sends the relevant text or photo to Google Gemini.'))),
      h('div.row', h('div', h('b', 'Export my data'), h('span', 'Download everything YHOD holds about you — account details, visits, check-ins, AI feedback, conversations and assessments — as one file.')), exp),
      h('div.row', h('div', h('b', 'Visit history'), h('span', data.visits.length ? `YHOD has recorded visits on ${data.visits.length} day${data.visits.length === 1 ? '' : 's'}, most recently ${fmtDate(data.visits[0].date)}. These dates choose your welcome message.` : 'No visits recorded yet.'))),
      h('div.row.danger', h('div', h('b', 'Delete all my health records'), h('span', 'Removes every check-in, AI feedback, conversation, assessment and saved photo. Your account stays.')), h('button.btn.btn-danger', { type: 'button', onclick: () => deleteFlow('records') }, icon('trash'), 'Delete records')),
      h('div.row.danger', h('div', h('b', 'Delete my account'), h('span', 'Removes your account and everything in it, permanently.')), h('button.btn.btn-danger', { type: 'button', onclick: () => deleteFlow('account') }, icon('trash'), 'Delete account'))));
  }

  async function load() {
    try { data = await api.get('/api/records'); paint(); }
    catch (e) { swap(body, errorNote(e, { title: 'Your records could not be loaded', retry: load })); }
  }

  const wrap = h('div.records', { role: 'dialog', 'aria-modal': 'true', 'aria-label': 'My records' },
    h('div.records-in',
      h('div.records-head', h('h2', 'MY RECORDS'), h('button.btn.btn-sm', { type: 'button', onclick: close }, icon('x'), 'Close')),
      tabs, body));
  document.getElementById('overlays').append(wrap);
  document.body.classList.add('is-locked');
  document.addEventListener('keydown', onKey, true);
  paintTabs();
  swap(body, h('div.shimmer', { style: { height: '90px', borderRadius: '18px' } }, '.'));
  load();
}
