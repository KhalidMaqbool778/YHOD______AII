// YHOD — START YHOD: the guided health conversation, the camera / image upload,
// Gemini photo analysis and the symptom assessment.
import { h, icon, swap, busy, toast, errorNote, scrollToEl, reveal, confirmDialog, AI_MODEL_LABEL } from './dom.js';
import { api } from './api.js';
import { voice, speak } from './voice.js';
import { createMicLogo, setMicState } from './miclogo.js';
import { openCamera, prepareImage, ACCEPT } from './camera.js';
import { assessmentCard, emergencyCard } from './assessview.js';
import { detectRedFlags } from '../shared/safety.js';
import { EMERGENCY_VOICE_TEXT } from '../shared/copy.js';

const CONCERNS = [['skin', 'Skin rash or irritation'], ['swelling', 'Visible swelling'], ['injury', 'Minor visible injury'], ['nail', 'Nail change'], ['other', 'Other visible concern']];
const HISTORY_KEYS = new Set(['name', 'age', 'visited_doctor', 'conditions', 'medicines']);

export function mountStartYhod(root, ctx) {
  let conv = null; // { id, state }
  let photo = null; // { blob, url, source }
  let sending = false;
  let emergencyShown = false;
  let assessmentShown = false;

  const input = h('input', { type: 'text', placeholder: 'Type START YHOD to begin...', 'aria-label': 'Type START YHOD and press Enter to begin', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', maxlength: '300', enterkeyhint: 'go' });
  const go = h('button.sy-go', { type: 'submit', 'aria-label': 'Begin START YHOD' }, icon('send'));
  const hint = h('div.sy-hint', { 'aria-live': 'polite' });
  const resume = h('div', { style: { display: 'grid', justifyItems: 'center' } });
  const alertBox = h('div');
  const live = h('div');
  const results = h('div', { style: { display: 'grid', gap: '20px' } });
  const defaultHint = () => swap(hint, 'Type ', h('kbd', 'START YHOD'), ' and press ', h('kbd', 'Enter'), ' to begin a guided conversation with Gemini.');
  defaultHint();
  const isStart = (v) => /^\s*start\s*yhod\s*[.!]?\s*$/i.test(v);
  input.addEventListener('input', () => { go.classList.toggle('is-ready', isStart(input.value)); if (hint.classList.contains('warn')) { hint.classList.remove('warn'); defaultHint(); } });

  const bar = h('form.sy-bar', { onsubmit: (e) => {
    e.preventDefault();
    const v = input.value;
    if (isStart(v)) return begin();
    if (!v.trim()) { input.focus(); return undefined; }
    hint.classList.add('warn');
    swap(hint, 'To begin, type ', h('kbd', 'START YHOD'), ' and press ', h('kbd', 'Enter'), '.');
    // even here, an obvious emergency is never ignored
    const red = detectRedFlags(v);
    if (red.emergency) showEmergency({ reasons: red.flags.map((f) => f.label) }, { say: true });
    return undefined;
  } }, icon('search'), input, go);

  swap(root, h('div.wrap', h('div.sy.glass.glow.reveal', h('div.sy-glow'),
    h('div.sy-head', h('h2', 'START YHOD'), h('p', 'Are you feeling unwell? Tell your AI health companion what is happening.')),
    bar, hint, resume, alertBox, live, results)));

  const numbers = () => ctx.status?.emergencyNumbers;
  /** Shows the emergency notice. Returns true when it also started the spoken warning. */
  function showEmergency(em = {}, { say = false } = {}) {
    const first = !emergencyShown;
    emergencyShown = true;
    swap(alertBox, emergencyCard({ numbers: numbers(), ...em }));
    if (!first) return false;
    scrollToEl(alertBox, 10);
    if (!say) return false;
    voice.unlock();
    speak(EMERGENCY_VOICE_TEXT, { source: 'emergency' }, 'emergency');
    return true;
  }

  // ───────── conversation ─────────
  let msgs, foot, quick, answer, sendBtn, errBox, knownBox, meter, headSub, chatMic, nowBtn;

  const bubble = (m) => {
    const mine = m.role === 'user';
    const el = h(`div.msg.${mine ? 'me' : 'bot'}${m.emergency ? '.alert' : ''}`, h('div.bubble', m.text));
    if (!mine) el.append(h('div.msg-meta',
      h('button', { type: 'button', onclick: () => { voice.unlock(); if (voice.muted) toast('Sound is off, so this is shown as subtitles.'); speak(m.text, { source: 'message', id: m.id }, `m:${m.id}`); } }, icon('volume'), 'Listen'),
      h('span.ai-tag', m.source === 'protocol' ? 'Safety question' : AI_MODEL_LABEL(m.model))));
    return el;
  };
  // newest message into view; a long reply is shown from its first word, not from its end
  const scrollChat = () => {
    const last = msgs.lastElementChild;
    if (last && last.classList.contains('bot') && last.offsetHeight > msgs.clientHeight - 20) msgs.scrollTop = Math.max(0, last.offsetTop - 10);
    else msgs.scrollTop = msgs.scrollHeight;
  };

  function paintState() {
    const s = conv.state;
    meter.style.width = `${Math.round((s.progress.done / s.progress.total) * 100)}%`;
    headSub.textContent = s.assessmentId ? 'Assessment ready' : s.ready ? 'Preparing your assessment' : `Step ${Math.min(s.progress.done + 1, s.progress.total)} of ${s.progress.total} · one question at a time`;
    swap(knownBox, s.known.filter((k) => k.key !== 'danger_check').length
      ? s.known.filter((k) => k.key !== 'danger_check').map((k) => h('div', h('small', k.label), h('span', k.value)))
      : h('p.faint', { style: { fontSize: '13px' } }, 'Your answers will be listed here as you give them.'));
    if (s.emergency) showEmergency(s.emergency);
    nowBtn.hidden = !!s.assessmentId;
  }

  function setQuick(list) {
    swap(quick, (list || []).map((q) => h('button', { type: 'button', onclick: () => send(q) }, q)));
    quick.hidden = !(list && list.length);
  }

  function render(messages) {
    msgs = h('div.sy-msgs', { role: 'log', 'aria-live': 'polite', 'aria-label': 'Conversation with YHOD' }, messages.map(bubble));
    quick = h('div.quick', { hidden: true });
    errBox = h('div');
    answer = h('textarea', { rows: '1', placeholder: 'Type your answer…', maxlength: '1500', 'aria-label': 'Your answer', enterkeyhint: 'send' });
    sendBtn = h('button.send', { type: 'submit', 'aria-label': 'Send answer', disabled: true }, icon('arrowUp'));
    const grow = () => { answer.style.height = 'auto'; answer.style.height = Math.min(140, answer.scrollHeight) + 'px'; };
    answer.addEventListener('input', () => { grow(); sendBtn.disabled = sending || !answer.value.trim(); });
    answer.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(answer.value); } });
    nowBtn = h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => assess() }, icon('sparkle'), 'Get my assessment now');
    foot = h('div.sy-foot', quick, errBox, h('form.composer', { onsubmit: (e) => { e.preventDefault(); send(answer.value); } }, answer, sendBtn),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px', justifyContent: 'space-between', alignItems: 'center' } }, h('span.faint', { style: { fontSize: '11.5px' } }, 'Answer in your own words. General information only — not a diagnosis.'), nowBtn));
    meter = h('i');
    headSub = h('p');
    chatMic = createMicLogo({ waves: false, label: 'YHOD' });
    knownBox = h('div.known');
    const upload = h('input', { type: 'file', accept: ACCEPT.join(','), hidden: true, 'aria-hidden': 'true', tabindex: '-1' });
    upload.addEventListener('change', () => { const f = upload.files[0]; upload.value = ''; if (f) pickFile(f); });
    const photoBox = h('div');
    const chooseUpload = () => upload.click();
    const chooseCamera = () => openCamera({ onUse: (blob) => setPhoto(blob, 'camera'), onUpload: chooseUpload });

    function pickFile(f) {
      if (!ACCEPT.includes(f.type)) return toast('Please choose a JPG, JPEG, PNG or WEBP image.', 'error');
      const max = (ctx.status?.limits?.imageMB || 6) * 4; // the photo is made smaller before it is sent
      if (f.size > max * 1024 * 1024) return toast(`That image is too large (limit ${max} MB).`, 'error');
      return setPhoto(f, 'upload');
    }

    function setPhoto(blob, source) {
      if (photo) URL.revokeObjectURL(photo.url);
      photo = blob ? { blob, url: URL.createObjectURL(blob), source } : null;
      paintPhoto();
      if (photo) scrollToEl(photoBox, 20);
    }

    let concern = 'skin';
    let described = '';
    let consent = false;
    function paintPhoto(err) {
      if (!photo) { photoBox.replaceChildren(); return; }
      const chips = h('div.concerns', { role: 'radiogroup', 'aria-label': 'What kind of concern is it?' }, CONCERNS.map(([k, label]) => h(`button.chip${k === concern ? '.is-active' : ''}`, { type: 'button', role: 'radio', 'aria-checked': String(k === concern), onclick: () => { concern = k; paintPhoto(); } }, label)));
      const symptomsKnown = conv?.state.known.find((k) => k.key === 'symptoms')?.value || '';
      const text = h('textarea.textarea', { maxlength: '2000', placeholder: 'For example: I have red spots on my arm. They itch and sometimes hurt. This started three days ago.', 'aria-label': 'Describe what you are experiencing' }, described || symptomsKnown);
      text.addEventListener('input', () => { described = text.value; });
      const box = h('input', { type: 'checkbox' });
      box.checked = consent;
      box.addEventListener('change', () => { consent = box.checked; });
      const analyse = h('button.btn.btn-primary.btn-block', { type: 'button', onclick: async () => {
        described = text.value;
        busy(analyse, true, 'Gemini is looking at your photo…');
        setMicState(chatMic, 'thinking');
        const red = detectRedFlags(described);
        if (red.emergency) showEmergency({ reasons: red.flags.map((f) => f.label) }, { say: true });
        try {
          const prepared = await prepareImage(photo.blob);
          const r = await api.post(concern === 'skin' || concern === 'nail' ? '/api/analyze/skin' : '/api/analyze/image', { image: prepared.base64, symptoms: described, concern, conversationId: conv?.id, saveImage: consent }, { timeout: 85000 });
          setMicState(chatMic, null);
          if (r.emergency) showEmergency(r.emergency);
          const card = assessmentCard(r.assessment, { emergency: r.emergency ? { ...r.emergency, numbers: numbers() } : null, onClearerPhoto: chooseCamera });
          results.prepend(card);
          setPhoto(null); described = ''; consent = false;
          scrollToEl(card);
          ctx.bus.dispatchEvent(new CustomEvent('records-added'));
          voice.unlock();
          speak(r.assessment.result.spoken_summary, { source: 'assessment', id: r.assessment.id }, `a:${r.assessment.id}`, { auto: true });
        } catch (e) {
          setMicState(chatMic, null);
          paintPhoto(e); // the photo and the description stay exactly as they were, ready to try again
        }
      } }, icon('sparkle'), 'ANALYSE THIS PHOTO');
      swap(photoBox, h('div.photo',
        h('div.photo-prev', h('img', { src: photo.url, alt: 'Preview of your photo' })),
        h('div.photo-tools',
          photo.source === 'camera' ? h('button.btn.btn-sm', { type: 'button', onclick: chooseCamera }, icon('replay'), 'RETAKE') : h('button.btn.btn-sm', { type: 'button', onclick: chooseUpload }, icon('swap'), 'REPLACE'),
          h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => setPhoto(null) }, icon('trash'), 'REMOVE')),
        h('div.field', h('span', 'What kind of concern is it?'), chips),
        h('label.field', h('span', 'Describe what you are experiencing'), text),
        h('label.check', box, h('span', 'Also save this photo in my private records. If you leave this unticked, the photo is only used for this analysis and is not kept.')),
        err ? errorNote(err, { title: 'Gemini could not analyse the photo. Your photo and description are still here.' }) : null,
        analyse,
        h('p.faint', { style: { fontSize: '12px', lineHeight: '1.5' } }, 'The photo is sent securely to the YHOD server and analysed by Gemini together with your description. A photo can never confirm a condition.')));
    }

    swap(live, h('div', { style: { display: 'grid', gap: '20px' } },
      h('div.sy-live',
        h('div.sy-chat',
          h('div.sy-chat-head', chatMic, h('div', { style: { flex: '1', minWidth: '0' } }, h('h3', 'START YHOD'), headSub), h('div.meter', { role: 'progressbar', 'aria-label': 'Conversation progress' }, meter),
            h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: end }, 'End')),
          msgs, foot),
        h('div.sy-side',
          h('div.panel', h('h3', "SHOW YHOD WHAT YOU'RE EXPERIENCING"), h('p', 'Take a photograph or upload an image to help YHOD understand your health concern.'),
            h('div.pick', h('button', { type: 'button', onclick: chooseCamera }, icon('camera'), 'OPEN CAMERA'), h('button', { type: 'button', onclick: chooseUpload }, icon('upload'), 'UPLOAD IMAGE')),
            h('p.faint', { style: { fontSize: '12px' } }, 'JPG, JPEG, PNG or WEBP. You will see a preview before anything is sent.'), upload, photoBox),
          h('div.panel', h('h3', 'WHAT YOU HAVE TOLD YHOD'), knownBox)))));
    paintState();
    const last = messages[messages.length - 1];
    if (last && last.role !== 'user' && !conv.state.ready) setQuick(last.quick);
    requestAnimationFrame(scrollChat);
  }

  async function begin() {
    if (sending) return;
    sending = true;
    voice.unlock(); // typing START YHOD + Enter is the gesture that allows YHOD to speak
    swap(hint, h('span.spinner', { style: { display: 'inline-block', verticalAlign: '-3px', marginRight: '8px' } }), 'Starting your conversation…');
    try {
      const r = await api.post('/api/start-yhod/start', {});
      open(r.conversation, { fresh: true });
    } catch (e) {
      swap(hint, '');
      swap(alertBox, errorNote(e, { title: 'The conversation could not be started', retry: begin }));
    }
    sending = false;
  }

  function open(c, { fresh = false } = {}) {
    conv = { id: c.id, state: c.state };
    emergencyShown = false; assessmentShown = false;
    alertBox.replaceChildren(); results.replaceChildren(); resume.replaceChildren();
    bar.hidden = true; hint.hidden = true;
    render(c.messages);
    scrollToEl(root, -10);
    setTimeout(() => answer.focus({ preventScroll: true }), 350);
    if (fresh) { const first = c.messages[0]; speak(first.text, { source: 'message', id: first.id }, `m:${first.id}`, { auto: true }); }
    if (c.state.assessmentId) loadAssessment(c.state.assessmentId);
  }

  async function end() {
    if (conv && !conv.state.assessmentId && !(await confirmDialog({ title: 'End this conversation?', text: 'Your answers so far stay in your records, but the conversation will be closed.', confirm: 'End conversation' }))) return;
    const id = conv?.id;
    voice.stop();
    conv = null; if (photo) { URL.revokeObjectURL(photo.url); photo = null; }
    live.replaceChildren(); results.replaceChildren(); alertBox.replaceChildren();
    bar.hidden = false; hint.hidden = false; input.value = ''; go.classList.remove('is-ready'); defaultHint();
    if (id) api.post(`/api/start-yhod/${id}/close`, {}).catch(() => {});
    scrollToEl(root, -10);
  }

  async function send(text) {
    text = String(text || '').trim();
    if (!text || sending || !conv) return;
    sending = true; sendBtn.disabled = true; errBox.replaceChildren(); setQuick([]);
    const pending = bubble({ role: 'user', text });
    const typing = h('div.typing', { 'aria-label': 'YHOD is reading your answer' }, h('i'), h('i'), h('i'));
    msgs.append(pending, typing); scrollChat();
    answer.value = ''; answer.style.height = 'auto';
    setMicState(chatMic, 'thinking');
    // fixed safety rules run in the browser first: emergency advice appears at once, before the AI answers
    const last = conv.state.lastAsked;
    const red = detectRedFlags(text, { assumeTemperature: last === 'temperature', temperatureOnly: HISTORY_KEYS.has(last) });
    const warned = red.emergency ? showEmergency({ reasons: red.flags.map((f) => f.label) }, { say: true }) : false;
    try {
      const r = await api.post(`/api/start-yhod/${conv.id}/message`, { text }, { timeout: 60000 });
      const [mine, reply] = r.messages;
      conv.state = r.state;
      pending.replaceWith(bubble(mine));
      typing.remove();
      msgs.append(bubble(reply));
      paintState();
      // YHOD says each reply aloud (with sound off it is shown as subtitles); the spoken emergency warning is never interrupted
      if (!warned) { voice.unlock(); speak(reply.text, { source: 'message', id: reply.id }, `m:${reply.id}`, { auto: true }); }
      if (r.state.ready) { setQuick([]); assess(); } else setQuick(reply.quick);
    } catch (e) {
      pending.remove(); typing.remove();
      answer.value = text; // nothing is lost: the answer is back in the box
      if (e.data?.state) { conv.state = e.data.state; paintState(); }
      if (e.data?.emergency) showEmergency(e.data.emergency, { say: true });
      errBox.replaceChildren(errorNote(e, { title: 'YHOD could not read that answer', retry: () => send(answer.value), retryLabel: 'Send again' }));
    }
    setMicState(chatMic, null);
    sending = false; sendBtn.disabled = !answer.value.trim(); scrollChat();
    if (matchMedia('(pointer: fine)').matches) answer.focus({ preventScroll: true });
  }

  function showAssessment(a) {
    assessmentShown = true;
    const card = assessmentCard(a, { emergency: conv?.state.emergency || (a.result.seriousness_level === 'emergency' ? { numbers: numbers() } : null) });
    const old = results.querySelector('[data-kind="symptom"]');
    card.dataset.kind = 'symptom';
    if (old) old.replaceWith(card); else results.append(card);
    return card;
  }
  async function loadAssessment(id) {
    try { showAssessment((await api.get(`/api/assessments/${id}`)).assessment); } catch { /* it may have been deleted */ }
  }

  async function assess() {
    if (!conv || assessmentShown && conv.state.assessmentId) return;
    const loading = h('div.steps.card', { 'data-kind': 'symptom' }, h('div.step.now', h('span.ico', h('span.spinner', { style: { width: '13px', height: '13px' } })), 'Gemini is preparing your assessment from your answers…'));
    const old = results.querySelector('[data-kind="symptom"]');
    if (old) old.replaceWith(loading); else results.append(loading);
    scrollToEl(loading, 30);
    nowBtn.hidden = true;
    setMicState(chatMic, 'thinking');
    try {
      const r = await api.post(`/api/start-yhod/${conv.id}/assessment`, {}, { timeout: 85000 });
      setMicState(chatMic, null);
      conv.state.assessmentId = r.assessment.id; conv.state.ready = true;
      loading.remove();
      const card = showAssessment(r.assessment);
      paintState();
      setQuick([]);
      scrollToEl(card);
      reveal(card);
      ctx.bus.dispatchEvent(new CustomEvent('records-added'));
      voice.unlock();
      speak(r.assessment.result.spoken_summary, { source: 'assessment', id: r.assessment.id }, `a:${r.assessment.id}`, { auto: true });
    } catch (e) {
      setMicState(chatMic, null);
      nowBtn.hidden = false;
      const note = errorNote(e, { title: 'Gemini could not prepare your assessment yet. Your answers are saved.', retry: assess });
      note.dataset.kind = 'symptom';
      loading.replaceWith(note);
    }
  }

  // an unfinished conversation can be continued after a reload
  api.get('/api/start-yhod/current').then((r) => {
    if (!r.conversation || conv) return;
    const c = r.conversation;
    const when = new Date(c.messages[c.messages.length - 1].at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    swap(resume, h('div.note', { style: { maxWidth: '720px', width: '100%' } }, icon('clock'), h('div', { style: { flex: '1' } }, h('strong', `You have an unfinished conversation from ${when}.`),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '10px' } },
        h('button.btn.btn-sm.btn-primary', { type: 'button', onclick: () => { voice.unlock(); open(c); } }, 'Continue it'),
        h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { api.post(`/api/start-yhod/${c.id}/close`, {}).catch(() => {}); resume.replaceChildren(); } }, 'Discard')))));
  }).catch(() => {});

  ctx.startYhod = () => { ctx.go('start-yhod'); setTimeout(() => input.focus({ preventScroll: true }), 500); };
}
