// YHOD — the build (npm run build). Vercel runs this before it packages the function.
//   1. Check that the project is complete: every imported file exists and exports what is asked of it
//      (scripts/check-project.mjs). An incomplete upload stops here, with the missing files named,
//      instead of failing later with an error that is hard to read.
//   2. Write the "dist" folder: the files Vercel serves by itself, without calling the function.
//      YHOD's pages and scripts are NOT in it — they are served by the function, which gives every
//      script a fingerprinted address and sends the security headers. Only robots.txt lives here.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const node = process.versions.node.split('.').map(Number);
if (node[0] < 22 || (node[0] === 22 && node[1] < 13)) {
  console.error(`✗ YHOD needs Node.js 22.13 or newer; this is ${process.version}. On Vercel: Settings → Build and Deployment → Node.js Version, or "engines" in package.json.`);
  process.exit(1);
}

const check = spawnSync(process.execPath, [path.join(ROOT, 'scripts/check-project.mjs')], { stdio: 'inherit' });
if (check.status !== 0) process.exit(check.status ?? 1);

const dist = path.join(ROOT, 'dist');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
fs.writeFileSync(path.join(dist, 'robots.txt'), 'User-agent: *\nDisallow: /api/\n');
console.log(`✓ Build finished (Node ${process.version}). dist/ holds robots.txt; everything else is served by the function api/index.js.`);
