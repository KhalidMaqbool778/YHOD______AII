// YHOD — is the project complete and consistent?  (npm run check; also the first step of npm run build)
//
// A deployment fails, or a page stays blank, when one file is missing, misspelt or written with another
// capitalisation than the import that names it (Vercel builds on Linux, where "Gemini.js" is not "gemini.js").
// This script follows every import from the three starting points —
//     server.js              the application (a server of its own)
//     api/index.js           the same application as a Vercel Function
//     public/index.html      the site that runs in the browser
// — and checks, for every file it reaches:
//   1. the file exists, with exactly the capitalisation the import uses;
//   2. every name that is imported is really exported by the file it is imported from
//      (checked by the JavaScript engine itself: the modules are linked, but not run);
//   3. the style sheets, fonts and icons the pages name exist;
//   4. nothing that reaches the browser contains an API key or talks to Google directly.
// It prints the list of files the project needs, and ends with an error if anything is wrong.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { spawnSync } from 'node:child_process';
import { builtinModules } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

// Linking modules without running them needs a Node option; start again with it if it is missing.
if (typeof vm.SourceTextModule !== 'function') {
  const again = spawnSync(process.execPath, ['--experimental-vm-modules', '--disable-warning=ExperimentalWarning', fileURLToPath(import.meta.url), ...process.argv.slice(2)], { stdio: 'inherit' });
  process.exit(again.status ?? 1);
}

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const quiet = process.argv.includes('--quiet');
const rel = (abs) => path.relative(ROOT, abs).split(path.sep).join('/');
const problems = [];
const problem = (text) => { if (!problems.includes(text)) problems.push(text); };
const needed = new Map(); // project path → why it is needed

/** Does this path exist with exactly this capitalisation? → null, or what is wrong with it. */
function spelling(abs) {
  let dir = ROOT;
  for (const part of rel(abs).split('/')) {
    let names;
    try { names = fs.readdirSync(dir); } catch { return `"${rel(dir)}" is not a folder`; }
    if (!names.includes(part)) {
      const other = names.find((n) => n.toLowerCase() === part.toLowerCase());
      return other ? `it is spelt "${other}" on disk, but "${part}" where it is used (capital letters matter on Linux and Vercel)` : 'the file does not exist';
    }
    dir = path.join(dir, part);
  }
  return null;
}
function need(abs, why) {
  const p = rel(abs);
  if (p.startsWith('..')) { problem(`${why}: points outside the project (${p})`); return false; }
  const wrong = spelling(abs);
  if (wrong) { problem(`MISSING  ${p}  — ${wrong}\n           needed by ${why}`); return false; }
  if (!needed.has(p)) needed.set(p, why);
  return true;
}

// Where does an import lead? For the server's own files: the path on disk. For the files of the site it is the
// address that counts: the browser loads public/js/app.js as /js/app.js, so its "../shared/copy.js" is
// /shared/copy.js — and the server takes /shared/… from the shared/ folder, everything else from public/.
const publicDir = path.join(ROOT, 'public');
function target(fromAbs, spec) {
  if (!fromAbs.startsWith(publicDir + path.sep)) return spec.startsWith('/') ? path.join(ROOT, spec) : path.resolve(path.dirname(fromAbs), spec);
  const address = new URL(spec, `http://yhod.site/${rel(fromAbs).slice('public/'.length)}`).pathname;
  return address.startsWith('/shared/') ? path.join(ROOT, address) : path.join(publicDir, address);
}

// ── JavaScript modules: follow the imports, then let the engine link them ──
const builtins = new Set([...builtinModules, ...builtinModules.map((m) => `node:${m}`), 'node:sqlite', 'node:test']);
const modules = new Map();   // absolute path → vm.SourceTextModule
const synthetic = new Map(); // "node:fs" → vm.SyntheticModule
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const declared = new Set([...Object.keys(pkg.dependencies || {}), ...Object.keys(pkg.optionalDependencies || {})]);
const context = vm.createContext({});

async function builtin(spec) {
  if (synthetic.has(spec)) return synthetic.get(spec);
  let names = ['default'];
  try { names = [...new Set(['default', ...Object.keys(await import(spec))])]; } catch { /* not in this Node version: only its name is known */ }
  const m = new vm.SyntheticModule(names, () => {}, { identifier: spec, context });
  synthetic.set(spec, m);
  return m;
}

function load(abs, why) {
  if (modules.has(abs)) return modules.get(abs);
  if (!need(abs, why)) return null;
  const code = fs.readFileSync(abs, 'utf8');
  let m;
  try {
    m = new vm.SourceTextModule(code, { identifier: pathToFileURL(abs).href, context, initializeImportMeta: (meta) => { meta.url = pathToFileURL(abs).href; } });
  } catch (e) {
    problem(`SYNTAX   ${rel(abs)}  — ${e.message}`);
    return null;
  }
  modules.set(abs, m);
  // files that are named in the code without a static import
  const bare = code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`\\])\/\/[^\n]*/g, '$1');
  for (const hit of bare.matchAll(/\bimport\(\s*(['"])([^'"]+)\1\s*\)/g)) if (hit[2].startsWith('.')) load(target(abs, hit[2]), `${rel(abs)} (import("${hit[2]}"))`);
  for (const hit of bare.matchAll(/new URL\(\s*(['"])(\.[^'"]+)\1\s*,\s*import\.meta\.url\s*\)/g)) need(target(abs, hit[2]), `${rel(abs)} (new URL("${hit[2]}"))`);
  return m;
}

async function link(entryAbs, why) {
  const entry = load(entryAbs, why);
  if (!entry) return;
  try {
    await entry.link(async (spec, parent) => {
      const from = fileURLToPath(parent.identifier);
      if (builtins.has(spec)) return builtin(spec);
      if (spec.startsWith('.') || spec.startsWith('/')) {
        const m = load(target(from, spec), `${rel(from)} (import "${spec}")`);
        if (m) return m;
        throw new Error(`"${spec}", imported by ${rel(from)}, cannot be found`);
      }
      const name = spec.startsWith('@') ? spec.split('/').slice(0, 2).join('/') : spec.split('/')[0];
      if (!declared.has(name)) problem(`PACKAGE  "${spec}" is imported by ${rel(from)} but "${name}" is not listed in package.json`);
      return new vm.SyntheticModule(['default'], () => {}, { identifier: spec, context });
    });
  } catch (e) {
    // e.g. "The requested module './gemini.js' does not provide an export named 'geminiState'"
    const where = String(e.stack || '').match(/file:\/\/[^\s:)]+\.m?js(:\d+)?/);
    problem(`IMPORT   ${e.message}${where ? `\n           in ${rel(fileURLToPath(where[0].replace(/:\d+$/, '')))}${where[1] || ''}` : ''}`);
  }
}

await link(path.join(ROOT, 'server.js'), 'the application (node server.js)');
await link(path.join(ROOT, 'api/index.js'), 'Vercel (the serverless function named in vercel.json)');

// ── the site in the browser: the page, its style sheets and scripts, the fonts and icons they name ──
const page = path.join(publicDir, 'index.html');
if (need(page, 'the site (the page every visitor loads)')) {
  const html = fs.readFileSync(page, 'utf8');
  for (const hit of html.matchAll(/\b(?:href|src)="(\/[^"#?]+)"/g)) {
    const file = path.join(publicDir, hit[1]);
    if (/\.m?js$/.test(hit[1])) await link(file, `public/index.html (${hit[0]})`);
    else if (need(file, `public/index.html (${hit[0]})`) && hit[1].endsWith('.css')) {
      const css = fs.readFileSync(file, 'utf8');
      for (const u of css.matchAll(/url\(\s*['"]?(\/[^'")?#]+)[^)]*\)/g)) need(path.join(publicDir, u[1]), `${rel(file)} (url(${u[1]}))`);
    }
  }
}
// ── names the application relies on ──
const must = { 'src/gemini.js': ['GeminiError', 'checkGemini', 'geminiState'], 'server.js': ['yhod', 'default'], 'api/index.js': ['default'], 'src/db.js': ['db', 'dbReady', 'nowIso'] };
for (const [file, names] of Object.entries(must)) {
  const m = modules.get(path.join(ROOT, file));
  if (!m) continue; // already reported as missing
  let have = [];
  try { have = Object.getOwnPropertyNames(m.namespace); } catch { continue; } // linking failed: already reported
  for (const n of names) if (!have.includes(n)) problem(`EXPORT   ${file} must export "${n}" (it exports: ${have.join(', ') || 'nothing'})`);
}

// ── the files Vercel needs besides the code ──
for (const [file, why] of [['vercel.json', 'Vercel (how requests reach the function)'], ['package.json', 'Node and Vercel (module type, Node version, build command)']]) need(path.join(ROOT, file), why);
try {
  const v = JSON.parse(fs.readFileSync(path.join(ROOT, 'vercel.json'), 'utf8'));
  for (const fn of Object.keys(v.functions || {})) if (!/[*{]/.test(fn)) need(path.join(ROOT, fn), 'vercel.json ("functions")');
  const sends = (v.rewrites || []).map((r) => r.destination);
  if (!sends.some((d) => d === '/api' || d === '/api/index' || d === '/api/index.js')) problem('VERCEL   vercel.json has no rewrite that sends requests to the function (/api)');
  if (!String(pkg.engines?.node || '').match(/^(2[2-9]|[3-9]\d)\b/)) problem(`NODE     package.json "engines.node" is "${pkg.engines?.node}": YHOD needs Node 22.13 or newer (it uses the built-in SQLite), and Vercel offers 22.x, 24.x and 26.x`);
  if (pkg.type !== 'module') problem('NODE     package.json must say "type": "module" (the code uses import/export)');
} catch (e) { problem(`VERCEL   vercel.json cannot be read: ${e.message}`); }
for (const dir of ['voice']) if (fs.existsSync(path.join(ROOT, dir))) for (const f of fs.readdirSync(path.join(ROOT, dir))) need(path.join(ROOT, dir, f), 'the spoken lines that ship with YHOD');

// ── two files whose names differ only in capital letters cannot both exist on Windows or macOS ──
(function twins(dir) {
  const seen = new Map();
  for (const name of fs.readdirSync(dir)) {
    if (name === 'node_modules' || name === 'data' || name.startsWith('.')) continue;
    const low = name.toLowerCase();
    if (seen.has(low)) problem(`NAMES    "${rel(path.join(dir, seen.get(low)))}" and "${rel(path.join(dir, name))}" differ only in capital letters`);
    seen.set(low, name);
    const abs = path.join(dir, name);
    if (fs.statSync(abs).isDirectory()) twins(abs);
  }
})(ROOT);

// ── nothing that reaches the browser may hold a key or call Google itself ──
const KEY_SHAPES = [/AIza[0-9A-Za-z_-]{30,}/, /\bAQ\.[A-Za-z0-9_-]{30,}/, /x-goog-api-key/i, /generativelanguage\.googleapis\.com/i, /GEMINI_API_KEY\s*[:=]\s*['"][^'"]{8,}/];
const realKey = String(process.env.GEMINI_API_KEY || (fs.existsSync(path.join(ROOT, '.env')) ? (fs.readFileSync(path.join(ROOT, '.env'), 'utf8').match(/^GEMINI_API_KEY=(.+)$/m) || [])[1] : '') || '').trim();
for (const p of needed.keys()) {
  if (/\.(woff2|bin|png|jpg|ico)$/.test(p)) continue;
  const text = fs.readFileSync(path.join(ROOT, p), 'utf8');
  if (realKey.length >= 16 && text.includes(realKey)) problem(`SECRET   ${p} contains the Gemini API key itself. The key belongs in an environment variable only.`);
  if (p.startsWith('public/') || p.startsWith('shared/')) for (const shape of KEY_SHAPES) if (shape.test(text)) problem(`SECRET   ${p} is sent to the browser and contains "${text.match(shape)[0].slice(0, 28)}…": the browser must never hold a key or call Google directly`);
}
if (fs.existsSync(path.join(ROOT, '.gitignore')) && !/^\.env$/m.test(fs.readFileSync(path.join(ROOT, '.gitignore'), 'utf8'))) problem('SECRET   .gitignore does not list ".env": the file with the API key could be uploaded with the code');

// ── report ──
const list = [...needed.keys()].sort();
if (!quiet) {
  console.log(`YHOD project check — ${list.length} files are needed:\n`);
  let folder = null;
  for (const p of list) {
    const f = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '(project folder)';
    if (f !== folder) { folder = f; console.log(`  ${f}/`.replace('(project folder)/', '(project folder)')); }
    console.log(`      ${p.slice(p.lastIndexOf('/') + 1)}`);
  }
  console.log('');
}
if (problems.length) {
  console.error(`✗ ${problems.length} problem${problems.length === 1 ? '' : 's'} found:\n`);
  for (const p of problems) console.error(`  ${p}\n`);
  console.error('The project is not complete. Add or correct the files named above, then run this check again.');
  process.exit(1);
}
console.log(`✓ All ${list.length} files exist with the right capitalisation, every import finds the name it asks for`);
console.log(`  (${modules.size} JavaScript modules linked; src/gemini.js exports GeminiError, checkGemini and geminiState), and nothing sent to the browser holds a key.`);
