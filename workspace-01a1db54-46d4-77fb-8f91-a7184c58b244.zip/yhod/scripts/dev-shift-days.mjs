// Testing helper: "let N days pass" for ONE account by moving its saved visit and
// check-in dates N days into the past. It lets you test the returning / six-day
// welcome messages and the weekly dashboard without waiting for real days.
//
//   node scripts/dev-shift-days.mjs <email> <days>
//
// It edits the database directly and is not reachable from the website.
import { db } from '../src/db.js';

const [email, daysArg] = process.argv.slice(2);
const days = Number.parseInt(daysArg, 10);
if (!email || !Number.isInteger(days) || days < 1 || days > 3650) {
  console.error('Usage: node scripts/dev-shift-days.mjs <email> <days>');
  process.exit(1);
}
const user = db.get('SELECT id, name FROM users WHERE email = ?', email.toLowerCase());
if (!user) { console.error('No account with that e-mail.'); process.exit(1); }

const back = (d) => new Date(Date.parse(d + 'T00:00:00Z') - days * 864e5).toISOString().slice(0, 10);
const backTs = (ts) => new Date(Date.parse(ts) - days * 864e5).toISOString();

db.tx(() => {
  for (const r of db.all('SELECT date, first_at, last_at FROM visits WHERE user_id = ? ORDER BY date ASC', user.id)) {
    db.run('UPDATE visits SET date = ?, first_at = ?, last_at = ? WHERE user_id = ? AND date = ?', back(r.date), backTs(r.first_at), backTs(r.last_at), user.id, r.date);
  }
  for (const r of db.all('SELECT id, date, created_at, updated_at FROM checkins WHERE user_id = ? ORDER BY date ASC', user.id)) {
    db.run('UPDATE checkins SET date = ?, created_at = ?, updated_at = ? WHERE id = ?', back(r.date), backTs(r.created_at), backTs(r.updated_at), r.id);
  }
  for (const r of db.all('SELECT id, created_at FROM assessments WHERE user_id = ?', user.id)) {
    db.run('UPDATE assessments SET created_at = ? WHERE id = ?', backTs(r.created_at), r.id);
  }
});
const v = db.all('SELECT date FROM visits WHERE user_id = ? ORDER BY date', user.id).map((r) => r.date);
const c = db.all('SELECT date FROM checkins WHERE user_id = ? ORDER BY date', user.id).map((r) => r.date);
console.log(`Moved ${user.name}'s records ${days} day(s) into the past. Visits: ${v.join(', ') || '—'} | Check-ins: ${c.join(', ') || '—'}`);
db.close();
