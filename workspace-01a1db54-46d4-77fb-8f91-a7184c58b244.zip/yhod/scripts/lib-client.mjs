// Tiny API client with a cookie jar, used by the test scripts.
import fs from 'node:fs';
export const BASE = process.env.BASE || 'http://127.0.0.1:3111';
const STATE = process.env.STATE || '/tmp/yhod-test-state.json';
export const state = fs.existsSync(STATE) ? JSON.parse(fs.readFileSync(STATE, 'utf8')) : {};
export const save = () => fs.writeFileSync(STATE, JSON.stringify(state, null, 2));
export async function api(method, path, body, { raw = false, headers = {} } = {}) {
  const t = Date.now();
  const r = await fetch(BASE + path, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), 'x-yhod': '1', ...(state.cookie ? { cookie: state.cookie } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(100000) });
  for (const c of r.headers.getSetCookie?.() || []) { const kv = c.split(';')[0]; if (kv.split('=')[1]) state.cookie = kv; else if (state.cookie && state.cookie.startsWith(kv.split('=')[0] + '=')) delete state.cookie; }
  const ct = r.headers.get('content-type') || '';
  const data = !raw && ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer());
  return { status: r.status, data, headers: r.headers, ms: Date.now() - t };
}
let pass = 0, fail = 0;
export function check(name, ok, info = '') { if (ok) { pass++; console.log(`  ✓ ${name}${info ? ' — ' + info : ''}`); } else { fail++; console.log(`  ✗ FAIL: ${name}${info ? ' — ' + info : ''}`); } return ok; }
export const summary = () => { console.log(`\n${fail ? 'FAILED' : 'PASSED'}: ${pass} checks passed, ${fail} failed`); if (fail) process.exitCode = 1; };
export const SAMPLE_ANSWERS = {
  1: 5, 2: 2, 3: 1, 4: 2, 5: 3, 6: 'Yes', 7: 'Yes', 8: 2, 9: 2, 10: 'Normal',
  11: 40, 12: 0, 13: 5, 14: 4, 15: 9, 16: 6200, 17: 30, 18: 'Walking', 19: 'No',
  21: '00:30', 22: '06:15', 23: 5.75, 24: 'Fair', 25: 2, 26: 0, 27: 60, 28: 'Yes', 29: 'No',
  31: 'Okay', 32: 4, 33: 2, 34: 3, 35: 'No', 36: 'Yes', 37: 'Yes', 38: 'No', 39: 15,
  41: { value: 37.9, unit: 'C' }, 42: 'Yes', 43: 'No', 44: 'Yes', 45: 'Yes', 46: 'No', 47: 'No', 48: 'No', 49: 'No', 50: 'No',
  51: 'No', 52: 'No', 53: 'Yes', 54: 'mild body aches', 55: 'yesterday', 56: 4, 57: 'Same', 58: 'seasonal allergies', 59: 'Not applicable',
};
