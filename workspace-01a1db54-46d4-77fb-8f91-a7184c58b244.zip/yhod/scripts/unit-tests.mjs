// Offline unit tests (no network, no Gemini quota used).
import assert from 'node:assert/strict';
import { QUESTIONS, TOTAL_QUESTIONS, SECTIONS, normaliseAnswers, answerSentence, sleepDuration } from '../shared/questions.js';
import { detectRedFlags, extractTemperatures, interpretDangerAnswer, checkinSafetyNotices } from '../shared/safety.js';
import { cleanName, cleanEmail, nameProblem, emailProblem, emailSuggestion, passwordProblem, passwordLength, PASSWORD_MAX } from '../shared/account.js';

let passed = 0;
const t = (name, fn) => { try { fn(); passed++; } catch (e) { console.error('✗', name, '\n   ', e.message); process.exitCode = 1; } };

// ── questions ───────────────────────────────────────────────────────
t('exactly 60 questions, ids 1..60', () => { assert.equal(TOTAL_QUESTIONS, 60); QUESTIONS.forEach((q, i) => assert.equal(q.id, i + 1)); });
t('6 sections with 10 questions each', () => { for (const s of SECTIONS) assert.equal(QUESTIONS.filter((q) => q.section === s.id).length, 10, s.id); });
t('valid answers normalise', () => {
  const { clean, errors } = normaliseAnswers({ 1: '8', 6: 'yes', 10: 'normal', 21: '23:30', 32: 4, 41: { value: '38.4', unit: 'c' }, 57: 'getting worse', 59: 'not applicable', 60: '  hello\n world ' });
  assert.deepEqual(errors, {});
  assert.deepEqual(clean, { 1: 8, 6: 'Yes', 10: 'Normal', 21: '23:30', 32: 4, 41: { value: 38.4, unit: 'C' }, 57: 'Getting worse', 59: 'Not applicable', 60: 'hello world' });
});
t('invalid answers rejected, blanks skipped', () => {
  const { clean, errors } = normaliseAnswers({ 1: -2, 2: '', 6: 'maybe', 21: '25:00', 32: 9, 41: { value: 150, unit: 'C' }, 56: 11 });
  assert.deepEqual(Object.keys(errors).map(Number), [1, 6, 21, 32, 41, 56]);
  assert.deepEqual(clean, {});
});
t('answer sentences', () => {
  assert.equal(answerSentence(QUESTIONS[0], 8), 'I drank 8 glasses of water today.');
  assert.equal(answerSentence(QUESTIONS[5], 'Yes'), 'I ate breakfast today. — Yes');
  assert.equal(answerSentence(QUESTIONS[40], { value: 101.3, unit: 'F' }), 'My body temperature was 101.3 °F.');
  assert.equal(answerSentence(QUESTIONS[56], 'Improving'), 'My symptoms are Improving.');
});
t('sleep duration wraps midnight', () => { assert.equal(sleepDuration('23:30', '07:00'), 7.5); assert.equal(sleepDuration('01:00', '06:15'), 5.25); });

// ── safety layer ────────────────────────────────────────────────────
const flagged = (s, o) => detectRedFlags(s, o).flags.map((f) => f.code);
t('105°F example from the brief triggers emergency', () => {
  assert.deepEqual(flagged('I have a fever of 105°F, I have a runny nose, I am feeling very hot, I have a headache, and my body feels weak.'), ['very_high_temperature']);
});
t('temperature variants', () => {
  for (const s of ['fever of 105', 'my temperature is 40.5', 'temp was 104 F', '105 degrees fahrenheit', 'temperature reached 41°C', 'Fever: 104.2', 'bukhar 105 hai', 'it is 40,6 °C']) assert.ok(flagged(s).includes('very_high_temperature'), s);
  for (const s of ['temperature 99.5 F', 'my temp is 37.2', 'fever of 101', 'temperature is normal 98.6', '38.5 C fever']) assert.deepEqual(flagged(s), [], s);
});
t('numbers that are not temperatures are ignored', () => {
  for (const s of ['I am 45 years old', 'I have had a fever for 3 days and I am 40 years old', 'fever for 3 days, age 40', 'I weigh 105 kg', 'I walked 105 minutes', 'pulse 110', 'I took 100 mg yesterday', 'fever for 40 days', 'I am 41']) assert.deepEqual(flagged(s), [], s);
});
t('bare number counts when answering the temperature question', () => {
  assert.deepEqual(flagged('105', { assumeTemperature: true }), ['very_high_temperature']);
  assert.deepEqual(flagged('about 104.5', { assumeTemperature: true }), ['very_high_temperature']);
  assert.deepEqual(flagged('98.6', { assumeTemperature: true }), []);
  assert.deepEqual(flagged('34', { assumeTemperature: true }), ['very_low_temperature']);
  assert.deepEqual(extractTemperatures('39.4', { assumeTemperature: true }), [{ value: 39.4, unit: 'C', celsius: 39.4 }]);
});
t('danger keywords', () => {
  assert.deepEqual(flagged('I have chest pain and I am sweating'), ['chest_pain']);
  assert.deepEqual(flagged("I can't breathe properly"), ['breathing']);
  assert.deepEqual(flagged('my son is having a seizure'), ['seizure']);
  assert.deepEqual(flagged('she fainted an hour ago'), ['fainting']);
  assert.deepEqual(flagged('the bleeding won’t stop'), ['bleeding']);
  assert.deepEqual(flagged('he is very confused and has slurred speech'), ['confusion']);
  assert.deepEqual(flagged('I want to kill myself'), ['self_harm']);
});
t('negations and history do not trigger', () => {
  for (const s of ['no chest pain', "I don't have chest pain or breathing difficulty", "No, I don't have chest pain, breathing difficulty, seizures, fainting, severe bleeding or severe confusion", 'none of these, no seizures', 'I fainted two years ago', 'history of seizures as a child', 'No trouble breathing', 'never had chest pain', 'not short of breath']) assert.deepEqual(flagged(s), [], s);
});
t('"No," answer particle does not hide a real symptom', () => {
  assert.deepEqual(flagged('No, chest pain started this morning'), ['chest_pain']);
  assert.deepEqual(flagged('I have not slept and now have chest pain'), ['chest_pain']);
  assert.deepEqual(flagged('No fever. But I have chest pain'), ['chest_pain']);
});
t('temperatureOnly mode ignores history keywords but keeps the temperature rule', () => {
  assert.deepEqual(flagged('I have epilepsy and get seizures', { temperatureOnly: true }), []);
  assert.deepEqual(flagged('asthma, and my fever is 105', { temperatureOnly: true }), ['very_high_temperature']);
});
t('danger answer interpretation', () => {
  assert.equal(interpretDangerAnswer('Yes'), 'yes');
  assert.equal(interpretDangerAnswer('no'), 'no');
  assert.equal(interpretDangerAnswer("No, I don't have chest pain or anything like that"), 'no');
  assert.equal(interpretDangerAnswer('No, chest pain started this morning'), 'yes');
  assert.equal(interpretDangerAnswer('yes I have severe bleeding'), 'yes');
  assert.equal(interpretDangerAnswer('I am not sure'), 'unclear');
  assert.equal(interpretDangerAnswer('nahi'), 'no');
  assert.equal(interpretDangerAnswer('no idea what is happening to me'), 'unclear');
  assert.equal(interpretDangerAnswer("I don't know"), 'unclear');
  assert.equal(interpretDangerAnswer("I don't have any of those"), 'no');
});
t('check-in safety notices', () => {
  assert.deepEqual(checkinSafetyNotices({ 1: 8, 11: 30 }), []);
  assert.deepEqual(checkinSafetyNotices({ 47: 'Yes' }).map((n) => [n.code, n.level]), [['chest_pain', 'emergency']]);
  assert.deepEqual(checkinSafetyNotices({ 41: { value: 105, unit: 'F' } }).map((n) => [n.code, n.level]), [['very_high_temperature', 'emergency']]);
  assert.deepEqual(checkinSafetyNotices({ 41: { value: 39.2, unit: 'C' } }).map((n) => [n.code, n.level]), [['high_temperature', 'urgent']]);
  assert.deepEqual(checkinSafetyNotices({ 56: 9, 57: 'Getting worse' }).map((n) => [n.code, n.level]), [['severe_symptoms', 'emergency']]);
  assert.deepEqual(checkinSafetyNotices({ 38: 'Yes', 46: 'No', 47: 'No' }).map((n) => [n.code, n.level]), [['low_mood', 'care']]);
  assert.deepEqual(checkinSafetyNotices({ 54: 'I fainted this morning' }).map((n) => n.code), ['fainting']);
  assert.deepEqual(checkinSafetyNotices({ 58: 'epilepsy with seizures' }), []);
});

// ── the entrance: name, e-mail, password ────────────────────────────
t('well-formed e-mail addresses are accepted', () => {
  for (const ok of ['ayesha@gmail.com', 'Ayesha.Khan@Gmail.COM', '  ali@yahoo.com  ', 'first.last+yhod@sub.domain.co.uk', 'a_b-c@hotmail.com', 'user@example.pk', 'x@y.io', "o'brien@example.org", 'josé@example.com', 'user@münchen.de', 'user@xn--mnchen-3ya.de', '123@456.com']) {
    assert.equal(emailProblem(ok), null, ok);
  }
});
t('malformed e-mail addresses are refused, each with a reason', () => {
  for (const bad of ['', '   ', 'ayesha', 'ayesha@', '@gmail.com', 'ayesha@gmail', 'ayesha@gmail.', 'ayesha@.com', 'ayesha@gmail..com', 'ayesha@@gmail.com', 'a@b@c.com', 'ayesha khan@gmail.com', 'ayesha@gm ail.com',
    '.ayesha@gmail.com', 'ayesha.@gmail.com', 'aye..sha@gmail.com', 'ayesha@-gmail.com', 'ayesha@gmail-.com', 'ayesha@gmail.c', 'ayesha@gmail.123', 'ayesha@gmail,com', 'ayesha(at)gmail.com', 'ayesha@[192.168.1.1]',
    'a'.repeat(65) + '@gmail.com', 'a@' + 'b'.repeat(64) + '.com', 'a@' + 'b.'.repeat(130) + 'com', 'ayesha@gmail.com;drop', '<ayesha@gmail.com>', 'ayesha@gmail.com\nx']) {
    const problem = emailProblem(bad);
    assert.equal(typeof problem, 'string', JSON.stringify(bad));
    assert.ok(problem.length > 15 && /[.]$/.test(problem), JSON.stringify(bad));
  }
});
t('an e-mail is compared in lower case without surrounding spaces', () => {
  assert.equal(cleanEmail('  Ayesha.Khan@Gmail.COM '), 'ayesha.khan@gmail.com');
});
t('a mistyped well-known mail domain gets a suggestion, a correct one does not', () => {
  assert.equal(emailSuggestion('Ayesha@gmial.com'), 'ayesha@gmail.com');
  assert.equal(emailSuggestion('ali@yahoo.con'), 'ali@yahoo.com');
  assert.equal(emailSuggestion('ali@hotmail.co'), 'ali@hotmail.com');
  for (const fine of ['ayesha@gmail.com', 'ali@yahoo.co.uk', 'x@hotmail.co.uk', 'me@gmx.com', 'me@ymail.com', 'me@mail.com', 'me@company.pk', 'no-at-sign']) assert.equal(emailSuggestion(fine), null, fine);
});
t('any password the person chooses is accepted', () => {
  for (const ok of ['1', 'a', ' ', 'abc', '1234', 'password', 'میرا پاس ورڈ', '🙂', 'with spaces inside', '  leading and trailing  ', '<script>', "'; DROP TABLE users; --", 'x'.repeat(PASSWORD_MAX)]) assert.equal(passwordProblem(ok), null, JSON.stringify(ok));
});
t('only a missing or oversized password is refused', () => {
  for (const bad of ['', undefined, null, 12345678, ['a'], { a: 1 }, 'x'.repeat(PASSWORD_MAX + 1)]) assert.equal(typeof passwordProblem(bad), 'string', JSON.stringify(bad));
  assert.equal(passwordLength('🙂ab'), 3);
});
t('names are tidied; an empty or oversized one is refused', () => {
  assert.equal(cleanName('  Ayesha \n  Khan  '), 'Ayesha Khan');
  assert.equal(cleanName('<b>Ali</b>'), 'b Ali /b');
  assert.equal(nameProblem('Ayesha'), null);
  assert.equal(nameProblem('عائشہ'), null);
  assert.equal(typeof nameProblem('   '), 'string');
  assert.equal(typeof nameProblem('x'.repeat(61)), 'string');
});

console.log(process.exitCode ? 'Some unit tests FAILED' : `All ${passed} unit tests passed`);
