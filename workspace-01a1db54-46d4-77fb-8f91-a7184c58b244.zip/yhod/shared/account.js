// YHOD — the three things a person types to open their workspace: name, e-mail and password.
// The browser uses these rules to explain a problem before anything is sent.
// The server uses the same rules to decide, so the two can never disagree.

export const NAME_MAX = 60;
export const EMAIL_MAX = 254;
export const PASSWORD_MAX = 200;

/** A name as it is stored: no control characters or angle brackets, single spaces, trimmed. */
export const cleanName = (v) => String(v ?? '').replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim();

/** An e-mail as it is stored and compared: lower case, without surrounding spaces. */
export const cleanEmail = (v) => String(v ?? '').trim().toLowerCase();

/** null when the name is acceptable; otherwise one sentence that says what to correct. */
export function nameProblem(value) {
  const name = cleanName(value);
  if (!name) return 'Please tell YHOD your name.';
  if (name.length > NAME_MAX) return `Please use a name of at most ${NAME_MAX} characters.`;
  return null;
}

// The part before the @: letters, digits and the usual symbols, with single dots only in between.
const LOCAL = /^[\p{L}\p{N}!#$%&'*+/=?^_`{|}~-]+(?:\.[\p{L}\p{N}!#$%&'*+/=?^_`{|}~-]+)*$/u;
// One piece of the domain: letters and digits, hyphens only inside, at most 63 characters.
const LABEL = /^[\p{L}\p{N}](?:[\p{L}\p{N}-]{0,61}[\p{L}\p{N}])?$/u;
// The last piece (com, pk, org ...): letters only, or an internationalised ending in its "xn--" form.
const ENDING = /^(?:\p{L}{2,24}|xn--[a-z0-9-]{2,59})$/u;

/**
 * null when the address is correctly formed; otherwise one sentence that says what to correct.
 * This checks the form of the address. It cannot know whether the mailbox exists or belongs to the person.
 */
export function emailProblem(value) {
  const email = cleanEmail(value);
  if (!email) return 'Please enter your e-mail address.';
  if (/\s/.test(email)) return 'An e-mail address cannot contain spaces.';
  const parts = email.split('@');
  if (parts.length < 2) return 'An e-mail address needs an @ sign, for example name@gmail.com.';
  if (parts.length > 2) return 'An e-mail address can have only one @ sign.';
  const [local, domain] = parts;
  if (!local) return 'Something is missing before the @ sign.';
  if (!domain) return 'Something is missing after the @ sign, for example gmail.com.';
  if (email.length > EMAIL_MAX || local.length > 64) return 'This e-mail address is too long.';
  if (!LOCAL.test(local)) return 'The part before the @ sign is not valid. Check it for a dot in the wrong place or an unusual character.';
  const labels = domain.split('.');
  if (labels.length < 2) return 'The part after the @ sign needs a full domain, for example gmail.com.';
  if (!labels.every((label) => LABEL.test(label)) || !ENDING.test(labels[labels.length - 1])) return 'The part after the @ sign is not a valid domain. It should look like gmail.com.';
  return null;
}

// Well-known mail domains as they are commonly mistyped. Used only to ask "did you mean ...?", never to refuse.
const DOMAIN_FIXES = {
  'gmial.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gmal.com': 'gmail.com', 'gamil.com': 'gmail.com', 'gnail.com': 'gmail.com',
  'gmaill.com': 'gmail.com', 'gmail.co': 'gmail.com', 'gmail.con': 'gmail.com', 'gmail.cm': 'gmail.com', 'gmail.om': 'gmail.com', 'gmail.comm': 'gmail.com',
  'hotmial.com': 'hotmail.com', 'hotmai.com': 'hotmail.com', 'hotmal.com': 'hotmail.com', 'hotmail.co': 'hotmail.com', 'hotmail.con': 'hotmail.com',
  'yaho.com': 'yahoo.com', 'yahooo.com': 'yahoo.com', 'yahoo.co': 'yahoo.com', 'yahoo.con': 'yahoo.com',
  'outlok.com': 'outlook.com', 'outloo.com': 'outlook.com', 'outlook.co': 'outlook.com', 'outlook.con': 'outlook.com',
  'iclod.com': 'icloud.com', 'icloud.co': 'icloud.com', 'icloud.con': 'icloud.com',
};

/** A likely correction for a mistyped well-known mail domain ("name@gmial.com"), or null. */
export function emailSuggestion(value) {
  const email = cleanEmail(value);
  const at = email.lastIndexOf('@');
  if (at < 1) return null;
  const fixed = DOMAIN_FIXES[email.slice(at + 1)];
  return fixed ? email.slice(0, at + 1) + fixed : null;
}

/**
 * Any password a person chooses is accepted: there is no minimum length and no rule about digits or symbols.
 * It only has to exist and to fit in PASSWORD_MAX characters. It is never trimmed or changed.
 * null when acceptable; otherwise one sentence that says what to correct.
 */
export function passwordProblem(value) {
  if (typeof value !== 'string' || value.length === 0) return 'Please enter a password. You can choose any password you like.';
  if (value.length > PASSWORD_MAX) return `Please use a password of at most ${PASSWORD_MAX} characters.`;
  return null;
}

/** How many characters a person would count in a password (an emoji counts once). */
export const passwordLength = (value) => [...String(value ?? '')].length;
