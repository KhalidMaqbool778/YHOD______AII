// YHOD — fixed wording used by both the browser and the server.
export const BRAND_WORDS = ['YOUR', 'HEALTH', 'OUR', 'DUTY'];
export const INTRO_SUBTITLE = 'YOUR PERSONAL AI HEALTH COMPANION';
export const INTRO_VOICE_TEXT = 'Welcome to YHOD. Create your health better with full free access. Your Health, Our Duty.';
export const EMERGENCY_VOICE_TEXT = 'This may be a medical emergency. Please contact your local emergency services now, or go to the nearest emergency department. Do not wait.';
export const MEDICINE_DISCLAIMER = 'YHOD provides general health information, not medical prescriptions. Consult a qualified healthcare professional before starting any medicine.';
export const GENERAL_DISCLAIMER = 'YHOD is an AI companion that shares general health information. It does not diagnose, and it is not a substitute for a doctor. In an emergency, contact your local emergency services.';
