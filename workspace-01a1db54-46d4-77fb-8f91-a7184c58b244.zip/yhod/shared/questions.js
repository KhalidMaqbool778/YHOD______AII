// YHOD — the 60 daily check-in questions.
// This single definition is used by BOTH the browser (to render the form)
// and the server (to validate answers and to describe them to Gemini).

export const SECTIONS = [
  { id: 'water_food', title: 'WATER AND FOOD', short: 'Water & Food', icon: 'drop' },
  { id: 'activity', title: 'PHYSICAL ACTIVITY', short: 'Activity', icon: 'run' },
  { id: 'sleep', title: 'SLEEP', short: 'Sleep', icon: 'moon' },
  { id: 'mind', title: 'MENTAL WELLBEING', short: 'Mind', icon: 'spark' },
  { id: 'body', title: 'BODY AND SYMPTOMS', short: 'Body', icon: 'pulse' },
  { id: 'extra', title: 'ADDITIONAL HEALTH INFORMATION', short: 'More', icon: 'plus' },
];

const YESNO = ['Yes', 'No'];

// "____" marks where the input sits inside the sentence.
export const QUESTIONS = [
  // ── WATER AND FOOD ────────────────────────────────────────────────
  { id: 1, section: 'water_food', text: 'I drank ____ glasses of water today.', type: 'number', min: 0, max: 40, step: 1 },
  { id: 2, section: 'water_food', text: 'I drank ____ glasses of other fluids today.', type: 'number', min: 0, max: 40, step: 1 },
  { id: 3, section: 'water_food', text: 'I ate ____ servings of fruits today.', type: 'number', min: 0, max: 30, step: 1 },
  { id: 4, section: 'water_food', text: 'I ate ____ servings of vegetables today.', type: 'number', min: 0, max: 30, step: 1 },
  { id: 5, section: 'water_food', text: 'I ate ____ meals today.', type: 'number', min: 0, max: 12, step: 1 },
  { id: 6, section: 'water_food', text: 'I ate breakfast today.', type: 'choice', options: YESNO },
  { id: 7, section: 'water_food', text: 'I ate protein-rich food today.', type: 'choice', options: YESNO },
  { id: 8, section: 'water_food', text: 'I drank ____ sugary drinks today.', type: 'number', min: 0, max: 30, step: 1 },
  { id: 9, section: 'water_food', text: 'I ate ____ servings of snacks today.', type: 'number', min: 0, max: 30, step: 1 },
  { id: 10, section: 'water_food', text: 'My appetite today was ____.', type: 'select', options: ['Very low', 'Low', 'Normal', 'Good', 'Very high'] },

  // ── PHYSICAL ACTIVITY ─────────────────────────────────────────────
  { id: 11, section: 'activity', text: 'I walked for ____ minutes today.', type: 'number', min: 0, max: 1440, step: 1 },
  { id: 12, section: 'activity', text: 'I exercised for ____ minutes today.', type: 'number', min: 0, max: 1440, step: 1 },
  { id: 13, section: 'activity', text: 'I stretched for ____ minutes today.', type: 'number', min: 0, max: 1440, step: 1 },
  { id: 14, section: 'activity', text: 'I took ____ breaks from sitting today.', type: 'number', min: 0, max: 200, step: 1 },
  { id: 15, section: 'activity', text: 'I sat for approximately ____ hours today.', type: 'number', min: 0, max: 24, step: 0.5 },
  { id: 16, section: 'activity', text: 'I walked ____ steps today.', type: 'number', min: 0, max: 200000, step: 1, wide: true },
  { id: 17, section: 'activity', text: 'I spent ____ minutes outdoors today.', type: 'number', min: 0, max: 1440, step: 1 },
  { id: 18, section: 'activity', text: 'My main physical activity was ____.', type: 'text', maxLength: 120, suggestions: ['Walking', 'Running', 'Cycling', 'Gym workout', 'Yoga', 'Swimming', 'Sports', 'Housework', 'None today'] },
  { id: 19, section: 'activity', text: 'I experienced pain during exercise.', type: 'choice', options: YESNO },
  { id: 20, section: 'activity', text: 'Other physical activity information: ____.', type: 'text', maxLength: 300, long: true },

  // ── SLEEP ─────────────────────────────────────────────────────────
  { id: 21, section: 'sleep', text: 'I went to sleep at ____.', type: 'time' },
  { id: 22, section: 'sleep', text: 'I woke up at ____.', type: 'time' },
  { id: 23, section: 'sleep', text: 'I slept for ____ hours today.', type: 'number', min: 0, max: 24, step: 0.25 },
  { id: 24, section: 'sleep', text: 'My sleep quality was ____.', type: 'select', options: ['Very poor', 'Poor', 'Fair', 'Good', 'Excellent'] },
  { id: 25, section: 'sleep', text: 'I woke up during the night ____ times.', type: 'number', min: 0, max: 50, step: 1 },
  { id: 26, section: 'sleep', text: 'I took a nap for ____ minutes.', type: 'number', min: 0, max: 720, step: 1 },
  { id: 27, section: 'sleep', text: 'I used screens before sleeping for ____ minutes.', type: 'number', min: 0, max: 720, step: 1 },
  { id: 28, section: 'sleep', text: 'I consumed caffeine late in the day.', type: 'choice', options: YESNO },
  { id: 29, section: 'sleep', text: 'I felt rested after waking up.', type: 'choice', options: YESNO },
  { id: 30, section: 'sleep', text: 'Other information about my sleep: ____.', type: 'text', maxLength: 300, long: true },

  // ── MENTAL WELLBEING ──────────────────────────────────────────────
  { id: 31, section: 'mind', text: 'My mood today was ____.', type: 'select', options: ['Very low', 'Low', 'Okay', 'Good', 'Great'] },
  { id: 32, section: 'mind', text: 'My stress level was ____ out of 5.', type: 'rating', max: 5 },
  { id: 33, section: 'mind', text: 'My energy level was ____ out of 5.', type: 'rating', max: 5 },
  { id: 34, section: 'mind', text: 'My concentration level was ____ out of 5.', type: 'rating', max: 5 },
  { id: 35, section: 'mind', text: 'I felt relaxed today.', type: 'choice', options: YESNO },
  { id: 36, section: 'mind', text: 'I enjoyed an activity today.', type: 'choice', options: YESNO },
  { id: 37, section: 'mind', text: 'I spent time with family or friends.', type: 'choice', options: YESNO },
  { id: 38, section: 'mind', text: 'I experienced unusual sadness or worry.', type: 'choice', options: YESNO },
  { id: 39, section: 'mind', text: 'I relaxed for ____ minutes today.', type: 'number', min: 0, max: 1440, step: 1 },
  { id: 40, section: 'mind', text: 'Other information about my mood: ____.', type: 'text', maxLength: 300, long: true },

  // ── BODY AND SYMPTOMS ─────────────────────────────────────────────
  { id: 41, section: 'body', text: 'My body temperature was ____ °C/°F.', type: 'temperature' },
  { id: 42, section: 'body', text: 'I experienced a headache.', type: 'choice', options: YESNO, symptom: 'Headache' },
  { id: 43, section: 'body', text: 'I experienced a cough.', type: 'choice', options: YESNO, symptom: 'Cough' },
  { id: 44, section: 'body', text: 'I experienced a runny nose or cold.', type: 'choice', options: YESNO, symptom: 'Runny nose or cold' },
  { id: 45, section: 'body', text: 'I experienced a sore throat.', type: 'choice', options: YESNO, symptom: 'Sore throat' },
  { id: 46, section: 'body', text: 'I experienced difficulty breathing.', type: 'choice', options: YESNO, symptom: 'Difficulty breathing' },
  { id: 47, section: 'body', text: 'I experienced chest pain.', type: 'choice', options: YESNO, symptom: 'Chest pain' },
  { id: 48, section: 'body', text: 'I experienced stomach pain.', type: 'choice', options: YESNO, symptom: 'Stomach pain' },
  { id: 49, section: 'body', text: 'I experienced nausea or vomiting.', type: 'choice', options: YESNO, symptom: 'Nausea or vomiting' },
  { id: 50, section: 'body', text: 'I experienced dizziness.', type: 'choice', options: YESNO, symptom: 'Dizziness' },

  // ── ADDITIONAL HEALTH INFORMATION ─────────────────────────────────
  { id: 51, section: 'extra', text: 'I experienced diarrhea or constipation.', type: 'choice', options: YESNO, symptom: 'Diarrhea or constipation' },
  { id: 52, section: 'extra', text: 'I noticed a skin rash.', type: 'choice', options: YESNO, symptom: 'Skin rash' },
  { id: 53, section: 'extra', text: 'I experienced unusual weakness.', type: 'choice', options: YESNO, symptom: 'Unusual weakness' },
  { id: 54, section: 'extra', text: 'Other symptoms I experienced: ____.', type: 'text', maxLength: 300, long: true },
  { id: 55, section: 'extra', text: 'My symptoms started ____.', type: 'text', maxLength: 120, suggestions: ['today', 'yesterday', '2–3 days ago', 'about a week ago', 'more than a week ago', 'more than a month ago'] },
  { id: 56, section: 'extra', text: 'My symptom severity is ____ out of 10.', type: 'number', min: 0, max: 10, step: 1 },
  { id: 57, section: 'extra', text: 'My symptoms are ____.', type: 'choice', options: ['Improving', 'Same', 'Getting worse'] },
  { id: 58, section: 'extra', text: 'My previously diagnosed health conditions (optional): ____.', type: 'text', maxLength: 300, long: true },
  { id: 59, section: 'extra', text: 'I followed my prescribed medication instructions.', type: 'choice', options: ['Yes', 'No', 'Not applicable'] },
  { id: 60, section: 'extra', text: 'Other health information I want to tell YHOD: ____.', type: 'text', maxLength: 600, long: true },
];

export const QUESTION_BY_ID = Object.fromEntries(QUESTIONS.map((q) => [q.id, q]));
export const TOTAL_QUESTIONS = QUESTIONS.length; // 60

export const TEMP_LIMITS = { C: { min: 30, max: 45 }, F: { min: 86, max: 113 } };

/**
 * Validate + normalise one answer. Returns { ok:true, value } (value === undefined
 * means "skipped") or { ok:false, message }.
 */
export function normaliseAnswer(q, raw) {
  if (raw === undefined || raw === null || raw === '') return { ok: true, value: undefined };
  switch (q.type) {
    case 'number': {
      const n = typeof raw === 'number' ? raw : Number(String(raw).replace(',', '.').trim());
      if (!Number.isFinite(n)) return { ok: false, message: 'Please enter a number.' };
      if (n < q.min || n > q.max) return { ok: false, message: `Please enter a value between ${q.min} and ${q.max}.` };
      return { ok: true, value: Math.round(n * 100) / 100 };
    }
    case 'rating': {
      const n = Number(raw);
      if (!Number.isInteger(n) || n < 1 || n > q.max) return { ok: false, message: `Choose a value from 1 to ${q.max}.` };
      return { ok: true, value: n };
    }
    case 'choice':
    case 'select': {
      const s = String(raw).trim();
      const hit = q.options.find((o) => o.toLowerCase() === s.toLowerCase());
      if (!hit) return { ok: false, message: 'Please choose one of the options.' };
      return { ok: true, value: hit };
    }
    case 'time': {
      const s = String(raw).trim();
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(s)) return { ok: false, message: 'Please enter a time like 22:30.' };
      return { ok: true, value: s };
    }
    case 'temperature': {
      if (typeof raw !== 'object') return { ok: false, message: 'Please enter a temperature.' };
      if (raw.value === undefined || raw.value === null || raw.value === '') return { ok: true, value: undefined };
      const unit = String(raw.unit || 'C').toUpperCase() === 'F' ? 'F' : 'C';
      const n = Number(String(raw.value).replace(',', '.'));
      const lim = TEMP_LIMITS[unit];
      if (!Number.isFinite(n)) return { ok: false, message: 'Please enter a number.' };
      if (n < lim.min || n > lim.max) return { ok: false, message: `Body temperature in °${unit} should be between ${lim.min} and ${lim.max}. Check the unit.` };
      return { ok: true, value: { value: Math.round(n * 10) / 10, unit } };
    }
    case 'text': {
      // strip control characters, collapse whitespace
      const s = String(raw).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim();
      if (!s) return { ok: true, value: undefined };
      if (s.length > q.maxLength) return { ok: false, message: `Please keep this under ${q.maxLength} characters.` };
      return { ok: true, value: s };
    }
    default:
      return { ok: false, message: 'Unknown question type.' };
  }
}

/** Validate a whole answers object: { "1": 8, "6": "Yes", ... } */
export function normaliseAnswers(input) {
  const clean = {};
  const errors = {};
  if (!input || typeof input !== 'object' || Array.isArray(input)) return { clean, errors: { _: 'Answers must be an object.' } };
  for (const q of QUESTIONS) {
    const r = normaliseAnswer(q, input[q.id] ?? input[String(q.id)]);
    if (!r.ok) errors[q.id] = r.message;
    else if (r.value !== undefined) clean[q.id] = r.value;
  }
  return { clean, errors };
}

export function celsius(temp) {
  if (!temp || typeof temp.value !== 'number') return null;
  return temp.unit === 'F' ? Math.round(((temp.value - 32) * 5) / 9 * 10) / 10 : temp.value;
}

/** Human sentence for one answered question, e.g. "I drank 8 glasses of water today." */
export function answerSentence(q, value) {
  if (value === undefined || value === null) return null;
  if (q.type === 'temperature') return q.text.replace('____ °C/°F', `${value.value} °${value.unit}`);
  if (q.text.includes('____')) return q.text.replace('____', String(value));
  return `${q.text} — ${value}`; // yes / no style statements
}

/** Hours between a bedtime and a wake time given as HH:MM (wraps past midnight). */
export function sleepDuration(bed, wake) {
  if (!bed || !wake) return null;
  const [bh, bm] = bed.split(':').map(Number);
  const [wh, wm] = wake.split(':').map(Number);
  let mins = wh * 60 + wm - (bh * 60 + bm);
  if (mins <= 0) mins += 24 * 60;
  if (mins > 20 * 60) return null;
  return Math.round((mins / 60) * 4) / 4;
}
