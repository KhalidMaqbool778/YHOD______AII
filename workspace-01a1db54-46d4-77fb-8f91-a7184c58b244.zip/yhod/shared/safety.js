// YHOD — deterministic safety layer (shared by browser and server).
//
// This is NOT artificial intelligence and it never replaces Gemini's analysis.
// It is a small set of fixed rules that guarantees certain red flags (for example
// a temperature of 105 °F, or "I have chest pain") always produce immediate
// emergency advice — instantly in the browser, and again on the server — even
// if the AI request is slow or fails. Gemini still reads every message itself.

import { celsius } from './questions.js';

export const EMERGENCY_TEMP_C = 40.0; // 104 °F
export const HIGH_TEMP_C = 39.0; // 102.2 °F
export const LOW_TEMP_C = 35.0; // 95 °F

export const DANGER_SYMPTOMS = ['chest pain', 'severe breathing difficulty', 'seizures', 'fainting', 'severe bleeding', 'severe confusion'];

const PATTERNS = [
  { code: 'chest_pain', label: 'Chest pain', re: /\bchest\s*(?:pain|pains|pressure|tightness|heaviness)|\bpain\s+in\s+(?:my|the)\s+chest|\bchest\s+(?:is\s+)?hurt(?:s|ing)?/i },
  { code: 'breathing', label: 'Breathing difficulty', re: /\b(?:can(?:'|’|no)?t|cannot|unable\s+to|hard\s+to|struggl(?:e|ing)\s+to|difficult\s+to)\s+breath(?:e|ing)?|\bdifficulty\s+(?:in\s+|with\s+)?breathing|\bbreathing\s+(?:is\s+)?(?:difficult(?:y|ies)?|problems?|trouble)|\btrouble\s+breathing|\bshort(?:ness)?\s+of\s+breath|\bbreathless(?:ness)?|\bgasping|\bchoking|\b(?:lips|face)\s+(?:are\s+|is\s+|turning\s+|look\s+)?blue/i },
  { code: 'seizure', label: 'Seizure', re: /\bseizures?\b|\bconvulsions?\b|\bhaving\s+(?:a\s+)?fits?\b/i },
  { code: 'fainting', label: 'Fainting or loss of consciousness', re: /\bfaint(?:ed|ing|s)?\b|\bpass(?:ed|ing)?\s+out\b|\bblack(?:ed)?\s*out\b|\bunconscious\b|\bcollaps(?:e|ed|ing)\b|\blost\s+consciousness|\bunresponsive\b/i },
  { code: 'bleeding', label: 'Severe bleeding', re: /\b(?:severe|heavy|heavily|a\s+lot\s+of|lots\s+of|uncontrolled|profuse)\s+bleeding|\bbleeding\s+(?:heavily|a\s+lot|badly|won(?:'|’)?t\s+stop|will\s+not\s+stop|does(?:n(?:'|’)?t|\s+not)\s+stop|is\s+not\s+stopping)|\b(?:vomit(?:ing|ed)?|cough(?:ing|ed)?(?:\s+up)?|throw(?:ing)?\s+up)\s+blood|\bblood\s+in\s+(?:my\s+)?vomit/i },
  { code: 'confusion', label: 'Severe confusion', re: /\b(?:severe(?:ly)?|very|sudden(?:ly)?|extremely|really)\s+confus(?:ed|ion)|\bdisoriented\b|\bslurred\s+speech|\bcan(?:'|’|no)?t\s+(?:speak|stay\s+awake)|\bface\s+(?:is\s+)?droop(?:ing|ed|s)?|\bweak(?:ness)?\s+on\s+one\s+side/i },
  { code: 'self_harm', label: 'Thoughts of self-harm', re: /\bsuicid(?:e|al)\b|\bkill(?:ing)?\s+myself\b|\bend\s+my\s+(?:own\s+)?life\b|\bhurt(?:ing)?\s+myself\b|\bself[-\s]?harm/i },
  { code: 'allergic', label: 'Possible severe allergic reaction', re: /\banaphyla|\b(?:throat|tongue)\s+(?:is\s+)?(?:swelling|swollen|closing)|\bswollen\s+(?:throat|tongue)/i },
  { code: 'overdose', label: 'Possible overdose or poisoning', re: /\boverdos(?:e|ed|ing)\b|\bpoison(?:ed|ing)\b|\bswallowed\s+(?:bleach|chemicals?|a\s+battery)/i },
];

const CLAUSE_BREAK = /[.;!?\n]|\b(?:but|however|except|although|though|yet|then|and\s+now|now\s+i)\b/gi;
const NEG_WORD = /\b(?:no|not|none|never|without|denies|deny|nor|neither|nahi|nahin|free\s+of)\b|n(?:'|’)t\b/gi;
const HISTORY = /\b(?:years?\s+ago|months?\s+ago|last\s+(?:year|month)|in\s+(?:19|20)\d\d|history\s+of|used\s+to|previously|in\s+the\s+past|as\s+a\s+child|when\s+i\s+was|childhood)\b/i;

function clauseBefore(text, index) {
  const before = text.slice(Math.max(0, index - 140), index);
  const re = new RegExp(CLAUSE_BREAK.source, 'gi');
  let cut = 0;
  let m;
  while ((m = re.exec(before))) cut = m.index + m[0].length;
  return before.slice(cut);
}

/** True when the phrase at `index` is negated ("no chest pain") or clearly historical ("fainted last year"). */
function isDismissed(text, index, length) {
  // An opening "No," / "Yes," is an answer particle, not a negation of what follows.
  const clause = clauseBefore(text, index).replace(/^\s*(?:no|nope|nah|yes|yeah|ok|okay)\s*,\s*/i, '');
  const re = new RegExp(NEG_WORD.source, 'gi');
  let last = null;
  let m;
  while ((m = re.exec(clause))) last = m;
  if (last) {
    const between = clause.slice(last.index + last[0].length).trim();
    const words = between ? between.split(/\s+/).length : 0;
    if (words <= 10) return true;
  }
  const after = text.slice(index, index + length + 48).split(/[.;!?\n]/)[0];
  return HISTORY.test(clause) || HISTORY.test(after);
}

const TEMP_KEYWORD = /(?:fever|temp(?:erature)?|thermometer|bukha+r)(?:\s+[a-z]+){0,4}\s*[:=]?\s*$/i;
const NOT_TEMP_BEFORE = /(?:\bage|\baged|\bi\s+am|\bi(?:'|’)?m|\bweigh[ts]?|\bweight|\bpulse|\bbp|\bheart\s+rate|\bsugar|\bglucose|\bspo2|\boxygen|\bsaturation|\bfor|\bsince)\s*(?:is|of|was|:)?\s*$/i;
const NOT_TEMP_AFTER = /^\s*(?:years?|yrs?|y\/o|yo\b|days?|hrs?|hours?|mins?|minutes?|weeks?|months?|kgs?|lbs?|pounds|mg|ml|bpm|%|times|glasses|steps|cm|inch(?:es)?|am\b|pm\b|:\d)/i;

/**
 * Pull body-temperature readings out of free text.
 * Returns [{ value, unit, celsius }]. `assumeTemperature` lets a bare number
 * ("105") count when the question being answered is the temperature question.
 */
export function extractTemperatures(text, { assumeTemperature = false } = {}) {
  const out = [];
  if (!text) return out;
  const s = String(text).replace(/(\d),(\d)/g, '$1.$2');
  const re = /(?<![\d.])(\d{2,3}(?:\.\d{1,2})?)(?![\d])\s*(°\s*[cf]\b|º\s*[cf]\b|degrees?(?:\s*(?:celsius|centigrade|fahrenheit|[cf]\b))?|deg\s*[cf]?\b|celsius|centigrade|fahrenheit|[cf]\b|°|º)?/gi;
  let m;
  while ((m = re.exec(s))) {
    const value = Number(m[1]);
    const unitRaw = (m[2] || '').toLowerCase().trim();
    const before = clauseBefore(s, m.index);
    const after = s.slice(m.index + m[0].length, m.index + m[0].length + 14);
    const hasKeyword = TEMP_KEYWORD.test(before);
    const hasUnit = unitRaw !== '';
    if (!hasUnit && !hasKeyword && !assumeTemperature) continue;
    if (!hasUnit && (NOT_TEMP_AFTER.test(after) || (!hasKeyword && NOT_TEMP_BEFORE.test(before)))) continue;
    let unit = null;
    if (/f/.test(unitRaw) && !/c/.test(unitRaw)) unit = 'F';
    else if (/c/.test(unitRaw)) unit = 'C';
    if (!unit) {
      if (value >= 86 && value <= 115) unit = 'F';
      else if (value >= 30 && value <= 45) unit = 'C';
      else continue;
    }
    if (unit === 'F' && (value < 86 || value > 115)) continue;
    if (unit === 'C' && (value < 30 || value > 45)) continue;
    // a lone "c"/"f" letter with no temperature wording must at least look like a body temperature
    if (/^[cf]$/.test(unitRaw) && !hasKeyword && !assumeTemperature) {
      const plausible = unit === 'F' ? value >= 94 && value <= 110 : value >= 34 && value <= 43;
      if (!plausible) continue;
    }
    const c = unit === 'F' ? Math.round((((value - 32) * 5) / 9) * 10) / 10 : value;
    out.push({ value, unit, celsius: c });
  }
  return out;
}

/**
 * Scan a free-text message for red flags.
 * opts.assumeTemperature — treat a bare number as a temperature reading.
 * opts.temperatureOnly   — only apply the temperature rule (used for answers
 *                          about history, age, medicines… where keywords like
 *                          "seizures" usually describe the past).
 * Returns { emergency:boolean, flags:[{code,label,detail}] }.
 */
export function detectRedFlags(text, opts = {}) {
  const flags = [];
  const s = String(text || '');
  if (!s.trim()) return { emergency: false, flags };
  if (!opts.temperatureOnly) {
    for (const p of PATTERNS) {
      const re = new RegExp(p.re.source, 'gi');
      let m;
      while ((m = re.exec(s))) {
        if (!isDismissed(s, m.index, m[0].length)) {
          flags.push({ code: p.code, label: p.label, detail: m[0] });
          break;
        }
        if (m.index === re.lastIndex) re.lastIndex++;
      }
    }
  }
  for (const t of extractTemperatures(s, opts)) {
    if (t.celsius >= EMERGENCY_TEMP_C) {
      flags.push({ code: 'very_high_temperature', label: `Very high temperature (${t.value} °${t.unit})`, detail: `${t.value} °${t.unit}` });
      break;
    }
    if (t.celsius < LOW_TEMP_C) {
      flags.push({ code: 'very_low_temperature', label: `Very low temperature (${t.value} °${t.unit})`, detail: `${t.value} °${t.unit}` });
      break;
    }
  }
  return { emergency: flags.length > 0, flags };
}

const YES = /^\s*(?:yes|yeah|yep|yup|ya|y|ji|jee|haan|han|i\s+do|i\s+am|i\s+have|sure|correct|true)\b/i;
const NO = /^\s*(?:no(?!\s+idea)|nope|nah|n|none|not\s+really|nahi|nahin|i\s+don(?:'|’)?t(?!\s+know)|i\s+do\s+not(?!\s+know)|i\s+am\s+not(?!\s+sure)|i(?:'|’)m\s+not(?!\s+sure)|nothing)\b/i;

/** Interpret the reply to the opening "any dangerous symptoms?" question → 'yes' | 'no' | 'unclear'. */
export function interpretDangerAnswer(text) {
  const s = String(text || '').trim();
  if (!s) return 'unclear';
  if (detectRedFlags(s).emergency) return 'yes';
  if (/\b(?:not\s+sure|unsure|don(?:'|’)?t\s+know|do\s+not\s+know|maybe|perhaps|might)\b/i.test(s)) return 'unclear';
  if (NO.test(s)) return 'no';
  if (YES.test(s)) return 'yes';
  return 'unclear';
}

/**
 * Fixed safety rules for a submitted daily check-in.
 * Returns [{ level:'emergency'|'urgent'|'care', code, title, text }]
 */
export function checkinSafetyNotices(answers) {
  const a = answers || {};
  const yes = (id) => a[id] === 'Yes';
  const notices = [];
  if (yes(47)) {
    notices.push({ level: 'emergency', code: 'chest_pain', title: 'You reported chest pain', text: 'Chest pain can be serious. If it is happening now, is severe or new, or comes with breathlessness, sweating, nausea, or pain spreading to the arm, jaw or back, contact your local emergency services immediately.' });
  }
  if (yes(46)) {
    notices.push({ level: 'emergency', code: 'breathing', title: 'You reported difficulty breathing', text: 'If you are struggling to breathe right now, cannot speak in full sentences, or your lips look blue, contact your local emergency services immediately. Otherwise please arrange to be seen by a doctor today.' });
  }
  const c = celsius(a[41]);
  if (c !== null) {
    const shown = `${a[41].value} °${a[41].unit}`;
    if (c >= EMERGENCY_TEMP_C) notices.push({ level: 'emergency', code: 'very_high_temperature', title: `Very high temperature recorded (${shown})`, text: 'A body temperature this high needs emergency medical assessment now. Contact your local emergency services or go to the nearest emergency department.' });
    else if (c >= HIGH_TEMP_C) notices.push({ level: 'urgent', code: 'high_temperature', title: `High temperature recorded (${shown})`, text: 'Please contact a doctor today, and seek urgent help sooner if the fever rises, lasts more than 3 days, or comes with a stiff neck, rash, confusion or breathing difficulty.' });
    else if (c < LOW_TEMP_C) notices.push({ level: 'urgent', code: 'very_low_temperature', title: `Very low temperature recorded (${shown})`, text: 'Please re-check the reading. If it is correct, or you feel very cold, drowsy or confused, seek urgent medical help.' });
  }
  const sev = typeof a[56] === 'number' ? a[56] : null;
  if (sev !== null && sev >= 8) {
    const worse = a[57] === 'Getting worse';
    notices.push({ level: worse ? 'emergency' : 'urgent', code: 'severe_symptoms', title: `You rated your symptoms ${sev} out of 10${worse ? ' and getting worse' : ''}`, text: worse ? 'Severe symptoms that are getting worse need urgent medical assessment now. If you feel you are in danger, contact your local emergency services.' : 'Symptoms this severe should be assessed by a doctor today.' });
  } else if (a[57] === 'Getting worse') {
    notices.push({ level: 'care', code: 'worsening', title: 'You said your symptoms are getting worse', text: 'Please arrange to speak with a doctor soon, and seek urgent help if they become severe.' });
  }
  if (yes(38)) {
    notices.push({ level: 'care', code: 'low_mood', title: 'You reported unusual sadness or worry', text: 'Thank you for sharing that. If these feelings continue or feel overwhelming, please talk to someone you trust or a health professional. If you ever feel unsafe or think about harming yourself, contact your local emergency services right away.' });
  }
  // free-text boxes about today (not the "previously diagnosed conditions" box, which is history)
  const free = [a[20], a[30], a[40], a[54], a[60]].filter(Boolean).join(' . ');
  for (const f of detectRedFlags(free).flags) {
    if (notices.some((n) => n.code === f.code)) continue;
    notices.push({ level: 'emergency', code: f.code, title: `You mentioned: ${f.label.toLowerCase()}`, text: 'This can be a sign of a medical emergency. If it is happening now, contact your local emergency services or go to the nearest emergency department.' });
  }
  return notices;
}

/** Local emergency numbers, ordered so the visitor's likely country comes first. */
export function emergencyNumbers(timeZone) {
  const all = [
    { region: 'Pakistan', zones: /^Asia\/Karachi$/, numbers: [{ n: '1122', label: 'Rescue' }, { n: '115', label: 'Edhi Ambulance' }] },
    { region: 'India', zones: /^Asia\/(?:Kolkata|Calcutta)$/, numbers: [{ n: '112', label: 'Emergency' }, { n: '108', label: 'Ambulance' }] },
    { region: 'USA / Canada', zones: /^America\/(?:New_York|Chicago|Denver|Los_Angeles|Phoenix|Anchorage|Toronto|Vancouver|Detroit|Edmonton|Winnipeg|Halifax)/, numbers: [{ n: '911', label: 'Emergency' }] },
    { region: 'United Kingdom', zones: /^Europe\/London$/, numbers: [{ n: '999', label: 'Emergency' }] },
    { region: 'Europe & most other countries', zones: /^Europe\//, numbers: [{ n: '112', label: 'Emergency' }] },
  ];
  const tz = String(timeZone || '');
  const local = all.filter((r) => r.zones.test(tz));
  const rest = all.filter((r) => !local.includes(r));
  return [...local, ...rest].map(({ region, numbers }) => ({ region, numbers }));
}
