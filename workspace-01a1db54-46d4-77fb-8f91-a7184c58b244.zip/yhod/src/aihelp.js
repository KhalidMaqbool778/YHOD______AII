// YHOD — small helpers shared by the AI routes.
import { db, nowIso } from './db.js';
import { encJson, decJson } from './security.js';
import { reserveAi } from './ratelimit.js';
import { GeminiError } from './gemini.js';

/**
 * Run one Gemini task for the signed-in user with usage controls.
 * A request that never produced an answer is refunded to the user's daily allowance.
 */
export async function ai(ctx, kind, lock, fn) {
  const r = await reserveAi(ctx.user.id, kind, lock);
  try {
    const v = await fn();
    r.done();
    return v;
  } catch (e) {
    if (e instanceof GeminiError) await r.refund();
    else r.done();
    throw e;
  }
}

/** Per-user cache of AI answers, tied to a hash ("basis") of the data they were made from. */
export async function cacheGet(user, kind) {
  const row = await db.get('SELECT basis, value_enc, created_at FROM ai_cache WHERE user_id = ? AND kind = ?', user.id, kind);
  if (!row) return null;
  try {
    return { basis: row.basis, value: decJson(row.value_enc, user.id), createdAt: row.created_at };
  } catch {
    return null;
  }
}

export async function cacheSet(user, kind, basis, value) {
  await db.run(
    `INSERT INTO ai_cache (user_id, kind, basis, value_enc, created_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(user_id, kind) DO UPDATE SET basis = excluded.basis, value_enc = excluded.value_enc, created_at = excluded.created_at`,
    user.id, kind, basis, encJson(value, user.id), nowIso(),
  );
}

export function cleanText(v, max) {
  return String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim().slice(0, max);
}

export const firstName = (user) => String(user.name || '').trim().split(/\s+/)[0] || 'there';

const URGENCY = ['none', 'monitor', 'see_doctor', 'urgent', 'emergency'];
export const maxUrgency = (a, b) => (URGENCY.indexOf(b) > URGENCY.indexOf(a) ? b : a);
