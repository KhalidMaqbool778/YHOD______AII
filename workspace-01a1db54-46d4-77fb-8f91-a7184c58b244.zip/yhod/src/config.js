// YHOD — server configuration. Everything sensitive comes from environment
// variables (or the local .env file) and never reaches the browser.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadEnvFile(path.join(ROOT, '.env'));

const env = (k, d) => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : d);
const int = (k, d) => {
  const n = Number.parseInt(env(k, ''), 10);
  return Number.isFinite(n) ? n : d;
};
const bool = (k, d) => {
  const v = env(k, '');
  return v === '' ? d : /^(1|true|yes|on)$/i.test(v);
};
const list = (k, d) => env(k, d).split(',').map((s) => s.trim()).filter(Boolean);

// Where is YHOD running?
//   a server of its own   one long-lived process with a disk that keeps its files (node server.js)
//   serverless (Vercel)   short-lived function instances; the code directory is read-only and only /tmp can be
//                         written, and /tmp is emptied whenever an instance goes away
const serverless = bool('YHOD_SERVERLESS', !!process.env.VERCEL);
// A database that outlives function instances: a libSQL / Turso database reached over HTTPS.
// The names are the ones Vercel's Turso integration creates; LIBSQL_* is accepted as well.
const dbUrl = env('TURSO_DATABASE_URL', env('LIBSQL_URL', env('DATABASE_URL', ''))).trim();
const remoteDb = /^(libsql|turso|https?|wss?):\/\//i.test(dbUrl) ? dbUrl : '';
// The largest request or answer the platform lets through (Vercel Functions: 4.5 MB). 0 = no such limit.
const payloadLimit = int('MAX_PAYLOAD_BYTES', serverless ? 4_300_000 : 0);
const within = (n, cap) => (cap > 0 ? Math.min(n, cap) : n);

export const config = {
  port: int('PORT', 3000),
  host: env('HOST', '0.0.0.0'),
  serverless,
  platform: process.env.VERCEL ? 'vercel' : serverless ? 'serverless' : 'server',
  dataDir: path.resolve(ROOT, env('DATA_DIR', serverless ? '/tmp/yhod-data' : 'data')),
  publicDir: path.join(ROOT, 'public'),
  sharedDir: path.join(ROOT, 'shared'),
  voiceSeedDir: path.join(ROOT, 'voice'),
  db: {
    url: remoteDb,
    token: env('TURSO_AUTH_TOKEN', env('LIBSQL_AUTH_TOKEN', env('DATABASE_AUTH_TOKEN', ''))).trim(),
  },
  payloadLimit,
  trustProxy: bool('TRUST_PROXY', true),
  sessionDays: int('SESSION_DAYS', 30),
  dataKey: env('YHOD_DATA_KEY', ''),
  // Allow the site to be shown inside another site's frame (needed for embedded previews).
  allowEmbedding: bool('ALLOW_EMBEDDING', false),

  gemini: {
    apiKey: env('GEMINI_API_KEY', '').trim(),
    base: env('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta').replace(/\/+$/, ''),
    // Ordered preference lists. If a model is slow, overloaded, out of quota or retired,
    // YHOD automatically moves on to the next one and shows which model answered.
    //  - textModels / visionModels: best quality first (symptom assessments, treatment information, photos)
    //  - fastModels: quickest and most generous first (conversation turns, daily feedback, notes, speech-to-text)
    textModels: list('GEMINI_TEXT_MODELS', 'gemini-3.6-flash,gemini-3-flash-preview,gemini-3.5-flash-lite,gemini-flash-lite-latest,gemini-3.8-flash,gemini-3.1-flash-lite'),
    visionModels: list('GEMINI_VISION_MODELS', 'gemini-3.6-flash,gemini-3-flash-preview,gemini-3.5-flash-lite,gemini-flash-lite-latest,gemini-3.8-flash,gemini-3.1-flash-lite'),
    fastModels: list('GEMINI_FAST_MODELS', 'gemini-3.5-flash-lite,gemini-flash-lite-latest,gemini-3-flash-preview,gemini-3.1-flash-lite,gemini-3.6-flash'),
    ttsModels: list('GEMINI_TTS_MODELS', 'gemini-3.8-flash-lite-tts,gemini-3.8-flash-tts,gemini-3.1-flash-tts-preview,gemini-2.5-flash-preview-tts'),
    ttsVoice: env('GEMINI_TTS_VOICE', 'Sulafat'),
    // How the brand name is written for the speech model only (subtitles always show "YHOD").
    spokenName: env('YHOD_SPOKEN_NAME', 'YHOD'),
  },

  limits: {
    // per signed-in user, per day
    textPerDay: int('AI_DAILY_TEXT', 120),
    imagePerDay: int('AI_DAILY_IMAGE', 20),
    voicePerDay: int('AI_DAILY_VOICE', 80),
    transcribePerDay: int('AI_DAILY_TRANSCRIBE', 40),
    // whole site, per day (protects the API key)
    globalPerDay: int('AI_GLOBAL_DAILY', 3000),
    // bursts
    aiPerMinute: int('AI_PER_MINUTE', 20),
    apiPerMinute: int('API_PER_MINUTE', 240),
    authPer10Min: int('AUTH_PER_10_MIN', 30),
    // A photo or a recording travels as base64 inside JSON (4 bytes for every 3), so on a platform with a
    // payload limit the files themselves must be smaller than that limit.
    maxImageBytes: within(int('MAX_IMAGE_BYTES', 6 * 1024 * 1024), Math.floor((payloadLimit - 128 * 1024) * 3 / 4)),
    maxAudioBytes: within(int('MAX_AUDIO_BYTES', 3 * 1024 * 1024), Math.floor((payloadLimit - 128 * 1024) * 3 / 4)),
    // The longest YHOD waits for Gemini within one request. A serverless function is stopped by its platform
    // after a fixed time (60 s in vercel.json), and YHOD must answer by itself before that happens.
    aiTotalMs: int('AI_TOTAL_MS', serverless ? 50_000 : 0),
  },
};

export { INTRO_VOICE_TEXT, EMERGENCY_VOICE_TEXT, MEDICINE_DISCLAIMER } from '../shared/copy.js';
