// YHOD — the database.
// One small asynchronous interface over two kinds of storage:
//   file     SQLite in a file, through Node's built-in `node:sqlite` (Node 22.13+): for a server with a disk
//            of its own. On older Node the `better-sqlite3` package is used if it happens to be installed.
//   remote   a libSQL / Turso database reached over HTTPS: for platforms without a lasting disk (Vercel and
//            other serverless hosts). Chosen when TURSO_DATABASE_URL is set.
// Every call returns a promise, whichever storage is in use, so the rest of YHOD is written once.
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { createRemote } from './libsql-http.js';

export const nowIso = () => new Date().toISOString();

// Raise this number whenever the table definitions below change.
const SCHEMA_VERSION = '3';
const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  tz TEXT NOT NULL DEFAULT 'UTC',
  settings TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  opened_at TEXT                    -- when a signed-in request first arrived for this workspace; NULL = set up but never opened
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,              -- SHA-256 of the session token (the token itself is never stored)
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS visits (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,               -- the visitor's local calendar date, YYYY-MM-DD
  first_at TEXT NOT NULL,
  last_at TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id, date)
);
CREATE TABLE IF NOT EXISTS checkins (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  answers_enc TEXT NOT NULL,        -- AES-256-GCM encrypted JSON
  metrics_enc TEXT,                 -- encrypted dashboard snapshot
  feedback_enc TEXT,                -- encrypted Gemini feedback
  feedback_model TEXT,
  answered INTEGER NOT NULL DEFAULT 0,
  urgency TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE (user_id, date)
);
CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,               -- 'start_yhod' | 'assistant'
  state_enc TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id, kind, updated_at);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content_enc TEXT NOT NULL,
  seq INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, seq);
CREATE TABLE IF NOT EXISTS images (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mime TEXT NOT NULL,
  bytes_enc BLOB NOT NULL,          -- AES-256-GCM encrypted image (stored only with explicit consent)
  size INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS assessments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,               -- 'symptom' | 'image' | 'skin'
  conversation_id TEXT,
  image_id TEXT,
  input_enc TEXT NOT NULL,
  result_enc TEXT NOT NULL,
  treatment_enc TEXT,
  level TEXT,
  model TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_assess_user ON assessments(user_id, created_at);
CREATE TABLE IF NOT EXISTS ai_cache (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  basis TEXT NOT NULL,              -- hash of the data the AI answer was based on
  value_enc TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, kind)
);
CREATE TABLE IF NOT EXISTS voice_cache (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hash TEXT NOT NULL,               -- hash of (text, tone, voice); the spoken text itself is only inside the encrypted audio
  mime TEXT NOT NULL,
  model TEXT,
  audio_enc BLOB NOT NULL,          -- AES-256-GCM encrypted audio
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, hash)
);
CREATE TABLE IF NOT EXISTS ai_usage (
  user_id TEXT NOT NULL,
  day TEXT NOT NULL,
  kind TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day, kind)
);

CREATE TABLE IF NOT EXISTS rate_windows (
  key TEXT PRIMARY KEY,             -- what is being counted, e.g. "login:<e-mail>"
  count INTEGER NOT NULL,
  reset_at INTEGER NOT NULL         -- when the count starts again (milliseconds since 1970)
);
CREATE TABLE IF NOT EXISTS voice_lines (
  key TEXT PRIMARY KEY,             -- kind and hash of (text, tone, voice) of a line that is the same for everyone
  mime TEXT NOT NULL,
  model TEXT,
  audio BLOB NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS app_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;

const norm = (params) => params.map((p) => (p === undefined ? null : typeof p === 'boolean' ? (p ? 1 : 0) : p));

// ── storage in a file ────────────────────────────────────────────────
async function openFile() {
  fs.mkdirSync(config.dataDir, { recursive: true, mode: 0o700 });
  const file = path.join(config.dataDir, 'yhod.sqlite');
  let raw = null;
  let label = '';
  try {
    const { DatabaseSync } = await import('node:sqlite');
    raw = new DatabaseSync(file);
    label = 'node:sqlite';
  } catch (e1) {
    try {
      const optional = 'better-sqlite3'; // only if someone installed it; it is not a dependency of YHOD
      const mod = await import(optional);
      raw = new mod.default(file);
      label = 'better-sqlite3';
    } catch (e2) {
      throw new Error(`No SQLite driver is available. Use Node.js 22.13 or newer (SQLite is built in). node:sqlite → ${e1.message}`);
    }
  }
  raw.exec('PRAGMA journal_mode = WAL');
  raw.exec('PRAGMA foreign_keys = ON');
  raw.exec('PRAGMA busy_timeout = 5000');
  raw.exec('PRAGMA synchronous = NORMAL');
  raw.exec('PRAGMA secure_delete = ON');
  try { fs.chmodSync(file, 0o600); } catch { /* best effort */ }

  const cache = new Map();
  const stmt = (sql) => {
    let s = cache.get(sql);
    if (!s) { s = raw.prepare(sql); cache.set(sql, s); }
    return s;
  };
  const plain = (row) => (row ? { ...row } : undefined);
  return {
    kind: 'file',
    label,
    where: file,
    get: async (sql, ...params) => plain(stmt(sql).get(...norm(params))),
    all: async (sql, ...params) => stmt(sql).all(...norm(params)).map(plain),
    run: async (sql, ...params) => ({ changes: Number(stmt(sql).run(...norm(params)).changes) }),
    // Runs from the first statement to the last without a pause in between, so nothing else can slip in.
    batch: async (list) => {
      raw.exec('BEGIN IMMEDIATE');
      try {
        for (const [sql, ...params] of list) stmt(sql).run(...norm(params));
        raw.exec('COMMIT');
      } catch (e) {
        try { raw.exec('ROLLBACK'); } catch { /* ignore */ }
        throw e;
      }
    },
    exec: async (sql) => { raw.exec(sql); },
    close() { try { raw.close(); } catch { /* ignore */ } },
  };
}

// ── storage in a libSQL / Turso database over HTTPS ──────────────────
function openRemote() {
  const remote = createRemote({ url: config.db.url, authToken: config.db.token });
  return {
    kind: 'remote',
    label: 'libSQL over HTTPS',
    where: remote.host,
    get: async (sql, ...params) => (await remote.execute(sql, norm(params))).rows[0],
    all: async (sql, ...params) => (await remote.execute(sql, norm(params))).rows,
    run: async (sql, ...params) => ({ changes: (await remote.execute(sql, norm(params))).changes }),
    batch: (list) => remote.batch(list.map(([sql, ...params]) => [sql, ...norm(params)])),
    exec: (sql) => remote.sequence(sql),
    close() { /* nothing stays open between requests */ },
  };
}

// ── opening, table definitions, upgrades ─────────────────────────────
let driver = null;
let opening = null;
/** A short description of the storage in use, for the start-up line and the status page. */
export let dbDriver = config.db.url ? 'libSQL over HTTPS' : 'node:sqlite';

async function open() {
  const d = config.db.url ? openRemote() : await openFile();
  // The table definitions are sent only when this database has not seen this version of them yet.
  let seen = null;
  try { seen = (await d.get("SELECT value FROM app_meta WHERE key = 'schema'"))?.value || null; } catch { seen = null; }
  if (seen !== SCHEMA_VERSION) {
    await d.exec(SCHEMA);
    // A database made by an earlier version of YHOD has no "opened_at" yet.
    const columns = (await d.all("SELECT name FROM pragma_table_info('users')")).map((c) => c.name);
    if (!columns.includes('opened_at')) {
      await d.exec('ALTER TABLE users ADD COLUMN opened_at TEXT');
      // A workspace that has a recorded visit or holds any record has evidently been opened before.
      await d.exec('UPDATE users SET opened_at = (SELECT MIN(first_at) FROM visits WHERE visits.user_id = users.id) WHERE opened_at IS NULL');
      await d.exec(`UPDATE users SET opened_at = created_at WHERE opened_at IS NULL AND (
        EXISTS (SELECT 1 FROM checkins WHERE checkins.user_id = users.id) OR EXISTS (SELECT 1 FROM conversations WHERE conversations.user_id = users.id)
        OR EXISTS (SELECT 1 FROM assessments WHERE assessments.user_id = users.id) OR EXISTS (SELECT 1 FROM images WHERE images.user_id = users.id))`);
    }
    await d.run("INSERT INTO app_meta (key, value) VALUES ('schema', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", SCHEMA_VERSION);
  }
  driver = d;
  dbDriver = d.label;
  return d;
}

/**
 * Resolves once the database can be used. Safe to call for every request: the work is done once, and if it
 * failed (the database was unreachable) the next call tries again.
 */
export function dbReady() {
  opening ||= open().catch((e) => { opening = null; throw e; });
  return opening;
}

function use() {
  if (!driver) throw new Error('The database is not open yet (await dbReady() first).');
  return driver;
}

export const db = {
  /** 'file' or 'remote' */
  get kind() { return config.db.url ? 'remote' : 'file'; },
  /**
   * Does what is saved outlive this process? Not when a serverless function keeps its SQLite file in the
   * platform's temporary directory: that directory is emptied whenever the function instance goes away.
   */
  get durable() { return !!config.db.url || !config.serverless; },
  get where() { return driver?.where || (config.db.url || path.join(config.dataDir, 'yhod.sqlite')); },
  get: (sql, ...params) => use().get(sql, ...params),
  all: (sql, ...params) => use().all(sql, ...params),
  run: (sql, ...params) => use().run(sql, ...params),
  /** Several statements as one unit: all of them take effect, or none. Each entry is [sql, ...values]. */
  batch: (list) => use().batch(list.filter(Boolean)),
  exec: (sql) => use().exec(sql),
  close() { if (driver) driver.close(); },
};
