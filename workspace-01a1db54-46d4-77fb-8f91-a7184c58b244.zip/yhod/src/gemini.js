// YHOD — the one and only place that talks to Google Gemini.
//
// • Uses the Gemini **Interactions API** (POST {base}/interactions), the
//   interface Google recommends for current models.
// • The API key is read from the server-side GEMINI_API_KEY environment
//   variable and sent in the `x-goog-api-key` header. It never reaches the browser.
// • `store:false` on every request: health data is not kept on Google's side
//   as a stored interaction.
// • Every answer YHOD shows comes from a real request made here. There are no
//   canned or simulated answers — if Gemini fails, the real error is surfaced.
// • Models can be busy, out of quota or slow. Each task has an ordered list of
//   models: a failure moves on to the next one at once, and a slow answer
//   starts the next model alongside ("hedging") so people are not left waiting.
import { config } from './config.js';

export class GeminiError extends Error {
  constructor(code, message, info = {}) {
    super(message);
    this.name = 'GeminiError';
    this.code = code;
    this.httpStatus = info.httpStatus || 502;
    this.detail = info.detail || null; // the real upstream message(s)
    this.retryAfterSec = info.retryAfterSec || null;
    this.attempts = info.attempts || [];
  }
}

// ── model health: skip models that are overloaded / out of quota for a while ──
const cooling = new Map(); // model → { until, reason }
const unsupported = new Map(); // model → Set('thinking' | 'safety' | 'style' | 'mp3')
const lastSuccess = {}; // purpose → { model, at, ms }

function coolDown(model, seconds, reason) {
  cooling.set(model, { until: Date.now() + seconds * 1000, reason });
}
function coolingInfo(model) {
  const c = cooling.get(model);
  if (!c) return null;
  if (c.until <= Date.now()) { cooling.delete(model); return null; }
  return c;
}
const TRANSIENT = new Set(['UNAVAILABLE', 'TIMEOUT', 'NETWORK', 'SLOW']);

function orderModels(models) {
  const ready = models.filter((m) => !coolingInfo(m));
  const transient = models.filter((m) => coolingInfo(m) && TRANSIENT.has(coolingInfo(m).reason)).sort((a, b) => coolingInfo(a).until - coolingInfo(b).until);
  const order = [...ready, ...transient];
  if (order.length) return order;
  // everything is resting (for example daily quota) — probe the one that comes back first
  return [...models].sort((a, b) => coolingInfo(a).until - coolingInfo(b).until).slice(0, 1);
}

// ── small global concurrency gate (kind to per-minute limits) ───────
const MAX_CONCURRENT = 8;
let active = 0;
const waiters = [];
async function gate() {
  if (active < MAX_CONCURRENT) { active++; return; }
  await new Promise((resolve) => waiters.push(resolve));
  active++;
}
function release() {
  active--;
  const next = waiters.shift();
  if (next) next();
}

function requireKey() {
  if (!config.gemini.apiKey) {
    throw new GeminiError('GEMINI_KEY_MISSING', 'The server has no Gemini API key. Set the GEMINI_API_KEY environment variable on the server and restart YHOD.', { httpStatus: 503, detail: 'GEMINI_API_KEY is not set.' });
  }
}

async function call(method, pathname, body, timeoutMs, signal) {
  const ctrl = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
  const onAbort = () => ctrl.abort();
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener('abort', onAbort, { once: true });
  }
  await gate();
  try {
    if (ctrl.signal.aborted) throw Object.assign(new Error('aborted'), { name: 'AbortError' });
    const res = await fetch(config.gemini.base + pathname, {
      method,
      headers: { 'content-type': 'application/json', 'x-goog-api-key': config.gemini.apiKey },
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* non-JSON error page */ }
    return { status: res.status, json, text, retryAfter: res.headers.get('retry-after') };
  } catch (e) {
    if (signal?.aborted && !timedOut) return { status: 0, cancelled: true };
    const aborted = e?.name === 'AbortError' || e?.name === 'TimeoutError';
    return { status: 0, timedOut: aborted, networkError: aborted ? null : String(e?.cause?.code || e?.message || e) };
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', onAbort);
    release();
  }
}

const upstreamMessage = (r) => String(r.json?.error?.message || r.json?.errors?.[0]?.message || (r.text || '').slice(0, 300) || '').trim();

function retrySeconds(r) {
  for (const d of r.json?.error?.details || []) {
    if (typeof d?.retryDelay === 'string') {
      const n = parseFloat(d.retryDelay);
      if (Number.isFinite(n)) return Math.ceil(n);
    }
  }
  const m = /retry in\s+(?:(\d+)h)?(?:(\d+)m)?(?:([\d.]+)s)?/i.exec(upstreamMessage(r));
  if (m && (m[1] || m[2] || m[3])) return Math.ceil((+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (parseFloat(m[3]) || 0));
  const header = Number.parseInt(r.retryAfter, 10);
  return Number.isFinite(header) && header > 0 ? header : null;
}

function classify(r) {
  const msg = upstreamMessage(r);
  if (r.status === 0) {
    return r.timedOut
      ? { code: 'TIMEOUT', message: 'No answer before the time limit.', cooldownSec: 180 }
      : { code: 'NETWORK', message: `Could not reach the Gemini API (${r.networkError}).`, cooldownSec: 20 };
  }
  if (r.status === 401 || (r.status === 400 && /api[ _-]?key/i.test(msg))) return { code: 'KEY_INVALID', message: msg || 'API key not valid.', fatal: true };
  if (r.status === 403) return { code: 'PERMISSION', message: msg || 'Permission denied.', fatal: true };
  if (r.status === 404) return { code: 'MODEL_UNAVAILABLE', message: msg || 'Model not found.', cooldownSec: 6 * 3600 };
  if (r.status === 429) {
    const retry = retrySeconds(r);
    // A quota refusal is not a hard cliff on the free tier. Measured on 2026-11-14: a voice model that had been refusing
    // with its daily-quota error answered a request about ten minutes later, and one minute after that it refused again
    // with "limit: 10 requests per day ... retry in 16h35m42s". So an exhausted model rests for at most 15 minutes and is
    // then tried again; a refused try costs about 0.4 s and the next model in the list answers instead.
    return { code: 'QUOTA', message: msg || 'Quota exceeded.', retryAfterSec: retry, cooldownSec: Math.min(Math.max(retry || 60, 20), 900) };
  }
  if (r.status >= 500) return { code: 'UNAVAILABLE', message: msg || `Gemini returned HTTP ${r.status}.`, cooldownSec: 120 };
  if (r.status === 400 && /safety|blocked|prohibited/i.test(msg)) return { code: 'BLOCKED', message: msg };
  return { code: 'BAD_REQUEST', message: msg || `Gemini returned HTTP ${r.status}.` };
}

function summarise(attempts) {
  const by = (code) => attempts.find((a) => a.code === code);
  const detail = attempts.map((a) => `${a.model}: ${a.status ? 'HTTP ' + a.status + ' — ' : ''}${a.message}`).join('\n') || 'No Gemini model could be tried in time.';
  const info = { attempts, detail };
  const key = by('KEY_INVALID');
  if (key) return new GeminiError('GEMINI_KEY_INVALID', `Gemini rejected the API key: ${key.message}`, { ...info, httpStatus: 502 });
  const perm = by('PERMISSION');
  if (perm) return new GeminiError('GEMINI_PERMISSION', `Gemini denied access: ${perm.message}`, { ...info, httpStatus: 502 });
  if (attempts.length && attempts.every((a) => a.code === 'QUOTA' || a.code === 'MODEL_UNAVAILABLE')) {
    const waits = attempts.map((a) => a.retryAfterSec).filter(Boolean);
    return new GeminiError('GEMINI_QUOTA', 'The Gemini API quota for this key is used up right now. Please try again later.', { ...info, httpStatus: 429, retryAfterSec: waits.length ? Math.min(...waits) : null });
  }
  const last = attempts[attempts.length - 1];
  if (by('BLOCKED') && (!last || last.code === 'BLOCKED')) return new GeminiError('GEMINI_BLOCKED', 'Gemini declined to answer this request because of its safety filters.', { ...info, httpStatus: 422 });
  if (last && (last.code === 'BAD_RESPONSE' || last.code === 'EMPTY' || last.code === 'FAILED')) return new GeminiError('GEMINI_BAD_RESPONSE', 'Gemini answered, but not in a form YHOD could safely use. Please try again.', { ...info, httpStatus: 502 });
  if (last && last.code === 'BAD_REQUEST') return new GeminiError('GEMINI_BAD_REQUEST', `Gemini rejected the request: ${last.message}`, { ...info, httpStatus: 502 });
  return new GeminiError('GEMINI_UNAVAILABLE', 'Gemini is busy or unreachable right now. Your information is safe — please try again in a moment.', { ...info, httpStatus: 503 });
}

/**
 * Try the models in order.
 *  - a failed attempt starts the next model immediately;
 *  - an attempt that has not answered after `hedgeMs` gets company: the next model
 *    starts alongside it (and another one every hedgeMs/2 after that); the first
 *    usable answer wins and the others are cancelled;
 *  - a model that was overtaken this way is treated as "slow" for a few minutes,
 *    so the following requests go straight to the models that are answering;
 *  - everything stops at `totalMs`.
 * run(model, signal, timeoutMs) resolves to { ok:true, value } | { ok:false, attempt, fatal? } | { cancelled:true }
 */
function raceModels({ purpose, models, hedgeMs, totalMs, attemptMs, run }) {
  const order = orderModels(models);
  const deadline = Date.now() + totalMs;
  const attempts = [];
  return new Promise((resolve, reject) => {
    let next = 0;
    let done = false;
    let timer = null;
    const live = new Map(); // AbortController → { model, started }
    const finish = (fn, v) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      for (const [c, info] of live) {
        if (fn === resolve && Date.now() - info.started >= hedgeMs) coolDown(info.model, 150, 'SLOW');
        c.abort();
      }
      fn(v);
    };
    const launch = () => {
      if (done) return;
      clearTimeout(timer);
      const remaining = deadline - Date.now();
      if (next >= order.length || remaining < 3500) {
        if (live.size === 0) finish(reject, summarise(attempts));
        return;
      }
      const model = order[next++];
      const ctrl = new AbortController();
      live.set(ctrl, { model, started: Date.now() });
      const settle = (r) => {
        live.delete(ctrl);
        if (done || r.cancelled) return;
        if (r.ok) {
          const slow = [...live.values()].filter((x) => Date.now() - x.started >= hedgeMs).map((x) => `${x.model}(slow)`);
          const failed = attempts.map((a) => `${a.model}(${a.code}${a.code === 'QUOTA' ? ': ' + (/limit:\s*([^)]*?)(?:\s+on Free Tier)?\)/i.exec(a.message || '')?.[1] || 'rate limit') : ''})`);
          if (slow.length || failed.length) console.info(`  Gemini[${purpose}] answered by ${r.value.model} in ${r.value.ms} ms after: ${[...failed, ...slow].join(', ')}`);
          return finish(resolve, { ...r.value, attempts });
        }
        attempts.push(r.attempt);
        if (r.fatal) return finish(reject, summarise(attempts));
        launch(); // a failure moves straight on to the next model
      };
      run(model, ctrl.signal, Math.min(attemptMs, remaining)).then(settle, (e) => settle({ ok: false, attempt: { model, status: 0, code: 'NETWORK', message: String(e?.message || e) } }));
      if (next < order.length) timer = setTimeout(launch, live.size > 1 ? Math.max(2500, Math.round(hedgeMs / 2)) : hedgeMs);
    };
    launch();
  });
}

function outputText(json) {
  const parts = [];
  for (const step of json?.steps || []) {
    if (step?.type !== 'model_output') continue;
    for (const c of step.content || []) if (c?.type === 'text' && typeof c.text === 'string') parts.push(c.text);
  }
  return parts.join('').trim();
}

// Where the platform stops a request after a fixed time (a serverless function), YHOD must give its own answer
// before that happens: the longest wait for Gemini within one request is then capped (AI_TOTAL_MS).
const withinBudget = (totalMs) => (config.limits.aiTotalMs > 0 ? Math.min(totalMs, config.limits.aiTotalMs) : totalMs);

export function parseJsonLoose(text) {
  let s = String(text).trim();
  const fence = /^```(?:json)?\s*([\s\S]*?)\s*```$/i.exec(s);
  if (fence) s = fence[1].trim();
  try { return JSON.parse(s); } catch { /* try the outermost braces */ }
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a >= 0 && b > a) return JSON.parse(s.slice(a, b + 1));
  throw new Error('not valid JSON');
}

const SAFETY_SETTINGS = ['harassment', 'hate_speech', 'sexually_explicit', 'dangerous_content'].map((type) => ({ type, threshold: 'block_only_high' }));

// Sends one interaction; if a model rejects an optional feature, retries without it and remembers.
async function interact(model, build, timeoutMs, signal) {
  const off = unsupported.get(model) || new Set();
  const deadline = Date.now() + timeoutMs;
  for (let i = 0; i < 4; i++) {
    const body = build(off);
    const r = await call('POST', '/interactions', body, Math.max(1000, deadline - Date.now()), signal);
    if (r.status === 400) {
      const msg = upstreamMessage(r);
      let changed = false;
      if (body.generation_config?.thinking_level === 'minimal' && !off.has('minimal') && /thinking/i.test(msg)) { off.add('minimal'); changed = true; }
      else if (!off.has('thinking') && body.generation_config?.thinking_level && /thinking/i.test(msg)) { off.add('thinking'); changed = true; }
      else if (!off.has('safety') && body.safety_settings && /safety/i.test(msg)) { off.add('safety'); changed = true; }
      else if (!off.has('style') && build.usesStyle && /annotation|speech[ _-]?metadata|style/i.test(msg)) { off.add('style'); changed = true; }
      else if (!off.has('mp3') && body.response_format?.mime_type === 'audio/mp3' && /mime|format|mp3|audio/i.test(msg)) { off.add('mp3'); changed = true; }
      if (changed) { unsupported.set(model, off); continue; }
    }
    return r;
  }
  return { status: 400, json: { error: { message: 'Request could not be adapted for this model.' } }, text: '' };
}

function failure(model, r, ms) {
  const c = classify(r);
  if (c.cooldownSec) coolDown(model, c.cooldownSec, c.code);
  return { ok: false, fatal: !!c.fatal, attempt: { model, status: r.status, code: c.code, message: c.message, retryAfterSec: c.retryAfterSec || null, ms } };
}

/**
 * Ask Gemini for a JSON answer (or plain text when no schema is given).
 *   input  — a string, or an array of content blocks:
 *            { type:'text', text } | { type:'image', data, mime_type } | { type:'audio', data, mime_type }
 *   schema — JSON Schema the answer must follow
 *   validate(data) — returns the cleaned answer or throws if unusable
 * Resolves to { data, model, usage, ms, attempts }.
 */
export async function generate({ purpose, models, system, input, schema, validate, thinking = 'low', maxOutputTokens = 4096, hedgeMs = 10000, attemptMs = 45000, totalMs = 55000 }) {
  totalMs = withinBudget(totalMs);
  requireKey();
  const run = async (model, signal, timeoutMs) => {
    const build = (off) => {
      const body = { model, input, store: false };
      if (system) body.system_instruction = system;
      const gc = {};
      const level = thinking === 'minimal' && off.has('minimal') ? 'low' : thinking; // some models have no "minimal" level
      if (level && !off.has('thinking')) gc.thinking_level = level;
      if (maxOutputTokens) gc.max_output_tokens = maxOutputTokens;
      if (Object.keys(gc).length) body.generation_config = gc;
      if (schema) body.response_format = { type: 'text', mime_type: 'application/json', schema };
      if (!off.has('safety')) body.safety_settings = SAFETY_SETTINGS;
      return body;
    };
    const started = Date.now();
    const r = await interact(model, build, timeoutMs, signal);
    const ms = Date.now() - started;
    if (r.cancelled) return { cancelled: true };
    if (r.status === 200 && r.json) {
      const state = r.json.status;
      const text = outputText(r.json);
      if (text && state !== 'failed' && state !== 'cancelled') {
        try {
          let data = schema ? parseJsonLoose(text) : text;
          if (validate) data = validate(data);
          lastSuccess[purpose] = { model: r.json.model || model, at: new Date().toISOString(), ms };
          cooling.delete(model);
          return { ok: true, value: { data, model: r.json.model || model, usage: r.json.usage || null, ms } };
        } catch (e) {
          return { ok: false, attempt: { model, status: 200, code: 'BAD_RESPONSE', message: `The answer could not be used (${e.message})${state === 'incomplete' ? ' — it was cut off' : ''}.`, ms } };
        }
      }
      const why = upstreamMessage(r) || (state ? `Interaction status: ${state}` : 'No text in the answer.');
      return { ok: false, attempt: { model, status: 200, code: /safety|block/i.test(why) ? 'BLOCKED' : state === 'failed' ? 'FAILED' : 'EMPTY', message: why, ms } };
    }
    return failure(model, r, ms);
  };
  return raceModels({ purpose, models, hedgeMs, totalMs, attemptMs, run });
}

// ── text to speech ──────────────────────────────────────────────────
export function pcmToWav(pcm, sampleRate = 24000, channels = 1, bits = 16) {
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE((sampleRate * channels * bits) / 8, 28);
  header.writeUInt16LE((channels * bits) / 8, 32);
  header.writeUInt16LE(bits, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

const TONES = {
  friendly: 'warm, friendly and natural, like a caring companion, at a relaxed conversational pace',
  serious: 'calm, clear and direct, serious but reassuring, speaking a little more slowly',
};

function sniffAudio(buf) {
  if (buf.length > 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WAVE') return 'audio/wav';
  if (buf.length > 4 && (buf.toString('latin1', 0, 3) === 'ID3' || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0))) return 'audio/mpeg';
  if (buf.length > 4 && buf.toString('latin1', 0, 4) === 'OggS') return 'audio/ogg';
  return null;
}

/**
 * Convert text to speech with a Gemini TTS model.
 * Resolves to { audio:Buffer, mime:'audio/mpeg'|'audio/wav', model, ms, attempts }.
 */
export async function synthesizeSpeech({ text, tone = 'friendly', hedgeMs = 20000, attemptMs = 45000, totalMs = 55000 }) {
  totalMs = withinBudget(totalMs);
  requireKey();
  const style = TONES[tone] || TONES.friendly;
  // "<...>" are vocal tags for Gemini TTS, so angle brackets are never passed through.
  let spoken = String(text).replace(/[<>]/g, ' ').replace(/\s+/g, ' ').trim();
  if (config.gemini.spokenName && config.gemini.spokenName !== 'YHOD') spoken = spoken.replace(/\bYHOD\b/g, config.gemini.spokenName);
  const run = async (model, signal, timeoutMs) => {
    const build = (off) => ({
      model,
      store: false,
      input: off.has('style')
        ? `Say in a ${style} voice: ${spoken}`
        : [{ type: 'user_input', content: [{ type: 'text', text: spoken, annotations: [{ type: 'speech_metadata', style }] }] }],
      response_format: off.has('mp3') ? { type: 'audio' } : { type: 'audio', mime_type: 'audio/mp3' },
      generation_config: { speech_config: [{ voice: config.gemini.ttsVoice }] },
    });
    build.usesStyle = true;
    const started = Date.now();
    const r = await interact(model, build, timeoutMs, signal);
    const ms = Date.now() - started;
    if (r.cancelled) return { cancelled: true };
    if (r.status === 200 && r.json) {
      let block = null;
      for (const step of r.json.steps || []) for (const c of step?.content || []) if (!block && c?.type === 'audio' && c.data) block = c;
      if (block) {
        let audio = Buffer.from(block.data, 'base64');
        let mime = sniffAudio(audio);
        if (!mime) {
          // headerless PCM (older preview models): wrap it so every browser can play it
          const rate = Number(/rate=(\d+)/.exec(String(block.mime_type || ''))?.[1]) || Number(block.sample_rate) || 24000;
          audio = pcmToWav(audio, rate, 1);
          mime = 'audio/wav';
        }
        if (audio.length > 2000) {
          lastSuccess.voice = { model: r.json.model || model, at: new Date().toISOString(), ms };
          cooling.delete(model);
          return { ok: true, value: { audio, mime, model: r.json.model || model, ms } };
        }
      }
      return { ok: false, attempt: { model, status: 200, code: 'EMPTY', message: upstreamMessage(r) || 'The speech model returned no audio.', ms } };
    }
    return failure(model, r, ms);
  };
  return raceModels({ purpose: 'voice', models: config.gemini.ttsModels, hedgeMs, totalMs, attemptMs, run });
}

// ── live status (no generation quota is used: this only lists models) ──
let listing = null; // { at, ok, names:Set|null, error }
export async function checkGemini(force = false) {
  if (!config.gemini.apiKey) return { configured: false, ok: false, error: { status: 0, code: 'GEMINI_KEY_MISSING', message: 'GEMINI_API_KEY is not set on the server.' } };
  if (!force && listing && Date.now() - listing.at < (listing.ok ? 10 * 60_000 : 30_000)) return describe();
  const r = await call('GET', '/models?pageSize=1000', null, 12000);
  if (r.status === 200 && Array.isArray(r.json?.models)) {
    const names = new Set(r.json.models.map((m) => String(m.name || '').replace(/^models\//, '')));
    listing = { at: Date.now(), ok: true, names, error: null };
    const all = new Set([...config.gemini.textModels, ...config.gemini.visionModels, ...config.gemini.fastModels, ...config.gemini.ttsModels]);
    for (const m of all) if (!names.has(m) && !coolingInfo(m)) coolDown(m, 12 * 3600, 'MODEL_UNAVAILABLE');
  } else {
    const c = classify(r);
    listing = { at: Date.now(), ok: false, names: null, error: { status: r.status, code: c.code, message: c.message } };
  }
  return describe();
}

function describe() {
  const g = config.gemini;
  const first = (models) => models.find((m) => !coolingInfo(m)) || null;
  const resting = [];
  for (const m of new Set([...g.textModels, ...g.visionModels, ...g.fastModels, ...g.ttsModels])) {
    const c = coolingInfo(m);
    if (c) resting.push({ model: m, reason: c.reason, seconds: Math.ceil((c.until - Date.now()) / 1000) });
  }
  return {
    configured: true,
    ok: !!listing?.ok,
    api: 'Gemini Interactions API (v1beta)',
    checkedAt: listing ? new Date(listing.at).toISOString() : null,
    error: listing?.error || null,
    models: { analysis: first(g.fastModels), assessment: first(g.textModels), vision: first(g.visionModels), conversation: first(g.fastModels), voice: first(g.ttsModels), voiceName: g.ttsVoice },
    lastSuccess,
    resting,
  };
}

export const geminiState = describe;
