// YHOD — dates, personal targets, dashboard numbers and the welcome logic.
// Everything here is computed from what is actually saved in the database.
import { db, nowIso } from './db.js';
import { decJson } from './security.js';
import { QUESTIONS, celsius, sleepDuration } from '../shared/questions.js';
import { HttpError } from './httpx.js';

// ── dates (always the visitor's own calendar day) ───────────────────
export function validTz(tz) {
  if (typeof tz !== 'string' || !tz || tz.length > 64) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch { return false; }
}
export function localDate(tz, d = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: validTz(tz) ? tz : 'UTC', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}
export const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + 'T00:00:00Z'));
export const dayNumber = (s) => { const [y, m, d] = s.split('-').map(Number); return Math.round(Date.UTC(y, m - 1, d) / 864e5); };
export const addDays = (s, n) => new Date((dayNumber(s) + n) * 864e5).toISOString().slice(0, 10);
export const daysBetween = (a, b) => dayNumber(b) - dayNumber(a);
export const todayFor = (user) => localDate(user.tz);

// ── personal targets ────────────────────────────────────────────────
export const DEFAULT_TARGETS = { water: 8, sleep: 8, activity: 30, steps: 8000, fruitVeg: 5 };
const TARGET_RANGES = { water: [1, 30], sleep: [3, 14], activity: [5, 600], steps: [500, 100000], fruitVeg: [1, 20] };

export function userSettings(user) {
  let s = {};
  try { s = JSON.parse(user.settings || '{}') || {}; } catch { s = {}; }
  return { targets: { ...DEFAULT_TARGETS, ...(s.targets || {}) }, tempUnit: s.tempUnit === 'F' ? 'F' : 'C' };
}
export const userTargets = (user) => userSettings(user).targets;

export function cleanTargets(input) {
  const out = {};
  if (!input || typeof input !== 'object') return out;
  for (const [k, [min, max]] of Object.entries(TARGET_RANGES)) {
    if (input[k] === undefined || input[k] === null || input[k] === '') continue;
    const n = Number(input[k]);
    if (!Number.isFinite(n) || n < min || n > max) throw new HttpError(422, 'INVALID_TARGET', `The ${k === 'fruitVeg' ? 'fruit and vegetable' : k} target must be between ${min} and ${max}.`);
    out[k] = k === 'sleep' ? Math.round(n * 2) / 2 : Math.round(n);
  }
  return out;
}

// ── dashboard numbers derived from one day's answers ────────────────
const SCORE = {
  mood: { 'Very low': 1, Low: 2, Okay: 3, Good: 4, Great: 5 },
  sleep: { 'Very poor': 1, Poor: 2, Fair: 3, Good: 4, Excellent: 5 },
};
const SYMPTOMS = QUESTIONS.filter((q) => q.symptom);

export function metricsFromAnswers(a) {
  const num = (id) => (typeof a[id] === 'number' && Number.isFinite(a[id]) ? a[id] : null);
  const yn = (id) => (a[id] === 'Yes' ? true : a[id] === 'No' ? false : null);
  const str = (id) => (typeof a[id] === 'string' && a[id].trim() ? a[id].trim() : null);
  const sum = (...v) => (v.every((x) => x === null) ? null : v.reduce((s, x) => s + (x || 0), 0));
  let sleepHours = num(23);
  let sleepFromTimes = false;
  if (sleepHours === null && str(21) && str(22)) { sleepHours = sleepDuration(a[21], a[22]); sleepFromTimes = sleepHours !== null; }
  const temp = a[41] && typeof a[41] === 'object' ? { value: a[41].value, unit: a[41].unit, celsius: celsius(a[41]) } : null;
  return {
    answered: Object.keys(a).length,
    water: num(1), otherFluids: num(2), fruits: num(3), vegetables: num(4), fruitVeg: sum(num(3), num(4)), meals: num(5),
    breakfast: yn(6), protein: yn(7), sugaryDrinks: num(8), snacks: num(9), appetite: str(10),
    walkMinutes: num(11), exerciseMinutes: num(12), stretchMinutes: num(13), activeMinutes: sum(num(11), num(12)),
    sittingBreaks: num(14), sittingHours: num(15), steps: num(16), outdoorMinutes: num(17), mainActivity: str(18), exercisePain: yn(19),
    bedtime: str(21), wakeTime: str(22), sleepHours, sleepFromTimes, sleepQuality: str(24), sleepQualityScore: SCORE.sleep[a[24]] ?? null,
    nightWakings: num(25), napMinutes: num(26), screenMinutes: num(27), lateCaffeine: yn(28), rested: yn(29),
    mood: str(31), moodScore: SCORE.mood[a[31]] ?? null, stress: num(32), energy: num(33), concentration: num(34),
    relaxed: yn(35), enjoyed: yn(36), social: yn(37), sadness: yn(38), relaxMinutes: num(39),
    temperature: temp,
    symptoms: SYMPTOMS.filter((q) => a[q.id] === 'Yes').map((q) => q.symptom),
    symptomsAnswered: SYMPTOMS.filter((q) => a[q.id] !== undefined).length,
    otherSymptoms: str(54), symptomOnset: str(55), severity: num(56), trend: str(57), conditions: str(58), medication: str(59),
  };
}

// ── reading saved check-ins ─────────────────────────────────────────
function readCheckin(user, row) {
  const answers = decJson(row.answers_enc, user.id) || {};
  return {
    id: row.id, date: row.date, answers, metrics: metricsFromAnswers(answers), answered: row.answered,
    feedback: decJson(row.feedback_enc, user.id), feedbackModel: row.feedback_model, urgency: row.urgency,
    createdAt: row.created_at, updatedAt: row.updated_at,
  };
}

export async function loadCheckin(user, date) {
  const row = await db.get('SELECT * FROM checkins WHERE user_id = ? AND date = ?', user.id, date);
  return row ? readCheckin(user, row) : null;
}

/** All check-ins from one date to another (both included), fetched in one go. → Map: date → check-in */
export async function loadCheckinsBetween(user, from, to) {
  const rows = await db.all('SELECT * FROM checkins WHERE user_id = ? AND date >= ? AND date <= ? ORDER BY date', user.id, from, to);
  return new Map(rows.map((row) => [row.date, readCheckin(user, row)]));
}

export async function checkinDates(user) {
  return (await db.all('SELECT date FROM checkins WHERE user_id = ? ORDER BY date', user.id)).map((r) => r.date);
}

/** Consecutive days ending today (or yesterday, when today is not done yet). */
export function streak(dates, today) {
  const set = new Set(dates);
  let d = set.has(today) ? today : addDays(today, -1);
  let n = 0;
  while (set.has(d)) { n++; d = addDays(d, -1); }
  return n;
}
function bestStreak(dates) {
  let best = 0;
  let run = 0;
  let prev = null;
  for (const d of [...dates].sort()) {
    run = prev && daysBetween(prev, d) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return best;
}

const pct = (v, target) => (v === null || v === undefined || !target ? null : Math.max(0, Math.min(999, Math.round((v / target) * 100))));

export async function buildDashboard(user, date) {
  const today = todayFor(user);
  const sel = isDate(date) && date <= today ? date : today;
  const targets = userTargets(user);
  const dates = await checkinDates(user);
  const days = await loadCheckinsBetween(user, addDays(sel, -6), sel); // the seven days shown, in one request
  const current = days.get(sel) || null;
  const m = current?.metrics || null;

  const week = [];
  for (let i = 6; i >= 0; i--) {
    const d = addDays(sel, -i);
    const c = days.get(d) || null;
    const x = c?.metrics;
    week.push({
      date: d, done: !!c,
      water: x?.water ?? null, sleepHours: x?.sleepHours ?? null, activeMinutes: x?.activeMinutes ?? null, steps: x?.steps ?? null,
      moodScore: x?.moodScore ?? null, stress: x?.stress ?? null, energy: x?.energy ?? null, fruitVeg: x?.fruitVeg ?? null,
      symptoms: x?.symptoms?.length ?? null,
    });
  }

  const habits = m ? [
    { key: 'water', label: 'Water', value: m.water, target: targets.water, unit: 'glasses', pct: pct(m.water, targets.water) },
    { key: 'sleep', label: 'Sleep', value: m.sleepHours, target: targets.sleep, unit: 'h', pct: pct(m.sleepHours, targets.sleep) },
    { key: 'activity', label: 'Activity', value: m.activeMinutes, target: targets.activity, unit: 'min', pct: pct(m.activeMinutes, targets.activity) },
    { key: 'steps', label: 'Steps', value: m.steps, target: targets.steps, unit: 'steps', pct: pct(m.steps, targets.steps) },
    { key: 'fruitVeg', label: 'Fruit & vegetables', value: m.fruitVeg, target: targets.fruitVeg, unit: 'servings', pct: pct(m.fruitVeg, targets.fruitVeg) },
  ] : [];

  return {
    date: sel, today, isToday: sel === today, hasCheckin: !!current, targets,
    metrics: m,
    habits,
    week,
    consistency: {
      days: week.map((w) => ({ date: w.date, done: w.done })),
      doneThisWeek: week.filter((w) => w.done).length,
      streak: streak(dates, today),
      bestStreak: bestStreak(dates),
      totalCheckins: dates.length,
    },
    feedback: current?.feedback || null,
    feedbackModel: current?.feedbackModel || null,
    updatedAt: current?.updatedAt || null,
    availableDates: dates,
  };
}

// ── visits + the three welcome messages ─────────────────────────────
export async function recordVisit(user) {
  const today = todayFor(user);
  const now = nowIso();
  await db.run(
    `INSERT INTO visits (user_id, date, first_at, last_at, count) VALUES (?, ?, ?, ?, 1)
     ON CONFLICT(user_id, date) DO UPDATE SET last_at = excluded.last_at, count = count + 1`,
    user.id, today, now, now,
  );
  return today;
}

export const WELCOME_TEXT = {
  first: (name) => `Welcome to YHOD, ${name}! I'm happy to have you here. Let's start taking care of your health together.`,
  daily: (name) => `Welcome to YHOD, ${name}! You come here daily to take care of your health. That's a wonderful habit. Continue building healthy habits and tracking your progress!`,
  away: (name) => `Welcome back to YHOD, ${name}! It's been a few days since your last visit. Please come daily to complete your health form and continue building healthier habits. Let's make your health journey better together!`,
};

/**
 * Chooses the welcome message from the dates actually saved for this person:
 *   first — no earlier visit and no earlier completed check-in exists;
 *   away  — the most recent earlier activity (visit or completed check-in) was 6 or more days ago;
 *   daily — otherwise.
 */
export async function welcomeFor(user) {
  const today = todayFor(user);
  const visits = (await db.all('SELECT date FROM visits WHERE user_id = ? ORDER BY date', user.id)).map((r) => r.date);
  const checkins = await checkinDates(user);
  const earlier = [...visits, ...checkins].filter((d) => d < today).sort();
  const last = earlier.length ? earlier[earlier.length - 1] : null;
  const gap = last ? daysBetween(last, today) : null;
  const type = last === null ? 'first' : gap >= 6 ? 'away' : 'daily';
  const lastCheckin = checkins.length ? checkins[checkins.length - 1] : null;
  return {
    type,
    message: WELCOME_TEXT[type](user.name),
    stats: {
      today,
      firstVisit: visits[0] || today,
      lastActivity: last,
      daysSinceLastActivity: gap,
      visitDays: new Set(visits).size,
      visitStreak: streak(visits, today),
      totalCheckins: checkins.length,
      checkinStreak: streak(checkins, today),
      lastCheckin,
      todayCheckinDone: checkins.includes(today),
    },
  };
}
