// YHOD — a tiny, dependency-free HTTP toolkit: router, JSON bodies, static
// files, security headers.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { config } from './config.js';

export class HttpError extends Error {
  constructor(status, code, message, extra = null) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "media-src 'self' blob: data:",
  "font-src 'self'",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

export function securityHeaders(secure, { api = false } = {}) {
  const h = {
    'Content-Security-Policy': CSP,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(self), microphone=(self), geolocation=(), payment=(), usb=()',
  };
  // API answers are only ever for this site's own pages.
  if (api || !config.allowEmbedding) h['Cross-Origin-Resource-Policy'] = 'same-origin';
  if (!config.allowEmbedding) {
    h['Content-Security-Policy'] += "; frame-ancestors 'none'";
    h['X-Frame-Options'] = 'DENY';
  }
  if (secure) h['Strict-Transport-Security'] = 'max-age=31536000';
  return h;
}

export function sendJson(res, status, data, headers = {}) {
  if (res.headersSent) return;
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': body.length, 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}

export function sendBuffer(res, status, buf, type, headers = {}) {
  if (res.headersSent) return;
  res.writeHead(status, { 'Content-Type': type, 'Content-Length': buf.length, 'Cache-Control': 'no-store', ...headers });
  res.end(buf);
}

export function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > limit) return reject(new HttpError(413, 'PAYLOAD_TOO_LARGE', 'That upload is too large.'));
    const chunks = [];
    let size = 0;
    let done = false;
    req.on('data', (c) => {
      if (done) return;
      size += c.length;
      if (size > limit) {
        done = true;
        reject(new HttpError(413, 'PAYLOAD_TOO_LARGE', 'That upload is too large.'));
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => { if (!done) { done = true; resolve(Buffer.concat(chunks)); } });
    req.on('error', (e) => { if (!done) { done = true; reject(e); } });
  });
}

export async function readJson(req, limit) {
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (type !== 'application/json') throw new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Requests must be sent as JSON.');
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  try {
    const v = JSON.parse(buf.toString('utf8'));
    if (v === null || typeof v !== 'object' || Array.isArray(v)) throw new Error('not an object');
    return v;
  } catch {
    throw new HttpError(400, 'BAD_JSON', 'The request body is not valid JSON.');
  }
}

export class Router {
  constructor() { this.routes = []; }
  add(method, pattern, opts, handler) {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:[a-zA-Z]+/g, (m) => { keys.push(m.slice(1)); return '([^/]+)'; }) + '/?$');
    this.routes.push({ method, pattern, re, keys, opts: opts || {}, handler });
  }
  find(method, pathname) {
    let pathMatched = false;
    for (const r of this.routes) {
      const m = r.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;
      const params = {};
      try { r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); }); } catch { return { badPath: true }; }
      return { route: r, params };
    }
    return pathMatched ? { methodNotAllowed: true } : null;
  }
}

export function clientIp(req) {
  if (config.trustProxy) {
    const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xff) return xff.slice(0, 64);
  }
  return req.socket.remoteAddress || 'unknown';
}

export function isSecureRequest(req) {
  if (req.socket.encrypted) return true;
  if (/\bhttps\b/i.test(String(req.headers['x-forwarded-proto'] || ''))) return true;
  // The page tells us its own scheme; lying only changes the flags on the liar's own cookie.
  return String(req.headers['x-yhod-proto'] || '') === 'https';
}

export function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (k && !(k in out)) out[k] = part.slice(i + 1).trim();
  }
  return out;
}

// ── static files ────────────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json; charset=utf-8',
  '.woff2': 'font/woff2', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.svg', '.json', '.webmanifest', '.txt']);
const staticCache = new Map(); // abs path → { mtimeMs, etag, raw, gz }

// ── fingerprinted addresses ─────────────────────────────────────────
// A script or style sheet is always addressed as /a/<fingerprint>/js/main.js, where the fingerprint is made
// from all the site's files. Change any file and the fingerprint changes, so every address changes with it.
// That makes the site immune to caches that hold on to a file longer than the server asked — a browser, or
// a gateway in front of the server. (Observed 2026-11-14 behind a hosted preview: scripts sent with
// "Cache-Control: no-cache" were still running in their old form at least half an hour after they had been
// changed, through six or more reloads, so two fixes never reached the browser.) A fingerprinted file may be
// kept for ever; the page that names the addresses is never stored; a file asked for under a plain or an
// outdated address is never stored either.
const FINGERPRINTED = /^\/a\/([A-Za-z0-9]{8,24})(\/.*)$/;
let fingerprint = { id: '', at: 0 };
const contentHashes = new Map(); // "public/js/main.js" → { size, mtimeMs, hash }

function eachFile(dir, prefix, visit) {
  let names = [];
  try { names = fs.readdirSync(dir).sort(); } catch { return; }
  for (const name of names) {
    if (name.startsWith('.')) continue;
    const abs = path.join(dir, name);
    let stat = null;
    try { stat = fs.statSync(abs); } catch { continue; }
    if (stat.isDirectory()) eachFile(abs, `${prefix}${name}/`, visit);
    else if (stat.isFile()) visit(`${prefix}${name}`, stat);
  }
}

/**
 * The fingerprint of the site's files as they are right now. It is made from what the files contain, not from
 * their dates: the same files give the same fingerprint on every machine and in every deployment, and changed
 * files never give the old one (a deployment platform may give every file the same date).
 * On a server the files are looked at again at most every 0.4 s, and a file is read again only when its size or
 * date changed; in a serverless function the files cannot change, so this is worked out once.
 */
export function assetsId() {
  const now = Date.now();
  if (fingerprint.id && (config.serverless || now - fingerprint.at < 400)) return fingerprint.id;
  const hash = crypto.createHash('sha256');
  const add = (dir) => (rel, stat) => {
    let known = contentHashes.get(rel);
    if (!known || known.size !== stat.size || known.mtimeMs !== stat.mtimeMs) {
      known = { size: stat.size, mtimeMs: stat.mtimeMs, hash: crypto.createHash('sha256').update(fs.readFileSync(path.join(dir, rel.slice(rel.indexOf('/') + 1)))).digest('hex') };
      contentHashes.set(rel, known);
    }
    hash.update(`${rel}\0${known.hash}\n`);
  };
  eachFile(config.publicDir, 'public/', add(config.publicDir));
  eachFile(config.sharedDir, 'shared/', add(config.sharedDir));
  fingerprint = { id: hash.digest('hex').slice(0, 12), at: now };
  return fingerprint.id;
}

/**
 * What an old copy of the page gets instead of the start-up script: a few lines that fetch the current page.
 * The address they go to carries the fingerprint (/?v=…), so no store can have seen it before; and finding that
 * fingerprint already in the address is the proof that this was tried, so it can never go round in circles.
 */
function renewPage(current) {
  return `// YHOD — this is not the start-up script. The page that asked for it is an old copy of YHOD, handed out by a
// store in this browser or on the way to it. These lines fetch the current page instead.
const current = ${JSON.stringify(current)};
const here = new URL(location.href);
if (here.searchParams.get('v') !== current) {
  here.searchParams.set('v', current);
  location.replace(here.href);
} else {
  // The current page was asked for under its own address, and an old copy came back again.
  const el = (tag, text, style) => { const e = document.createElement(tag); e.textContent = text; Object.assign(e.style, style); return e; };
  const again = el('button', 'Load YHOD again', { marginTop: '22px', padding: '13px 26px', borderRadius: '999px', border: '0', font: 'inherit', fontWeight: '700', color: '#04060d', background: '#19d3ff', cursor: 'pointer' });
  again.type = 'button';
  again.addEventListener('click', () => location.reload());
  const box = el('main', '', { position: 'fixed', inset: '0', zIndex: '99999', display: 'grid', placeContent: 'center', justifyItems: 'center', padding: '28px', textAlign: 'center', background: '#04060d', color: '#f2f5fb', font: '16px/1.6 system-ui, sans-serif' });
  box.setAttribute('role', 'alert');
  box.append(
    el('h1', 'YHOD has been updated', { margin: '0 0 12px', fontSize: '24px', lineHeight: '1.25' }),
    el('p', 'This browser is still being given an old copy of the page, so YHOD cannot start here yet.', { margin: '0', maxWidth: '460px' }),
    el('p', 'Please close this tab or preview and open YHOD again. If you see this message once more, wait a few minutes and try again.', { margin: '10px 0 0', maxWidth: '460px', opacity: '.75' }),
    again,
  );
  document.body.replaceChildren(box);
  document.body.classList.remove('is-locked');
}
`;
}

function resolveStatic(pathname) {
  let rel;
  let base;
  if (pathname.startsWith('/shared/')) { base = config.sharedDir; rel = pathname.slice('/shared/'.length); }
  else { base = config.publicDir; rel = pathname === '/' ? 'index.html' : pathname.slice(1); }
  const abs = path.resolve(base, rel);
  if (abs !== base && !abs.startsWith(base + path.sep)) return null; // path traversal
  return abs;
}

/**
 * Send a file of the site. Returns false when there is no such file; otherwise a short note for the log
 * ('' when there is nothing worth noting).
 */
export function serveStatic(req, res, pathname, extraHeaders) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return false; }
  // no hidden files (.env, .git …), no NUL bytes, no backslashes
  if (decoded.includes('\0') || decoded.includes('\\') || decoded.split('/').some((seg) => seg.startsWith('.'))) return false;
  const current = assetsId();
  const marked = FINGERPRINTED.exec(decoded);
  if (marked) decoded = marked[2];
  const abs = resolveStatic(decoded);
  if (!abs) return false;
  let stat = null;
  try { stat = fs.statSync(abs); } catch { /* not found */ }
  if (!stat || !stat.isFile()) return false;
  const ext = path.extname(abs).toLowerCase();
  const type = MIME[ext];
  if (!type) return false;
  let entry = staticCache.get(abs);
  if (!entry || entry.mtimeMs !== stat.mtimeMs || entry.size !== stat.size) {
    const raw = fs.readFileSync(abs);
    entry = { mtimeMs: stat.mtimeMs, size: stat.size, raw, etag: '"' + crypto.createHash('sha1').update(raw).digest('base64url').slice(0, 20) + '"', gz: null };
    if (COMPRESSIBLE.has(ext) && raw.length > 600) entry.gz = zlib.gzipSync(raw, { level: 7 });
    staticCache.set(abs, entry);
  }

  // The page: it names the fingerprinted addresses, so it must never come out of a cache.
  if (ext === '.html') {
    const html = Buffer.from(entry.raw.toString('utf8').replace(/\b(href|src)="\/(css|js)\//g, `$1="/a/${current}/$2/`), 'utf8');
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store', 'Content-Length': html.length, ...extraHeaders });
    res.end(req.method === 'HEAD' ? undefined : html);
    return `page sent · files ${current}`;
  }

  const font = ext === '.woff2';
  const fresh = !!marked && marked[1] === current;

  // The start-up script, asked for under any address but the current one: a store (in the browser, or in a gateway
  // on the way) has handed out an old copy of the page. The other scripts of that page may come out of the same
  // store, in any mix of old and new, so that page must not start at all: it is sent to the current page instead.
  // (A page that is already open never asks for its start-up script again, so nobody is interrupted by this.)
  if (!fresh && decoded === '/js/main.js') {
    const body = Buffer.from(renewPage(current), 'utf8');
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': body.length, ...extraHeaders, 'Cache-Control': 'no-store', 'Clear-Site-Data': '"cache"' });
    res.end(req.method === 'HEAD' ? undefined : body);
    return `the start-up script was asked for under ${marked ? `the outdated fingerprint ${marked[1]}` : 'its plain address'}: that page is an old copy, and was sent on to the current page (files ${current})`;
  }

  const headers = {
    'Content-Type': type,
    'Cache-Control': font ? 'public, max-age=2592000, immutable' : fresh ? 'public, max-age=31536000, immutable' : 'no-store',
    Vary: 'Accept-Encoding',
    ...extraHeaders,
  };
  let note = '';
  if (!font && !fresh && (ext === '.js' || ext === '.css')) note = marked ? `asked for under the outdated fingerprint ${marked[1]} (now ${current}): a page loaded before the last change` : 'asked for under its plain address: the page in that browser is an old copy';
  if (font || fresh) {
    headers.ETag = entry.etag;
    if (req.headers['if-none-match'] === entry.etag) { res.writeHead(304, headers); res.end(); return note; }
  }
  const useGz = entry.gz && /\bgzip\b/.test(String(req.headers['accept-encoding'] || ''));
  const body = useGz ? entry.gz : entry.raw;
  if (useGz) headers['Content-Encoding'] = 'gzip';
  headers['Content-Length'] = body.length;
  res.writeHead(200, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
  return note;
}
