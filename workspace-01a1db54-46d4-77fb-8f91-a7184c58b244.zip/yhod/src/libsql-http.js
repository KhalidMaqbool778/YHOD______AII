// YHOD — a small client for a libSQL / Turso database reached over HTTPS ("SQL over HTTP").
// It needs nothing but fetch, so it adds no package to install and works inside a serverless function.
//   Protocol: https://docs.turso.tech/sdk/http/reference  (POST <database>/v2/pipeline)
// Every call is one self-contained HTTPS request: the connection is opened, used and closed in it, so
// nothing is left open between requests — which is what a function that may be frozen at any moment needs.

export class RemoteDbError extends Error {
  constructor(message, { code = 'DB_ERROR', status = 0 } = {}) {
    super(message);
    this.name = 'RemoteDbError';
    this.code = code;
    this.status = status;
  }
}

/** libsql://name-org.turso.io → https://name-org.turso.io (http:// stays, for a local test server). */
export function httpBase(url) {
  const u = String(url || '').trim().replace(/\/+$/, '');
  if (/^(libsql|turso|wss):\/\//i.test(u)) return u.replace(/^[a-z]+:\/\//i, 'https://');
  if (/^ws:\/\//i.test(u)) return u.replace(/^ws:\/\//i, 'http://');
  if (/^https?:\/\//i.test(u)) return u;
  throw new RemoteDbError('The database address must start with libsql:// or https://', { code: 'DB_BAD_URL' });
}

// ── JavaScript value → what the protocol sends, and back ─────────────
function toValue(p) {
  if (p === null || p === undefined) return { type: 'null' };
  if (typeof p === 'string') return { type: 'text', value: p };
  if (typeof p === 'boolean') return { type: 'integer', value: p ? '1' : '0' };
  if (typeof p === 'bigint') return { type: 'integer', value: p.toString() };
  if (typeof p === 'number') {
    if (!Number.isFinite(p)) throw new TypeError('A number that is not finite cannot be stored.');
    return Number.isSafeInteger(p) ? { type: 'integer', value: String(p) } : { type: 'float', value: p };
  }
  if (p instanceof Uint8Array) return { type: 'blob', base64: Buffer.from(p.buffer, p.byteOffset, p.byteLength).toString('base64') };
  throw new TypeError(`A value of type ${typeof p} cannot be stored.`);
}
function fromValue(v) {
  switch (v?.type) {
    case 'null': return null;
    case 'text': return v.value;
    case 'float': return Number(v.value);
    case 'integer': { const n = Number(v.value); return Number.isSafeInteger(n) ? n : BigInt(v.value); }
    case 'blob': return Buffer.from(String(v.base64 || ''), 'base64');
    default: return v === null || v === undefined ? null : v;
  }
}
const statement = (sql, params = [], wantRows = true) => ({ sql, args: params.map(toValue), want_rows: wantRows });
function readResult(result) {
  const names = (result.cols || []).map((c) => c.name);
  const rows = (result.rows || []).map((cells) => {
    const row = {};
    cells.forEach((cell, i) => { row[names[i]] = fromValue(cell); });
    return row;
  });
  return { rows, changes: Number(result.affected_row_count || 0) };
}

export function createRemote({ url, authToken = '', timeoutMs = 20_000, fetchImpl = globalThis.fetch }) {
  const base = httpBase(url);
  const host = new URL(base).host;

  async function pipeline(requests, { retry = false } = {}) {
    const body = JSON.stringify({ baton: null, requests: [...requests, { type: 'close' }] });
    let res;
    for (let attempt = 0; ; attempt++) {
      try {
        res = await fetchImpl(`${base}/v2/pipeline`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}) },
          body,
          signal: AbortSignal.timeout(timeoutMs),
        });
      } catch (e) {
        // Only a request that reads may safely be sent a second time.
        if (retry && attempt === 0) continue;
        const slow = e?.name === 'TimeoutError' || e?.name === 'AbortError';
        throw new RemoteDbError(slow ? `The database at ${host} did not answer in time.` : `The database at ${host} could not be reached (${e?.cause?.code || e?.message || 'network error'}).`, { code: slow ? 'DB_TIMEOUT' : 'DB_UNREACHABLE' });
      }
      if (res.status >= 500 && retry && attempt === 0) continue;
      break;
    }
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch { data = null; }
    if (!res.ok) {
      const said = data?.message || data?.error?.message || data?.error || text.slice(0, 200) || `HTTP ${res.status}`;
      if (res.status === 401 || res.status === 403) throw new RemoteDbError(`The database at ${host} refused the access token (HTTP ${res.status}). Check TURSO_AUTH_TOKEN.`, { code: 'DB_UNAUTHORIZED', status: res.status });
      throw new RemoteDbError(`The database at ${host} answered with an error: ${String(said).slice(0, 300)}`, { code: 'DB_HTTP_ERROR', status: res.status });
    }
    const results = data?.results;
    if (!Array.isArray(results) || results.length < requests.length) throw new RemoteDbError(`The database at ${host} sent an answer YHOD cannot read.`, { code: 'DB_BAD_ANSWER', status: res.status });
    return results.slice(0, requests.length).map((r) => {
      if (r?.type !== 'ok') throw new RemoteDbError(String(r?.error?.message || 'The database refused the statement.'), { code: r?.error?.code || 'DB_STATEMENT_ERROR', status: res.status });
      return r.response;
    });
  }

  return {
    host,
    /** One statement. → { rows: [{ column: value }], changes } */
    async execute(sql, params = []) {
      const [r] = await pipeline([{ type: 'execute', stmt: statement(sql, params) }], { retry: /^\s*(select|with|pragma)\b/i.test(sql) });
      return readResult(r.result);
    },
    /**
     * Several statements as one unit: either all of them take effect or none does.
     * Each step runs only if the one before it succeeded; the last steps commit, or undo everything.
     */
    async batch(list) {
      if (!list.length) return;
      const steps = [{ stmt: statement('BEGIN IMMEDIATE', [], false) }];
      list.forEach(([sql, ...params], i) => steps.push({ condition: { type: 'ok', step: i }, stmt: statement(sql, params, false) }));
      const commit = steps.length;
      steps.push({ condition: { type: 'ok', step: commit - 1 }, stmt: statement('COMMIT', [], false) });
      steps.push({ condition: { type: 'not', cond: { type: 'ok', step: commit } }, stmt: statement('ROLLBACK', [], false) });
      const [r] = await pipeline([{ type: 'batch', batch: { steps } }]);
      const errors = r.result?.step_errors || [];
      const failed = errors.slice(0, commit + 1).find((e) => e);
      if (failed) throw new RemoteDbError(String(failed.message || 'The database refused the statements.'), { code: failed.code || 'DB_STATEMENT_ERROR' });
      if (!r.result?.step_results?.[commit]) throw new RemoteDbError('The database did not confirm the changes.', { code: 'DB_NOT_COMMITTED' });
    },
    /** Several statements written as one text (used for the table definitions). */
    async sequence(sql) {
      await pipeline([{ type: 'sequence', sql }]);
    },
  };
}
