// YHOD — request rate limiting and AI usage controls.
import crypto from 'node:crypto';
import { db } from './db.js';
import { config } from './config.js';
import { HttpError } from './httpx.js';

// ── burst limits (in memory, fixed windows) ─────────────────────────
// Counted inside this process. On a serverless platform every function instance counts for itself, so these
// are a brake on bursts, not an exact limit. Limits that must hold exactly are counted in the database (below).
const windows = new Map();

export function hit(key, max, windowMs) {
  const now = Date.now();
  let w = windows.get(key);
  if (!w || w.reset <= now) { w = { count: 0, reset: now + windowMs }; windows.set(key, w); }
  w.count += 1;
  return { ok: w.count <= max, retryAfterSec: Math.max(1, Math.ceil((w.reset - now) / 1000)) };
}

export function enforce(key, max, windowMs, message = 'Too many requests. Please slow down and try again shortly.') {
  const r = hit(key, max, windowMs);
  if (!r.ok) throw new HttpError(429, 'RATE_LIMITED', message, { retryAfterSec: r.retryAfterSec });
}

/** Forget a window. */
export function forget(key) {
  windows.delete(key);
}

setInterval(() => {
  const now = Date.now();
  for (const [k, w] of windows) if (w.reset <= now) windows.delete(k);
}, 60_000).unref();

// ── limits that hold everywhere (in the database, fixed windows) ────
// Sign-in attempts are counted here: the count survives a restart and is shared by all function instances.
// The key is stored as a hash, so an e-mail someone typed is never written down in this table.
const stored = (key) => crypto.createHash('sha256').update(String(key)).digest('hex').slice(0, 40);
let storedCalls = 0;

export async function enforceStored(key, max, windowMs, message = 'Too many requests. Please slow down and try again shortly.') {
  const now = Date.now();
  // One statement adds 1 and reports the new count, so two requests at the same moment are both counted.
  const row = await db.get(
    `INSERT INTO rate_windows (key, count, reset_at) VALUES (?, 1, ?)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN rate_windows.reset_at <= ? THEN 1 ELSE rate_windows.count + 1 END,
       reset_at = CASE WHEN rate_windows.reset_at <= ? THEN excluded.reset_at ELSE rate_windows.reset_at END
     RETURNING count, reset_at`,
    stored(key), now + windowMs, now, now,
  );
  if (++storedCalls % 40 === 0) db.run('DELETE FROM rate_windows WHERE reset_at <= ?', now).catch(() => { /* housekeeping only */ });
  if (row.count > max) throw new HttpError(429, 'RATE_LIMITED', message, { retryAfterSec: Math.max(1, Math.ceil((row.reset_at - now) / 1000)) });
}

/** Forget a stored count, e.g. the wrong-password count of a workspace once the right password was given. */
export async function forgetStored(key) {
  await db.run('DELETE FROM rate_windows WHERE key = ?', stored(key));
}

// ── daily AI usage (persisted) ──────────────────────────────────────
const LIMITS = {
  text: () => config.limits.textPerDay,
  image: () => config.limits.imagePerDay,
  voice: () => config.limits.voicePerDay,
  transcribe: () => config.limits.transcribePerDay,
};
const utcDay = () => new Date().toISOString().slice(0, 10);
const ADD = `INSERT INTO ai_usage (user_id, day, kind, count) VALUES (?, ?, ?, MAX(0, ?))
             ON CONFLICT(user_id, day, kind) DO UPDATE SET count = MAX(0, count + ?)`;
const addBoth = (userId, day, kind, delta) => db.batch([[ADD, userId, day, kind, delta, delta], [ADD, '*', day, 'all', delta, delta]]);

const inFlight = new Set();

/**
 * Reserve one AI request for a user. Resolves to { refund(), done() }.
 *  - enforces the per-minute burst limit, the per-user daily limit for this kind
 *    of request ('text' | 'image' | 'voice' | 'transcribe') and the site-wide daily limit;
 *  - `lock` (optional feature name) allows only one request of that feature per user at a time;
 *  - refund() gives the request back when Gemini never produced an answer.
 */
export async function reserveAi(userId, kind, lock = null) {
  enforce(`ai:${userId}`, config.limits.aiPerMinute, 60_000, 'You are sending AI requests very quickly. Please wait a moment and try again.');
  const lockKey = lock ? `${userId}:${lock}` : null;
  if (lockKey && inFlight.has(lockKey)) throw new HttpError(409, 'AI_BUSY', 'YHOD is still working on your previous request. Please wait for it to finish.');
  if (lockKey) inFlight.add(lockKey); // taken before the first pause, so a second request cannot slip past
  const day = utcDay();
  try {
    const limit = LIMITS[kind]();
    const rows = await db.all("SELECT user_id, count FROM ai_usage WHERE day = ? AND ((user_id = ? AND kind = ?) OR (user_id = '*' AND kind = 'all'))", day, userId, kind);
    const used = (who) => rows.find((r) => r.user_id === who)?.count || 0;
    if (used(userId) >= limit) {
      const what = { text: 'AI analysis', image: 'image analysis', voice: 'AI voice', transcribe: 'voice input' }[kind];
      throw new HttpError(429, 'AI_DAILY_LIMIT', `You have reached today's limit of ${limit} ${what} requests. The limit resets at midnight UTC.`, { limit, kind });
    }
    if (used('*') >= config.limits.globalPerDay) {
      throw new HttpError(429, 'AI_GLOBAL_LIMIT', "YHOD has reached today's overall AI usage limit. Please try again tomorrow.");
    }
    await addBoth(userId, day, kind, 1);
  } catch (e) {
    if (lockKey) inFlight.delete(lockKey);
    throw e;
  }
  let finished = false;
  const release = () => { finished = true; if (lockKey) inFlight.delete(lockKey); };
  return {
    async refund() {
      const give = !finished;
      release();
      if (give) { try { await addBoth(userId, day, kind, -1); } catch { /* the allowance is simply not given back */ } }
    },
    done: release,
  };
}

export async function usageToday(userId) {
  const rows = await db.all('SELECT kind, count FROM ai_usage WHERE user_id = ? AND day = ?', userId, utcDay());
  const out = {};
  for (const kind of Object.keys(LIMITS)) out[kind] = { used: rows.find((r) => r.kind === kind)?.count || 0, limit: LIMITS[kind]() };
  return out;
}

/** Forget counters that no longer matter. Called now and then; never needed for correctness. */
export async function tidyUsage() {
  await db.run('DELETE FROM ai_usage WHERE day < ?', new Date(Date.now() - 8 * 864e5).toISOString().slice(0, 10));
  await db.run('DELETE FROM rate_windows WHERE reset_at <= ?', Date.now());
}
