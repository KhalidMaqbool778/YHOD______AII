// YHOD — accounts, sessions and personal settings.
import { db, nowIso } from './db.js';
import { config } from './config.js';
import { HttpError, parseCookies } from './httpx.js';
import { hashPassword, verifyPassword, burnPasswordTime, newId, newToken, sha256, decJson } from './security.js';
import { enforceStored, forgetStored, usageToday } from './ratelimit.js';
import { validTz, userSettings, cleanTargets, DEFAULT_TARGETS } from './health.js';
import { cleanName, cleanEmail, nameProblem, emailProblem, passwordProblem } from '../shared/account.js';

const COOKIE = 'yhod_session';
const COOKIE_SECURE = '__Host-yhod_session';

function sessionCookie(token, { secure, embedded }, maxAgeSec) {
  const name = secure ? COOKIE_SECURE : COOKIE;
  const parts = [`${name}=${token}`, 'Path=/', 'HttpOnly', `Max-Age=${maxAgeSec}`];
  if (secure) {
    parts.push('Secure');
    // Inside an embedded preview (a cross-site iframe) the cookie must be SameSite=None;
    // "Partitioned" keeps it isolated to that embedding site. As a normal top-level
    // website the stricter SameSite=Lax is used.
    if (embedded) parts.push('SameSite=None', 'Partitioned');
    else parts.push('SameSite=Lax');
  } else {
    parts.push('SameSite=Lax');
  }
  return parts.join('; ');
}

function clearCookies(ctx) {
  ctx.setCookie(`${COOKIE}=; Path=/; HttpOnly; Max-Age=0; SameSite=Lax`);
  ctx.setCookie(`${COOKIE_SECURE}=; Path=/; HttpOnly; Secure; Max-Age=0; SameSite=${ctx.embedded ? 'None; Partitioned' : 'Lax'}`);
}

/**
 * The ways a request can carry a session, in the order they are tried:
 *   cookie  the httpOnly session cookie (the normal way)
 *   header  "X-YHOD-Tab": the app's own header, for pages where the cookie does not get through
 *           (a browser that blocks cookies inside another site's frame; a gateway in front of the server
 *           that does not pass Cookie and Authorization on)
 *   bearer  "Authorization: Bearer ...", for scripts and other programs
 * Another website cannot make a visitor's browser send "header" or "bearer"; only this site's own code can.
 */
const TOKEN = /^[A-Za-z0-9_-]{20,200}$/;
function carriers(req) {
  const cookies = parseCookies(req);
  const tab = String(req.headers['x-yhod-tab'] || '');
  const bearer = /^Bearer\s+([A-Za-z0-9_-]{20,200})$/.exec(String(req.headers.authorization || ''));
  return [
    ['cookie', cookies[COOKIE_SECURE]],
    ['cookie', cookies[COOKIE]],
    ['header', TOKEN.test(tab) ? tab : ''],
    ['bearer', bearer?.[1]],
  ].filter(([, token]) => token);
}

/** For the access log: which carriers arrived with a request. Names only, never the values. */
export function sessionCarriers(req) {
  const seen = [...new Set(carriers(req).map(([via]) => via))];
  return seen.length ? seen.join('+') : 'none';
}

/** Find the signed-in user for a request. A carrier that is unknown or expired is skipped, not fatal. */
export async function resolveSession(req) {
  for (const [via, token] of carriers(req)) {
    const id = sha256(token);
    const row = await db.get('SELECT s.id AS sid, s.expires_at, u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?', id);
    if (!row) continue;
    if (row.expires_at <= nowIso()) { await db.run('DELETE FROM sessions WHERE id = ?', id); continue; }
    const { sid, expires_at, ...user } = row;
    return { user, sessionId: sid, via };
  }
  return null;
}

function publicUser(user) {
  const s = userSettings(user);
  return { id: user.id, name: user.name, email: user.email, tz: user.tz, targets: s.targets, tempUnit: s.tempUnit, createdAt: user.created_at };
}

async function startSession(ctx, user) {
  const token = newToken();
  const maxAge = config.sessionDays * 86400;
  await db.run('INSERT INTO sessions (id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)', sha256(token), user.id, nowIso(), new Date(Date.now() + maxAge * 1000).toISOString());
  ctx.setCookie(sessionCookie(token, ctx, maxAge));
  return token;
}

/**
 * A workspace counts as opened once a signed-in request has arrived for it. Until then it holds nothing:
 * it was set up, but nobody ever got in (for example because the sign-in never reached the server).
 */
export async function markOpened(user) {
  if (user.opened_at) return;
  user.opened_at = nowIso();
  await db.run('UPDATE users SET opened_at = ? WHERE id = ? AND opened_at IS NULL', user.opened_at, user.id);
}

const TOO_MANY_FROM_HERE = 'Too many sign-in attempts from this network. Please wait a few minutes.';
const TOO_MANY_FOR_WORKSPACE = 'Too many wrong passwords for this workspace. Please wait 15 minutes and try again.';
const WRONG_PASSWORD = 'A YHOD workspace already exists for this e-mail, but this is not its password.';

/** Read name, e-mail and password from a request; the same rules as in the browser (shared/account.js). */
function credentials(ctx, { needName }) {
  const name = cleanName(ctx.body.name);
  const email = cleanEmail(ctx.body.email);
  const password = typeof ctx.body.password === 'string' ? ctx.body.password : '';
  const wrongEmail = emailProblem(email);
  if (wrongEmail) throw new HttpError(422, 'INVALID_EMAIL', wrongEmail);
  const wrongPassword = passwordProblem(password);
  if (wrongPassword) throw new HttpError(422, 'INVALID_PASSWORD', wrongPassword);
  if (needName) { const wrongName = nameProblem(name); if (wrongName) throw new HttpError(422, 'INVALID_NAME', wrongName); }
  return { name, email, password, tz: validTz(ctx.body.tz) ? ctx.body.tz : null };
}

/**
 * Create a private workspace. `shell` is an existing workspace for the same e-mail that was never opened;
 * it holds nothing and is replaced, so that an e-mail is never blocked by a sign-up that led nowhere.
 */
async function createWorkspace(ctx, { name, email, password, tz }, shell = null) {
  const user = { id: newId(), email, name, pass_hash: await hashPassword(password), tz: tz || 'UTC', settings: JSON.stringify({ targets: DEFAULT_TARGETS }), created_at: nowIso(), opened_at: null };
  try {
    // One unit: the shell goes (only if it is still unopened) and the new workspace comes, or nothing changes.
    await db.batch([
      shell && ['DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE id = ? AND opened_at IS NULL)', shell.id],
      shell && ['DELETE FROM users WHERE id = ? AND opened_at IS NULL', shell.id],
      ['INSERT INTO users (id, email, name, pass_hash, tz, settings, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', user.id, user.email, user.name, user.pass_hash, user.tz, user.settings, user.created_at],
    ]);
  } catch (e) {
    if (/UNIQUE/i.test(String(e.message))) throw new HttpError(409, 'EMAIL_IN_USE', 'A YHOD workspace for this e-mail already exists. Enter its password to open it.');
    throw e;
  }
  return { user: publicUser(user), token: await startSession(ctx, user), isNew: true };
}

async function openWorkspace(ctx, user, tz) {
  await forgetStored(`login:${user.email}`);
  if (tz && tz !== user.tz) { await db.run('UPDATE users SET tz = ? WHERE id = ?', tz, user.id); user.tz = tz; }
  // A workspace that was set up but never opened (the sign-in never got through) is as good as new to its owner.
  return { user: publicUser(user), token: await startSession(ctx, user), isNew: !user.opened_at };
}

export function registerAuthRoutes(router) {
  /**
   * The entrance the YHOD site uses: name, e-mail and the person's own password.
   *   - the e-mail has a workspace and the password is right      → that workspace opens (the saved name is kept)
   *   - the e-mail has a workspace and the password is wrong      → 401 WRONG_PASSWORD
   *   - no workspace was ever opened with this e-mail             → 404 NO_WORKSPACE; the site asks the person, and
   *                                                                 sends the same details again with create: true
   */
  router.add('POST', '/api/auth/enter', {}, async (ctx) => {
    await enforceStored(`auth:${ctx.ip}`, config.limits.authPer10Min, 600_000, TOO_MANY_FROM_HERE);
    const create = ctx.body.create === true;
    const c = credentials(ctx, { needName: create });
    const user = await db.get('SELECT * FROM users WHERE email = ?', c.email);
    if (user) {
      // Guessing is limited per workspace, whatever network it comes from. A right password clears the count.
      if (user.opened_at) await enforceStored(`login:${c.email}`, 8, 900_000, TOO_MANY_FOR_WORKSPACE);
      if (await verifyPassword(c.password, user.pass_hash)) return await openWorkspace(ctx, user, c.tz);
      if (user.opened_at) throw new HttpError(401, 'WRONG_PASSWORD', WRONG_PASSWORD);
    } else {
      await burnPasswordTime(c.password);
    }
    if (!create) throw new HttpError(404, 'NO_WORKSPACE', 'No YHOD workspace has been opened with this e-mail yet.');
    return await createWorkspace(ctx, c, user || null);
  });

  // The two classic calls stay for scripts and other programs. They follow the same rules.
  router.add('POST', '/api/auth/signup', {}, async (ctx) => {
    await enforceStored(`auth:${ctx.ip}`, config.limits.authPer10Min, 600_000, TOO_MANY_FROM_HERE);
    const c = credentials(ctx, { needName: true });
    const existing = await db.get('SELECT * FROM users WHERE email = ?', c.email);
    if (existing && existing.opened_at) throw new HttpError(409, 'EMAIL_IN_USE', 'A YHOD workspace for this e-mail already exists. Enter its password to open it.');
    const { user, token } = await createWorkspace(ctx, c, existing || null);
    return { user, token };
  });

  router.add('POST', '/api/auth/login', {}, async (ctx) => {
    await enforceStored(`auth:${ctx.ip}`, config.limits.authPer10Min, 600_000, TOO_MANY_FROM_HERE);
    const email = cleanEmail(ctx.body.email);
    const password = typeof ctx.body.password === 'string' ? ctx.body.password : '';
    if (!email || !password) throw new HttpError(422, 'MISSING_CREDENTIALS', 'Please enter your e-mail and password.');
    await enforceStored(`login:${email}`, 8, 900_000, TOO_MANY_FOR_WORKSPACE);
    const user = await db.get('SELECT * FROM users WHERE email = ?', email);
    let ok = false;
    if (user) ok = await verifyPassword(password, user.pass_hash);
    else await burnPasswordTime(password);
    if (!ok) throw new HttpError(401, 'BAD_CREDENTIALS', 'That e-mail or password is not correct.');
    const { user: u, token } = await openWorkspace(ctx, user, validTz(ctx.body.tz) ? ctx.body.tz : null);
    return { user: u, token };
  });

  router.add('POST', '/api/auth/logout', {}, async (ctx) => {
    if (ctx.sessionId) await db.run('DELETE FROM sessions WHERE id = ?', ctx.sessionId);
    clearCookies(ctx);
    return { ok: true };
  });

  router.add('GET', '/api/auth/me', {}, async (ctx) => {
    if (!ctx.user) return { user: null };
    return { user: publicUser(ctx.user), via: ctx.sessionVia, usage: await usageToday(ctx.user.id) };
  });

  router.add('PATCH', '/api/account', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const s = userSettings(user);
    if (ctx.body.name !== undefined) {
      const name = cleanName(ctx.body.name);
      if (name.length < 1 || name.length > 60) throw new HttpError(422, 'INVALID_NAME', 'Please enter your name (up to 60 characters).');
      user.name = name;
    }
    if (ctx.body.targets !== undefined) s.targets = { ...s.targets, ...cleanTargets(ctx.body.targets) };
    if (ctx.body.tempUnit !== undefined) s.tempUnit = ctx.body.tempUnit === 'F' ? 'F' : 'C';
    if (ctx.body.tz !== undefined && validTz(ctx.body.tz)) user.tz = ctx.body.tz;
    user.settings = JSON.stringify(s);
    await db.run('UPDATE users SET name = ?, settings = ?, tz = ? WHERE id = ?', user.name, user.settings, user.tz, user.id);
    return { user: publicUser(user) };
  });

  // Everything YHOD holds about the signed-in person, decrypted, as one JSON download.
  router.add('GET', '/api/account/export', { auth: true }, async (ctx) => {
    const u = ctx.user;
    const dec = (v) => { try { return decJson(v, u.id); } catch { return null; } };
    const conversations = [];
    for (const c of await db.all('SELECT * FROM conversations WHERE user_id = ? ORDER BY created_at', u.id)) {
      const messages = await db.all('SELECT role, content_enc, created_at FROM messages WHERE conversation_id = ? AND user_id = ? ORDER BY seq', c.id, u.id);
      conversations.push({ id: c.id, kind: c.kind, status: c.status, createdAt: c.created_at, state: dec(c.state_enc), messages: messages.map((m) => ({ role: m.role, at: m.created_at, text: dec(m.content_enc) })) });
    }
    const data = {
      exportedAt: nowIso(),
      app: 'YHOD — Your Health, Our Duty',
      account: publicUser(u),
      visits: await db.all('SELECT date, first_at AS firstAt, last_at AS lastAt, count FROM visits WHERE user_id = ? ORDER BY date', u.id),
      dailyCheckins: (await db.all('SELECT * FROM checkins WHERE user_id = ? ORDER BY date', u.id)).map((r) => ({
        date: r.date, answers: dec(r.answers_enc), dashboard: dec(r.metrics_enc), aiFeedback: dec(r.feedback_enc), aiModel: r.feedback_model, createdAt: r.created_at, updatedAt: r.updated_at,
      })),
      assessments: (await db.all('SELECT * FROM assessments WHERE user_id = ? ORDER BY created_at', u.id)).map((r) => ({
        id: r.id, kind: r.kind, createdAt: r.created_at, level: r.level, aiModel: r.model, input: dec(r.input_enc), result: dec(r.result_enc), treatmentInformation: dec(r.treatment_enc), savedImageId: r.image_id,
      })),
      conversations,
      savedImages: (await db.all('SELECT id, mime, size, created_at AS createdAt FROM images WHERE user_id = ? ORDER BY created_at', u.id)).map((i) => ({ ...i, download: `/api/images/${i.id}` })),
    };
    const body = Buffer.from(JSON.stringify(data, null, 2));
    ctx.res.writeHead(200, {
      ...ctx.headers,
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Disposition': `attachment; filename="yhod-my-health-records-${new Date().toISOString().slice(0, 10)}.json"`,
      'Content-Length': body.length,
      'Cache-Control': 'no-store',
    });
    ctx.res.end(body);
  });

  // Delete health records (keep the account) — or the whole account.
  router.add('POST', '/api/account/delete', { auth: true }, async (ctx) => {
    const u = ctx.user;
    const scope = ctx.body.scope === 'account' ? 'account' : 'records';
    if (!(await verifyPassword(String(ctx.body.password ?? ''), u.pass_hash))) throw new HttpError(403, 'BAD_PASSWORD', 'That password is not correct, so nothing was deleted.');
    // One unit: everything listed here is deleted, or nothing is.
    const gone = ['messages', 'conversations', 'assessments', 'images', 'checkins', 'ai_cache', 'voice_cache', 'ai_usage'].map((t) => [`DELETE FROM ${t} WHERE user_id = ?`, u.id]);
    if (scope === 'account') gone.push(['DELETE FROM visits WHERE user_id = ?', u.id], ['DELETE FROM sessions WHERE user_id = ?', u.id], ['DELETE FROM users WHERE id = ?', u.id]);
    await db.batch(gone);
    if (scope === 'account') clearCookies(ctx);
    return { ok: true, scope };
  });
}
