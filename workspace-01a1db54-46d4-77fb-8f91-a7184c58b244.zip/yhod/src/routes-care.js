// YHOD — START YHOD conversation, symptom assessment, image + skin analysis,
// treatment information, voice assistant, speech-to-text.
import { db, nowIso } from './db.js';
import { config, MEDICINE_DISCLAIMER } from './config.js';
import { HttpError } from './httpx.js';
import { encJson, decJson, encryptBytes, decryptBytes, newId } from './security.js';
import { generate, GeminiError } from './gemini.js';
import { ai, cleanText, firstName } from './aihelp.js';
import * as P from './prompts.js';
import { todayFor, userTargets, loadCheckin, checkinDates, streak, loadCheckinsBetween } from './health.js';
import { detectRedFlags, interpretDangerAnswer, emergencyNumbers } from '../shared/safety.js';

const HISTORY_QUESTIONS = new Set(['name', 'age', 'visited_doctor', 'conditions', 'medicines']);
const MAX_TURNS = 26;

export const EMERGENCY_STEPS = [
  'Call your local emergency number now, or go to the nearest emergency department.',
  'Do not drive yourself. If someone is with you, ask them to stay and help.',
  'If a doctor has already given you an emergency plan for this situation, follow it.',
  'Do not wait to finish these questions.',
];

// ── conversation storage ────────────────────────────────────────────
const OPENING = {
  text: `I'm here with you. ${P.PROTOCOL[0].question}`,
  source: 'protocol',
  quick: ['Yes', 'No'],
};

function newState() {
  return { collected: {}, asked: { danger_check: true }, lastAsked: 'danger_check', dangerAsks: 1, followups: 0, turns: 0, emergency: { active: false, hard: false, reasons: [] }, ready: false, imageNotes: [], assessmentId: null };
}

async function loadConversation(user, id, kind = 'start_yhod') {
  const row = await db.get('SELECT * FROM conversations WHERE id = ? AND user_id = ? AND kind = ?', String(id), user.id, kind);
  if (!row) throw new HttpError(404, 'NO_CONVERSATION', 'That conversation was not found.');
  return { id: row.id, status: row.status, createdAt: row.created_at, state: decJson(row.state_enc, user.id) };
}
async function saveState(user, conv) {
  await db.run('UPDATE conversations SET state_enc = ?, status = ?, updated_at = ? WHERE id = ? AND user_id = ?', encJson(conv.state, user.id), conv.status, nowIso(), conv.id, user.id);
}
async function loadMessages(user, convId, limit = 200) {
  return (await db.all('SELECT id, role, content_enc, created_at FROM messages WHERE conversation_id = ? AND user_id = ? ORDER BY seq DESC LIMIT ?', convId, user.id, limit)).reverse().map((m) => {
    let c = {};
    try { c = decJson(m.content_enc, user.id) || {}; } catch { c = { text: '' }; }
    return { id: m.id, role: m.role, at: m.created_at, ...c };
  });
}
async function addMessage(user, convId, role, content) {
  const id = newId();
  const at = nowIso();
  // One statement works out the next position and stores the message, so two messages can never get the same one.
  await db.run('INSERT INTO messages (id, conversation_id, user_id, role, content_enc, seq, created_at) SELECT ?, ?, ?, ?, ?, COALESCE(MAX(seq), 0) + 1, ? FROM messages WHERE conversation_id = ?',
    id, convId, user.id, role, encJson(content, user.id), at, convId);
  return { id, role, at, ...content };
}

function remainingItems(state) {
  const out = P.PROTOCOL_KEYS.filter((k) => !state.collected[k] && !state.asked[k]);
  if (!state.collected.danger_check && state.dangerAsks < 2) out.unshift('danger_check');
  return out;
}

function publicState(state, user) {
  const known = P.PROTOCOL_KEYS.filter((k) => state.collected[k]).map((k) => ({ key: k, label: P.PROTOCOL_LABELS_USER[k] || P.PROTOCOL_LABELS[k], value: state.collected[k] }));
  const done = P.PROTOCOL_KEYS.filter((k) => state.collected[k] || (state.asked[k] && k !== state.lastAsked)).length;
  return {
    known,
    progress: { done: Math.min(done, P.PROTOCOL_KEYS.length), total: P.PROTOCOL_KEYS.length },
    ready: !!state.ready,
    lastAsked: state.lastAsked || null,
    assessmentId: state.assessmentId || null,
    emergency: state.emergency.active ? emergencyPayload(state, user) : null,
  };
}

function emergencyPayload(state, user) {
  return { active: true, reasons: state.emergency.reasons.slice(0, 5), steps: EMERGENCY_STEPS, numbers: emergencyNumbers(user.tz) };
}

function addReasons(state, reasons, hard) {
  state.emergency.active = true;
  if (hard) state.emergency.hard = true;
  for (const r of reasons) {
    const s = String(r || '').trim();
    if (s && !state.emergency.reasons.some((x) => x.toLowerCase() === s.toLowerCase())) state.emergency.reasons.push(s);
  }
}

const say = (m) => ({ role: m.role, content: m.text });

// ── image validation (secure file processing) ───────────────────────
function imageInfo(buf) {
  if (buf.length >= 33 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) && buf.toString('latin1', 12, 16) === 'IHDR') {
    return { mime: 'image/png', width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  }
  if (buf.length >= 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) { i++; continue; }
      const marker = buf[i + 1];
      if (marker === 0xff) { i++; continue; }
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
      if (marker === 0xd9 || marker === 0xda) break;
      const len = buf.readUInt16BE(i + 2);
      if (len < 2) return null;
      if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
        return { mime: 'image/jpeg', height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
      }
      i += 2 + len;
    }
    return null;
  }
  if (buf.length >= 30 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') {
    const fmt = buf.toString('latin1', 12, 16);
    if (fmt === 'VP8 ' && buf[23] === 0x9d && buf[24] === 0x01 && buf[25] === 0x2a) return { mime: 'image/webp', width: buf.readUInt16LE(26) & 0x3fff, height: buf.readUInt16LE(28) & 0x3fff };
    if (fmt === 'VP8L' && buf[20] === 0x2f) { const b = buf.readUInt32LE(21); return { mime: 'image/webp', width: (b & 0x3fff) + 1, height: ((b >>> 14) & 0x3fff) + 1 }; }
    if (fmt === 'VP8X') return { mime: 'image/webp', width: 1 + buf.readUIntLE(24, 3), height: 1 + buf.readUIntLE(27, 3) };
    return null;
  }
  return null;
}

function decodeImage(input) {
  if (typeof input !== 'string' || !input) throw new HttpError(422, 'NO_IMAGE', 'Please take or choose a photo first.');
  let b64 = input;
  const m = /^data:[a-z0-9.+/-]+;base64,/i.exec(b64.slice(0, 64));
  if (m) b64 = b64.slice(m[0].length);
  if (b64.length > Math.ceil(config.limits.maxImageBytes / 3) * 4 + 8) throw new HttpError(413, 'IMAGE_TOO_LARGE', `That image is too large. The limit is ${Math.round(config.limits.maxImageBytes / 1048576)} MB.`);
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) throw new HttpError(422, 'BAD_IMAGE', 'That image could not be read. Please try another photo.');
  const buf = Buffer.from(b64, 'base64');
  if (buf.length < 600) throw new HttpError(422, 'BAD_IMAGE', 'That image is empty or damaged. Please try another photo.');
  const info = imageInfo(buf);
  if (!info) throw new HttpError(415, 'UNSUPPORTED_IMAGE', 'Only JPG, JPEG, PNG and WEBP images are supported.');
  if (info.width < 48 || info.height < 48) throw new HttpError(422, 'IMAGE_TOO_SMALL', 'That image is too small for YHOD to look at. Please use a larger photo.');
  if (info.width > 12000 || info.height > 12000 || info.width * info.height > 60_000_000) throw new HttpError(413, 'IMAGE_TOO_LARGE', 'That image has too many pixels. Please use a smaller photo.');
  return { buf, base64: buf.toString('base64'), ...info };
}

function decodeWav(input) {
  if (typeof input !== 'string' || !input) throw new HttpError(422, 'NO_AUDIO', 'No recording was received.');
  if (input.length > Math.ceil(config.limits.maxAudioBytes / 3) * 4 + 8) throw new HttpError(413, 'AUDIO_TOO_LARGE', 'That recording is too long. Please keep it under about a minute.');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(input)) throw new HttpError(422, 'BAD_AUDIO', 'That recording could not be read.');
  const buf = Buffer.from(input, 'base64');
  if (buf.length < 44 || buf.toString('latin1', 0, 4) !== 'RIFF' || buf.toString('latin1', 8, 12) !== 'WAVE') throw new HttpError(415, 'BAD_AUDIO', 'That recording is not in a supported format.');
  const rate = buf.readUInt32LE(24);
  const bytesPerSec = buf.readUInt32LE(28) || rate * 2;
  const seconds = (buf.length - 44) / bytesPerSec;
  if (seconds < 0.35) throw new HttpError(422, 'AUDIO_TOO_SHORT', 'That recording was too short. Hold the microphone button, speak, then stop.');
  return { base64: buf.toString('base64'), seconds };
}

// ── assessment storage ──────────────────────────────────────────────
async function saveAssessment(user, { kind, conversationId = null, imageId = null, input, result, model }) {
  const id = newId();
  const at = nowIso();
  await db.run('INSERT INTO assessments (id, user_id, kind, conversation_id, image_id, input_enc, result_enc, model, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    id, user.id, kind, conversationId, imageId, encJson(input, user.id), encJson(result, user.id), model, at);
  return { id, kind, createdAt: at, model, imageId, input, result, treatment: null, disclaimer: MEDICINE_DISCLAIMER };
}

export async function loadAssessment(user, id) {
  const r = await db.get('SELECT * FROM assessments WHERE id = ? AND user_id = ?', String(id), user.id);
  if (!r) throw new HttpError(404, 'NO_ASSESSMENT', 'That assessment was not found.');
  return {
    id: r.id, kind: r.kind, createdAt: r.created_at, model: r.model, imageId: r.image_id, conversationId: r.conversation_id,
    input: decJson(r.input_enc, user.id), result: decJson(r.result_enc, user.id), treatment: decJson(r.treatment_enc, user.id), disclaimer: MEDICINE_DISCLAIMER,
  };
}

function conversationContext(state) {
  const c = state.collected;
  const rows = [['Age', c.age], ['Previously diagnosed conditions', c.conditions], ['Prescribed medicines', c.medicines], ['Body temperature', c.temperature], ['Symptoms described', c.symptoms], ['Started', c.onset], ['Improving or worsening', c.trend], ['Additional information', c.additional]];
  return rows.filter(([, v]) => v).map(([k, v]) => `- ${k}: ${v}`).join('\n');
}

async function assistantContext(user) {
  const today = todayFor(user);
  const t = userTargets(user);
  const dates = await checkinDates(user);
  const v = (x, u = '') => (x === null || x === undefined ? 'not recorded' : `${x}${u}`);
  const out = [`PERSON'S FIRST NAME: ${firstName(user)}`, `TODAY (their local date): ${today}`, `PERSONAL DAILY TARGETS: ${P.targetsText(t)}.`, `CHECK-INS: ${dates.length} completed in total; current streak ${streak(dates, today)} day(s); today's check-in completed: ${dates.includes(today) ? 'yes' : 'no'}.`];
  const recent = dates.slice(-7);
  if (recent.length) {
    out.push('RECENT CHECK-INS (most recent last):');
    const saved = await loadCheckinsBetween(user, recent[0], recent[recent.length - 1]);
    for (const d of recent) {
      const m = saved.get(d).metrics;
      out.push(`- ${d}: water ${v(m.water)} glasses; sleep ${v(m.sleepHours, ' h')}; walking+exercise ${v(m.activeMinutes, ' min')}; steps ${v(m.steps)}; fruit+veg ${v(m.fruitVeg)} servings; mood ${v(m.mood)}; stress ${v(m.stress)}/5; energy ${v(m.energy)}/5; temperature ${m.temperature ? m.temperature.value + ' °' + m.temperature.unit : 'not recorded'}; symptoms: ${m.symptoms.length ? m.symptoms.join(', ') : 'none recorded'}`);
    }
    const last = saved.get(recent[recent.length - 1]);
    if (last.feedback) out.push(`YHOD'S FEEDBACK FOR ${last.date}: ${last.feedback.personal_message} (urgency: ${last.feedback.urgency})`);
  } else {
    out.push('RECENT CHECK-INS: none yet.');
  }
  return out.join('\n');
}

export function registerCareRoutes(router) {
  // ════ (6) START YHOD conversation ═════════════════════════════════
  router.add('POST', '/api/start-yhod/start', { auth: true }, async (ctx) => {
    const user = ctx.user;
    // keep at most 30 past conversations per person
    const old = await db.all("SELECT id FROM conversations WHERE user_id = ? AND kind = 'start_yhod' ORDER BY created_at DESC LIMIT -1 OFFSET 30", user.id);
    // (the messages are deleted by name, not left to the database's cascade rule, which not every database applies)
    if (old.length) await db.batch(old.flatMap((o) => [['DELETE FROM messages WHERE conversation_id = ? AND user_id = ?', o.id, user.id], ['DELETE FROM conversations WHERE id = ? AND user_id = ?', o.id, user.id]]));
    const conv = { id: newId(), status: 'open', state: newState() };
    const now = nowIso();
    await db.run('INSERT INTO conversations (id, user_id, kind, state_enc, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)', conv.id, user.id, 'start_yhod', encJson(conv.state, user.id), 'open', now, now);
    const first = await addMessage(user, conv.id, 'assistant', OPENING);
    return { conversation: { id: conv.id, status: 'open', messages: [first], state: publicState(conv.state, user) } };
  });

  router.add('GET', '/api/start-yhod/current', { auth: true }, async (ctx) => {
    const row = await db.get("SELECT id FROM conversations WHERE user_id = ? AND kind = 'start_yhod' AND status = 'open' AND updated_at > ? ORDER BY updated_at DESC LIMIT 1", ctx.user.id, new Date(Date.now() - 12 * 3600_000).toISOString());
    if (!row) return { conversation: null };
    const conv = await loadConversation(ctx.user, row.id);
    return { conversation: { id: conv.id, status: conv.status, messages: await loadMessages(ctx.user, conv.id), state: publicState(conv.state, ctx.user) } };
  });

  router.add('POST', '/api/start-yhod/:id/close', { auth: true }, async (ctx) => {
    const conv = await loadConversation(ctx.user, ctx.params.id);
    conv.status = 'closed';
    await saveState(ctx.user, conv);
    return { ok: true };
  });

  router.add('POST', '/api/start-yhod/:id/message', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const text = cleanText(ctx.body.text, 1500);
    if (!text) throw new HttpError(422, 'EMPTY_MESSAGE', 'Please type your answer first.');
    const conv = await loadConversation(user, ctx.params.id);
    if (conv.status !== 'open') throw new HttpError(409, 'CONVERSATION_CLOSED', 'This conversation has ended. Type START YHOD to begin a new one.');
    const state = conv.state;
    const history = await loadMessages(user, conv.id);
    const last = state.lastAsked;

    // 1 ─ fixed safety rules run first, so emergency advice never depends on the AI being available
    const det = detectRedFlags(text, { assumeTemperature: last === 'temperature', temperatureOnly: HISTORY_QUESTIONS.has(last) });
    const flags = [...det.flags];
    const dangerOpen = last === 'danger_check' && !state.collected.danger_check;
    const dangerDet = dangerOpen ? interpretDangerAnswer(text) : null;
    if (dangerDet === 'yes' && !flags.length) flags.push({ code: 'danger_yes', label: 'The person answered yes to the dangerous-symptoms question' });
    const newEmergency = flags.length > 0 && !state.emergency.active;
    if (flags.length) {
      addReasons(state, det.flags.map((f) => f.label), det.flags.length > 0);
      if (!det.flags.length) addReasons(state, ['You answered yes to the dangerous-symptoms question'], false);
      await saveState(user, conv);
    }

    // 2 ─ Gemini reads the free-text answer, extracts what it says and words the next question
    const transcript = [...history.map(say), { role: 'user', content: text }];
    const ask = (correction) => generate({
      purpose: 'conversation', models: config.gemini.fastModels, system: P.CONVO_SYSTEM,
      input: P.convoInput({ state, messages: transcript, remaining: remainingItems(state), flags, firstName: firstName(user), correction }),
      schema: P.CONVO_SCHEMA, validate: P.checkConvo, thinking: 'low', maxOutputTokens: 1500, hedgeMs: 4500, totalMs: 35000,
    });
    let out;
    try {
      out = await ai(ctx, 'text', 'conversation', () => ask(null));
    } catch (e) {
      if (state.emergency.active && (e instanceof GeminiError)) e.extra = { emergency: emergencyPayload(state, user), state: publicState(state, user) };
      throw e;
    }
    state.turns += 1;

    const merge = (g) => {
      for (const k of P.PROTOCOL_KEYS) if (k !== 'danger_check' && g.extracted[k]) state.collected[k] = g.extracted[k];
      if (!state.collected.danger_check && (dangerOpen || g.extracted.danger_check)) {
        // "yes" from either the fixed rules or Gemini wins; otherwise either one may say "no"
        const answer = dangerDet === 'yes' || g.extracted.danger_check === 'yes' ? 'yes' : g.extracted.danger_check === 'no' || dangerDet === 'no' ? 'no' : '';
        if (answer) state.collected.danger_check = answer;
        else if (state.dangerAsks >= 2) state.collected.danger_check = 'unclear';
        if (answer === 'yes' && !state.emergency.active) addReasons(state, ['You answered yes to the dangerous-symptoms question'], false);
      }
      // Gemini's own reason is recorded only when the fixed rules did not already give one for this message
      if (g.emergency) addReasons(state, flags.length ? [] : [g.emergency_reason || 'Possible emergency symptoms were described'], false);
    };
    const valid = (g, remaining) => (remaining.length ? remaining.includes(g.asked) && !g.ready_for_assessment : true);

    let g = out.data;
    let model = out.model;
    let source = 'gemini';
    merge(g);
    let remaining = remainingItems(state);
    if (!valid(g, remaining)) {
      // Gemini skipped a required question: ask it once to correct itself
      try {
        const q = P.PROTOCOL.find((p) => p.key === remaining[0]).question;
        const again = await ai(ctx, 'text', 'conversation', () => ask(`Your previous draft did not ask the required next question. You must now ask about "${remaining[0]}" ("${q}") and set "asked" to "${remaining[0]}". Do not finish yet.`));
        merge(again.data);
        remaining = remainingItems(state);
        if (valid(again.data, remaining)) { g = again.data; model = again.model; }
      } catch { /* fall through to the protocol wording below */ }
    }

    let reply = g.reply;
    let quick = g.quick_replies;
    if (remaining.length) {
      if (!valid(g, remaining)) {
        // last resort: the exact protocol question, so the conversation can never get stuck
        const item = P.PROTOCOL.find((p) => p.key === remaining[0]);
        reply = `${state.emergency.active && newEmergency ? 'This may be an emergency. Please contact your local emergency services now and do not wait for these questions. When it is safe to answer: ' : ''}${item.question}`;
        quick = [];
        source = 'protocol';
        g = { ...g, asked: item.key };
      }
      if (g.asked === 'danger_check') state.dangerAsks += 1;
      else {
        state.asked[g.asked] = true;
        if (!state.collected.danger_check) state.collected.danger_check = 'unclear';
      }
      state.lastAsked = g.asked;
    } else if (g.ready_for_assessment || g.asked === 'none' || state.followups >= P.MAX_FOLLOWUPS) {
      state.ready = true;
      state.lastAsked = null;
    } else {
      state.followups += 1;
      state.lastAsked = 'followup';
    }
    if (state.turns >= MAX_TURNS) state.ready = true;

    const emergencyNow = state.emergency.active && (newEmergency || (g.emergency && !history.some((m) => m.emergency)));
    const userMsg = await addMessage(user, conv.id, 'user', { text });
    const botMsg = await addMessage(user, conv.id, 'assistant', { text: reply, source, model: source === 'gemini' ? model : null, quick, emergency: emergencyNow || undefined });
    await saveState(user, conv);
    return { messages: [userMsg, botMsg], state: publicState(state, user), emergencyNew: !!emergencyNow };
  });

  // ════ (7) symptom assessment ══════════════════════════════════════
  router.add('POST', '/api/start-yhod/:id/assessment', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const conv = await loadConversation(user, ctx.params.id);
    const state = conv.state;
    if (state.assessmentId && ctx.body.force !== true) {
      try { return { assessment: await loadAssessment(user, state.assessmentId), cached: true }; } catch { /* it was deleted: make a new one */ }
    }
    const messages = await loadMessages(user, conv.id);
    if (!messages.some((m) => m.role === 'user')) throw new HttpError(422, 'NOT_ENOUGH_INFORMATION', 'Please answer at least the first question so YHOD has something to assess.');
    const out = await ai(ctx, 'text', 'assessment', () => generate({
      purpose: 'assessment', models: config.gemini.textModels, system: P.SYMPTOM_SYSTEM,
      input: P.symptomInput({ state, messages: messages.map(say), flags: state.emergency.reasons, imageNotes: state.imageNotes }),
      schema: P.SYMPTOM_SCHEMA, validate: P.checkSymptom, thinking: 'minimal', maxOutputTokens: 6000, hedgeMs: 10000, totalMs: 57000,
    }));
    const result = out.data;
    if (state.emergency.hard && result.seriousness_level !== 'emergency') {
      result.level_from_model = result.seriousness_level;
      result.seriousness_level = 'emergency';
      result.levelRaisedBySafetyRules = true;
    }
    const a = await saveAssessment(user, { kind: 'symptom', conversationId: conv.id, input: { answers: state.collected, safetyFlags: state.emergency.reasons }, result, model: out.model });
    state.assessmentId = a.id;
    state.ready = true;
    conv.status = 'done';
    await saveState(user, conv);
    return { assessment: a, cached: false };
  });

  // ════ (8) image + text analysis  ·  (9) skin concern assessment ═══
  const analyse = (kind) => async (ctx) => {
    const user = ctx.user;
    const b = ctx.body;
    const img = decodeImage(b.image);
    const symptoms = cleanText(b.symptoms, 2000);
    const concern = kind === 'skin' ? (b.concern === 'nail' ? 'nail' : 'skin') : (['swelling', 'injury', 'other', 'skin', 'nail'].includes(b.concern) ? b.concern : 'other');
    let conv = null;
    if (b.conversationId) { try { conv = await loadConversation(user, b.conversationId); } catch { conv = null; } }
    const context = conv ? conversationContext(conv.state) : '';
    const det = detectRedFlags(symptoms);
    // the photo itself is sent to Gemini as real image input
    const out = await ai(ctx, 'image', 'image', () => generate({
      purpose: kind === 'skin' ? 'skin' : 'vision', models: config.gemini.visionModels, system: kind === 'skin' ? P.SKIN_SYSTEM : P.IMAGE_SYSTEM,
      input: [{ type: 'text', text: P.imageInputText({ symptoms, concern, context }) }, { type: 'image', data: img.base64, mime_type: img.mime }],
      schema: P.IMAGE_SCHEMA, validate: P.checkImage, thinking: 'low', maxOutputTokens: 6000, hedgeMs: 12000, totalMs: 57000,
    }));
    const result = out.data;
    if (det.emergency && result.seriousness_level !== 'emergency') {
      result.level_from_model = result.seriousness_level;
      result.seriousness_level = 'emergency';
      result.levelRaisedBySafetyRules = true;
      result.safetyFlags = det.flags.map((f) => f.label);
    }
    let imageId = null;
    if (b.saveImage === true) { // stored only with the person's explicit consent, encrypted
      imageId = newId();
      await db.run('INSERT INTO images (id, user_id, mime, bytes_enc, size, created_at) VALUES (?, ?, ?, ?, ?, ?)', imageId, user.id, img.mime, encryptBytes(img.buf, user.id), img.buf.length, nowIso());
    }
    const a = await saveAssessment(user, {
      kind: kind === 'skin' ? 'skin' : 'image', conversationId: conv?.id || null, imageId,
      input: { symptoms, concern: P.CONCERN_TYPES[concern], image: { mime: img.mime, width: img.width, height: img.height, bytes: img.buf.length, saved: !!imageId } },
      result, model: out.model,
    });
    if (conv && conv.status === 'open') {
      conv.state.imageNotes.push(`Photo (${P.CONCERN_TYPES[concern]}; quality ${result.image_quality}). Visible: ${result.what_i_can_see.join('; ')}. Possible explanations mentioned: ${result.possible_explanations.map((e) => e.name).join(', ')}. Seriousness: ${result.seriousness_level}.`.slice(0, 900));
      conv.state.imageNotes = conv.state.imageNotes.slice(-3);
      await saveState(user, conv);
    }
    return { assessment: a, emergency: result.seriousness_level === 'emergency' ? { active: true, reasons: result.safetyFlags || [], steps: EMERGENCY_STEPS, numbers: emergencyNumbers(user.tz) } : null };
  };
  const imageBody = Math.ceil(config.limits.maxImageBytes / 3) * 4 + 96 * 1024;
  router.add('POST', '/api/analyze/image', { auth: true, bodyLimit: imageBody }, analyse('image'));
  router.add('POST', '/api/analyze/skin', { auth: true, bodyLimit: imageBody }, analyse('skin'));

  // ════ (10) treatment information ══════════════════════════════════
  router.add('POST', '/api/treatment', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const a = await loadAssessment(user, ctx.body.assessmentId);
    const d = {
      age: cleanText(ctx.body.age, 40), allergies: cleanText(ctx.body.allergies, 300), conditions: cleanText(ctx.body.conditions, 300),
      medicines: cleanText(ctx.body.medicines, 300), other: cleanText(ctx.body.other, 300), question: cleanText(ctx.body.question, 500),
    };
    const r = a.result;
    const lines = [
      `PREVIOUS YHOD ASSESSMENT (${a.kind === 'symptom' ? 'from a symptom conversation' : 'from a photo and written description'}):`,
      r.summary ? `- What the person reported: ${r.summary}` : null,
      a.input?.symptoms ? `- What the person wrote: ${a.input.symptoms}` : null,
      r.what_i_can_see ? `- What was visible in the photo: ${r.what_i_can_see.join('; ')}` : null,
      `- Possible explanations (not confirmed): ${r.possible_explanations.map((e) => e.name).join('; ')}`,
      `- Seriousness: ${r.seriousness_level}. ${r.seriousness}`,
      `- Suggested professional: ${r.which_doctor}`,
      '',
      'PERSONAL DETAILS SUPPLIED BY THE PERSON (empty means not supplied):',
      `- Age: ${d.age || a.input?.answers?.age || ''}`,
      `- Allergies: ${d.allergies}`,
      `- Health conditions: ${d.conditions || a.input?.answers?.conditions || ''}`,
      `- Current medicines: ${d.medicines || a.input?.answers?.medicines || ''}`,
      `- Anything else (for example pregnancy or breastfeeding): ${d.other}`,
      '',
      `THE PERSON'S QUESTION: ${d.question || '(none — give the general information)'}`,
    ].filter((x) => x !== null).join('\n');
    const out = await ai(ctx, 'text', 'treatment', () => generate({
      purpose: 'treatment', models: config.gemini.textModels, system: P.TREATMENT_SYSTEM, input: lines,
      schema: P.TREATMENT_SCHEMA, validate: P.checkTreatment, thinking: 'minimal', maxOutputTokens: 5000, hedgeMs: 10000, totalMs: 57000,
    }));
    const treatment = { ...out.data, details: d, model: out.model, generatedAt: nowIso() };
    await db.run('UPDATE assessments SET treatment_enc = ? WHERE id = ? AND user_id = ?', encJson(treatment, user.id), a.id, user.id);
    return { treatment, disclaimer: MEDICINE_DISCLAIMER };
  });

  // ── saved assessments and consented photos (owner only) ───────────
  router.add('GET', '/api/assessments/:id', { auth: true }, async (ctx) => ({ assessment: await loadAssessment(ctx.user, ctx.params.id) }));

  router.add('DELETE', '/api/assessments/:id', { auth: true }, async (ctx) => {
    const a = await db.get('SELECT image_id FROM assessments WHERE id = ? AND user_id = ?', String(ctx.params.id), ctx.user.id);
    if (!a) return { deleted: false };
    await db.batch([
      ['DELETE FROM assessments WHERE id = ? AND user_id = ?', String(ctx.params.id), ctx.user.id],
      a.image_id && ['DELETE FROM images WHERE id = ? AND user_id = ?', a.image_id, ctx.user.id],
    ]);
    return { deleted: true };
  });

  router.add('GET', '/api/images/:id', { auth: true }, async (ctx) => {
    const row = await db.get('SELECT mime, bytes_enc FROM images WHERE id = ? AND user_id = ?', String(ctx.params.id), ctx.user.id);
    if (!row) throw new HttpError(404, 'NO_IMAGE', 'That photo was not found.');
    const buf = decryptBytes(row.bytes_enc, ctx.user.id);
    ctx.sendBinary(buf, row.mime, { 'Content-Disposition': 'inline; filename="yhod-photo"', 'Cache-Control': 'private, no-store' });
  });

  router.add('DELETE', '/api/images/:id', { auth: true }, async (ctx) => {
    const r = await db.run('DELETE FROM images WHERE id = ? AND user_id = ?', String(ctx.params.id), ctx.user.id);
    await db.run('UPDATE assessments SET image_id = NULL WHERE image_id = ? AND user_id = ?', String(ctx.params.id), ctx.user.id);
    return { deleted: Number(r.changes) > 0 };
  });

  // ════ voice assistant: text conversation ══════════════════════════
  async function assistantConversation(user) {
    const row = await db.get("SELECT id FROM conversations WHERE user_id = ? AND kind = 'assistant' ORDER BY created_at DESC LIMIT 1", user.id);
    if (row) return row.id;
    const id = newId();
    const now = nowIso();
    await db.run('INSERT INTO conversations (id, user_id, kind, state_enc, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)', id, user.id, 'assistant', encJson({}, user.id), 'open', now, now);
    return id;
  }

  router.add('GET', '/api/assistant/history', { auth: true }, async (ctx) => {
    const row = await db.get("SELECT id FROM conversations WHERE user_id = ? AND kind = 'assistant' ORDER BY created_at DESC LIMIT 1", ctx.user.id);
    return { messages: row ? await loadMessages(ctx.user, row.id, 40) : [] };
  });

  router.add('DELETE', '/api/assistant/history', { auth: true }, async (ctx) => {
    await db.batch([
      ["DELETE FROM messages WHERE user_id = ? AND conversation_id IN (SELECT id FROM conversations WHERE user_id = ? AND kind = 'assistant')", ctx.user.id, ctx.user.id],
      ["DELETE FROM conversations WHERE user_id = ? AND kind = 'assistant'", ctx.user.id],
    ]);
    return { ok: true };
  });

  router.add('POST', '/api/assistant/chat', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const text = cleanText(ctx.body.text, 1000);
    if (!text) throw new HttpError(422, 'EMPTY_MESSAGE', 'Please type or say something first.');
    const convId = await assistantConversation(user);
    const history = await loadMessages(user, convId, 10);
    const det = detectRedFlags(text);
    const input = [
      "THE PERSON'S YHOD RECORDS", await assistantContext(user), '',
      `SAFETY FLAGS FROM THE APP: ${det.flags.length ? det.flags.map((f) => f.label).join('; ') : 'none'}`, '',
      'CONVERSATION SO FAR (the last PERSON line is the latest message)',
      P.transcriptText([...history.map(say), { role: 'user', content: text }], 6000),
    ].join('\n');
    const out = await ai(ctx, 'text', 'assistant', () => generate({
      purpose: 'assistant', models: config.gemini.fastModels, system: P.ASSISTANT_SYSTEM, input,
      schema: P.ASSISTANT_SCHEMA, validate: P.checkAssistant, thinking: 'minimal', maxOutputTokens: 1200, hedgeMs: 4500, totalMs: 35000,
    }));
    const emergency = out.data.emergency || det.emergency;
    const userMsg = await addMessage(user, convId, 'user', { text });
    const botMsg = await addMessage(user, convId, 'assistant', { text: out.data.reply, source: 'gemini', model: out.model, emergency: emergency || undefined, suggestStartYhod: out.data.suggest_start_yhod || undefined });
    // keep the assistant history short
    await db.run('DELETE FROM messages WHERE conversation_id = ? AND user_id = ? AND seq <= (SELECT MAX(seq) FROM messages WHERE conversation_id = ?) - 60', convId, user.id, convId);
    return { messages: [userMsg, botMsg], emergency: emergency ? { active: true, reasons: det.flags.map((f) => f.label), steps: EMERGENCY_STEPS, numbers: emergencyNumbers(user.tz) } : null };
  });

  // ════ microphone input: Gemini turns the recording into text ══════
  router.add('POST', '/api/transcribe', { auth: true, bodyLimit: Math.ceil(config.limits.maxAudioBytes / 3) * 4 + 16 * 1024 }, async (ctx) => {
    const wav = decodeWav(ctx.body.audio);
    const out = await ai(ctx, 'transcribe', 'transcribe', () => generate({
      purpose: 'transcription', models: config.gemini.fastModels, system: P.TRANSCRIBE_SYSTEM,
      input: [{ type: 'text', text: 'Transcribe this recording. If there is no clear speech, set speech_detected to false and leave transcript empty.' }, { type: 'audio', data: wav.base64, mime_type: 'audio/wav' }],
      schema: P.TRANSCRIBE_SCHEMA, validate: P.checkTranscript, thinking: 'minimal', maxOutputTokens: 1200, hedgeMs: 6000, totalMs: 35000,
    }));
    return { transcript: out.data.transcript, speechDetected: out.data.speech_detected, seconds: Math.round(wav.seconds * 10) / 10, model: out.model };
  });
}

/** One stored assistant message of the signed-in person (used by the voice route). */
export async function findAssistantMessage(user, id) {
  const m = await db.get("SELECT m.content_enc, c.kind, c.state_enc FROM messages m JOIN conversations c ON c.id = m.conversation_id WHERE m.id = ? AND m.user_id = ? AND m.role = 'assistant'", String(id), user.id);
  if (!m) throw new HttpError(404, 'NO_MESSAGE', 'That message was not found.');
  let nameGiven = '';
  if (m.kind === 'start_yhod') { try { nameGiven = String((decJson(m.state_enc, user.id) || {}).collected?.name || ''); } catch { nameGiven = ''; } }
  return { ...(decJson(m.content_enc, user.id) || {}), kind: m.kind, nameGiven };
}
