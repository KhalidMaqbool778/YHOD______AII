// YHOD — welcome, daily check-in, Gemini daily analysis, dashboard, history comparison, records.
import { db, nowIso } from './db.js';
import { config } from './config.js';
import { HttpError } from './httpx.js';
import { encJson, decJson, newId, sha256 } from './security.js';
import { generate } from './gemini.js';
import { ai, cacheGet, cacheSet, firstName, maxUrgency } from './aihelp.js';
import * as P from './prompts.js';
import { todayFor, isDate, addDays, daysBetween, userTargets, metricsFromAnswers, loadCheckin, checkinDates, buildDashboard, recordVisit, welcomeFor, loadCheckinsBetween } from './health.js';
import { normaliseAnswers, TOTAL_QUESTIONS } from '../shared/questions.js';
import { checkinSafetyNotices } from '../shared/safety.js';

const answersHash = (answers) => sha256(JSON.stringify(answers));
const show = (v, unit = '') => (v === null || v === undefined ? 'not recorded' : `${v}${unit}`);

async function noteBasis(user, w) {
  const last = w.stats.lastCheckin ? await db.get('SELECT updated_at FROM checkins WHERE user_id = ? AND date = ?', user.id, w.stats.lastCheckin) : null;
  return sha256(JSON.stringify([user.name, w.type, w.stats.today, w.stats.totalCheckins, w.stats.checkinStreak, w.stats.lastCheckin, w.stats.todayCheckinDone, last?.updated_at || null, userTargets(user)]));
}

async function noteInput(user, w) {
  const s = w.stats;
  const t = userTargets(user);
  const kind = { first: 'first-time visitor', daily: 'regular returning visitor', away: `back after ${s.daysSinceLastActivity} days away` }[w.type];
  const out = [
    `WELCOME GREETING SHOWN ABOVE YOUR NOTE: "${w.message}"`,
    `KIND OF VISIT: ${kind}`,
    `PERSON'S FIRST NAME: ${firstName(user)}`,
    `TODAY (their local date): ${s.today}`,
    `VISITS: ${s.visitDays} different day(s) in total; visiting ${s.visitStreak} day(s) in a row; first visit ${s.firstVisit}.`,
    `DAILY CHECK-INS: ${s.totalCheckins} completed in total; current streak ${s.checkinStreak} day(s); today's check-in completed: ${s.todayCheckinDone ? 'yes' : 'no'}.`,
  ];
  if (s.lastCheckin) {
    const c = await loadCheckin(user, s.lastCheckin);
    const m = c.metrics;
    const ago = daysBetween(s.lastCheckin, s.today);
    out.push(`MOST RECENT CHECK-IN (${s.lastCheckin}, ${ago === 0 ? 'today' : ago === 1 ? 'yesterday' : ago + ' days ago'}; ${m.answered} of ${TOTAL_QUESTIONS} questions answered): water ${show(m.water)} of ${t.water} glasses; sleep ${show(m.sleepHours, ' h')} of ${t.sleep} h; walking and exercise ${show(m.activeMinutes, ' min')} of ${t.activity} min; steps ${show(m.steps)} of ${t.steps}; mood ${show(m.mood)}; symptoms reported: ${m.symptoms.length ? m.symptoms.join(', ') : 'none'}.`);
  } else {
    out.push('MOST RECENT CHECK-IN: none yet — they have never completed the daily check-in.');
  }
  return out.join('\n');
}

async function saveCheckin(user, date, answers) {
  const now = nowIso();
  const metrics = metricsFromAnswers(answers);
  const hash = answersHash(answers);
  const existing = await db.get('SELECT id, feedback_enc, feedback_model FROM checkins WHERE user_id = ? AND date = ?', user.id, date);
  if (existing) {
    let keep = false;
    try { keep = decJson(existing.feedback_enc, user.id)?.answersHash === hash; } catch { keep = false; }
    await db.run('UPDATE checkins SET answers_enc = ?, metrics_enc = ?, answered = ?, updated_at = ?, feedback_enc = ?, feedback_model = ? WHERE id = ?',
      encJson(answers, user.id), encJson(metrics, user.id), metrics.answered, now, keep ? existing.feedback_enc : null, keep ? existing.feedback_model : null, existing.id);
  } else {
    // "ON CONFLICT": if the same day is saved twice at the same moment, the second save updates instead of failing.
    await db.run(`INSERT INTO checkins (id, user_id, date, answers_enc, metrics_enc, answered, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id, date) DO UPDATE SET answers_enc = excluded.answers_enc, metrics_enc = excluded.metrics_enc, answered = excluded.answered, updated_at = excluded.updated_at`,
      newId(), user.id, date, encJson(answers, user.id), encJson(metrics, user.id), metrics.answered, now, now);
  }
  return metrics;
}

function requireDate(ctx) {
  const date = ctx.params.date;
  if (!isDate(date)) throw new HttpError(400, 'BAD_DATE', 'That date is not valid.');
  return date;
}

async function compareDays(user) {
  const dates = (await checkinDates(user)).slice(-14);
  const saved = dates.length ? await loadCheckinsBetween(user, dates[0], dates[dates.length - 1]) : new Map();
  return dates.map((d) => {
    const c = saved.get(d);
    const m = c.metrics;
    return { date: d, updatedAt: c.updatedAt, water: m.water, fruitVeg: m.fruitVeg, sugaryDrinks: m.sugaryDrinks, activeMinutes: m.activeMinutes, steps: m.steps, sittingHours: m.sittingHours, sleepHours: m.sleepHours, sleepQuality: m.sleepQuality, screenMinutes: m.screenMinutes, mood: m.mood, stress: m.stress, energy: m.energy, symptoms: m.symptoms };
  });
}
const compareBasis = (user, days) => sha256(JSON.stringify([days.map((d) => [d.date, d.updatedAt]), userTargets(user)]));

export function registerCheckinRoutes(router) {
  // ── (1) welcome message generation ────────────────────────────────
  // Records this visit, then picks the greeting from the visit and check-in dates actually saved.
  router.add('POST', '/api/welcome', { auth: true }, async (ctx) => {
    await recordVisit(ctx.user);
    const w = await welcomeFor(ctx.user);
    const cached = await cacheGet(ctx.user, 'welcome_note');
    return { ...w, note: cached && cached.basis === await noteBasis(ctx.user, w) ? cached.value : null };
  });

  // The short personal note under the greeting is written by Gemini from the person's real records.
  router.add('POST', '/api/welcome/note', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const w = await welcomeFor(user);
    const basis = await noteBasis(user, w);
    const cached = await cacheGet(user, 'welcome_note');
    if (cached && cached.basis === basis && ctx.body.force !== true) return { note: cached.value, cached: true };
    const input = await noteInput(user, w);
    const out = await ai(ctx, 'text', 'welcome_note', () => generate({
      purpose: 'welcome', models: config.gemini.fastModels, system: P.NOTE_SYSTEM, input,
      schema: P.NOTE_SCHEMA, validate: P.checkNote, thinking: 'minimal', maxOutputTokens: 600, hedgeMs: 5000, totalMs: 25000,
    }));
    const value = { text: out.data.note, model: out.model, generatedAt: nowIso() };
    await cacheSet(user, 'welcome_note', basis, value);
    return { note: value, cached: false };
  });

  // ── daily check-in: load and save ─────────────────────────────────
  router.add('GET', '/api/checkins/today', { auth: true }, async (ctx) => {
    const date = todayFor(ctx.user);
    const c = await loadCheckin(ctx.user, date);
    return { date, checkin: c ? { answers: c.answers, answered: c.answered, updatedAt: c.updatedAt, feedback: c.feedback } : null };
  });

  router.add('PUT', '/api/checkins/today', { auth: true }, async (ctx) => {
    const { clean, errors } = normaliseAnswers(ctx.body.answers);
    if (Object.keys(errors).length) throw new HttpError(422, 'INVALID_ANSWERS', 'Some answers need another look. Nothing was lost.', { fields: errors });
    if (!Object.keys(clean).length) throw new HttpError(422, 'EMPTY_FORM', 'Please fill in at least one sentence before submitting your check-in.');
    const date = todayFor(ctx.user);
    const metrics = await saveCheckin(ctx.user, date, clean);
    return { saved: true, date, answered: metrics.answered, notices: checkinSafetyNotices(clean), dashboard: await buildDashboard(ctx.user, date) };
  });

  // ── (3) daily form analysis — a real Gemini request on the saved answers ──
  router.add('POST', '/api/checkins/:date/analysis', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const date = requireDate(ctx);
    const c = await loadCheckin(user, date);
    if (!c) throw new HttpError(404, 'NO_CHECKIN', 'There is no saved check-in for that day.');
    const hash = answersHash(c.answers);
    if (c.feedback && c.feedback.answersHash === hash && ctx.body.force !== true) {
      return { feedback: c.feedback, cached: true, dashboard: await buildDashboard(user, date) };
    }
    const notices = checkinSafetyNotices(c.answers);
    const recent = [];
    const before = await loadCheckinsBetween(user, addDays(date, -6), addDays(date, -1)); // the six days before, in one request
    for (let i = 6; i >= 1; i--) {
      const d = addDays(date, -i);
      const r = before.get(d);
      if (r) recent.push({ date: d, water: r.metrics.water, sleepHours: r.metrics.sleepHours, activeMinutes: r.metrics.activeMinutes, steps: r.metrics.steps, mood: r.metrics.mood });
    }
    const out = await ai(ctx, 'text', 'analysis', () => generate({
      purpose: 'analysis', models: config.gemini.fastModels, system: P.DAILY_SYSTEM,
      input: P.dailyInput({ firstName: firstName(user), targets: userTargets(user), answers: c.answers, notices, recent, date }),
      schema: P.DAILY_SCHEMA, validate: P.checkDaily, thinking: 'low', maxOutputTokens: 4096, hedgeMs: 8000, totalMs: 56000,
    }));
    // Fixed safety rules can only raise the urgency Gemini chose, never lower it.
    let urgency = out.data.urgency;
    for (const n of notices) urgency = maxUrgency(urgency, { emergency: 'emergency', urgent: 'urgent', care: 'monitor' }[n.level]);
    const raised = urgency !== out.data.urgency;
    const top = notices.find((n) => n.level === 'emergency') || notices.find((n) => n.level === 'urgent');
    const feedback = {
      ...out.data,
      urgency,
      urgent_advice: out.data.urgent_advice || (raised && top ? top.text : ''),
      urgencyRaisedBySafetyRules: raised,
      notices,
      model: out.model,
      generatedAt: nowIso(),
      answersHash: hash,
      answered: c.answered,
    };
    await db.run('UPDATE checkins SET feedback_enc = ?, feedback_model = ? WHERE user_id = ? AND date = ?', encJson(feedback, user.id), out.model, user.id, date);
    return { feedback, cached: false, dashboard: await buildDashboard(user, date) };
  });

  // ── (4) daily feedback — the saved Gemini feedback for a day ───────
  router.add('GET', '/api/checkins/:date/feedback', { auth: true }, async (ctx) => {
    const c = await loadCheckin(ctx.user, requireDate(ctx));
    if (!c) throw new HttpError(404, 'NO_CHECKIN', 'There is no saved check-in for that day.');
    return { date: c.date, feedback: c.feedback, stale: !!c.feedback && c.feedback.answersHash !== answersHash(c.answers) };
  });

  router.add('GET', '/api/checkins/:date', { auth: true }, async (ctx) => {
    const c = await loadCheckin(ctx.user, requireDate(ctx));
    if (!c) throw new HttpError(404, 'NO_CHECKIN', 'There is no saved check-in for that day.');
    return { checkin: { date: c.date, answers: c.answers, answered: c.answered, metrics: c.metrics, feedback: c.feedback, createdAt: c.createdAt, updatedAt: c.updatedAt } };
  });

  router.add('DELETE', '/api/checkins/:date', { auth: true }, async (ctx) => {
    const r = await db.run('DELETE FROM checkins WHERE user_id = ? AND date = ?', ctx.user.id, requireDate(ctx));
    await db.run("DELETE FROM ai_cache WHERE user_id = ? AND kind IN ('compare', 'welcome_note')", ctx.user.id);
    return { deleted: Number(r.changes) > 0 };
  });

  // ── dashboard: every number comes from the saved check-ins ────────
  router.add('GET', '/api/dashboard', { auth: true }, async (ctx) => {
    const date = ctx.query.get('date');
    const [dash, days, cached] = await Promise.all([buildDashboard(ctx.user, date), compareDays(ctx.user), cacheGet(ctx.user, 'compare')]);
    return { dashboard: dash, comparison: cached && days.length >= 2 && cached.basis === compareBasis(ctx.user, days) ? cached.value : null, canCompare: days.length >= 2 };
  });

  // ── (5) health history comparison — Gemini compares the saved days ─
  router.add('POST', '/api/history/compare', { auth: true }, async (ctx) => {
    const user = ctx.user;
    const days = await compareDays(user);
    if (days.length < 2) throw new HttpError(422, 'NOT_ENOUGH_HISTORY', 'YHOD needs at least two days of check-ins to compare. Come back tomorrow and complete your check-in.');
    const basis = compareBasis(user, days);
    const cached = await cacheGet(user, 'compare');
    if (cached && cached.basis === basis && ctx.body.force !== true) return { comparison: cached.value, cached: true };
    const out = await ai(ctx, 'text', 'compare', () => generate({
      purpose: 'comparison', models: config.gemini.fastModels, system: P.COMPARE_SYSTEM,
      input: P.compareInput({ firstName: firstName(user), targets: userTargets(user), days }),
      schema: P.COMPARE_SCHEMA, validate: P.checkCompare, thinking: 'low', maxOutputTokens: 3000, hedgeMs: 8000, totalMs: 56000,
    }));
    const value = { ...out.data, model: out.model, generatedAt: nowIso(), from: days[0].date, to: days[days.length - 1].date, days: days.length };
    await cacheSet(user, 'compare', basis, value);
    return { comparison: value, cached: false };
  });

  // ── records overview ──────────────────────────────────────────────
  router.add('GET', '/api/records', { auth: true }, async (ctx) => {
    const u = ctx.user;
    const dec = (v) => { try { return decJson(v, u.id); } catch { return null; } };
    const checkins = (await db.all('SELECT date, answers_enc, feedback_enc, answered, updated_at FROM checkins WHERE user_id = ? ORDER BY date DESC LIMIT 400', u.id)).map((r) => {
      const m = metricsFromAnswers(dec(r.answers_enc) || {});
      const f = dec(r.feedback_enc);
      return { date: r.date, answered: r.answered, updatedAt: r.updated_at, hasFeedback: !!f, urgency: f?.urgency || null, water: m.water, sleepHours: m.sleepHours, activeMinutes: m.activeMinutes, mood: m.mood, symptoms: m.symptoms.length };
    });
    const assessments = (await db.all('SELECT id, kind, image_id, result_enc, input_enc, treatment_enc, model, created_at FROM assessments WHERE user_id = ? ORDER BY created_at DESC LIMIT 200', u.id)).map((r) => {
      const res = dec(r.result_enc) || {};
      const inp = dec(r.input_enc) || {};
      return {
        id: r.id, kind: r.kind, createdAt: r.created_at, level: res.seriousness_level || null, model: r.model, imageId: r.image_id, hasTreatment: !!r.treatment_enc,
        title: (res.possible_explanations || []).slice(0, 2).map((e) => e.name).join(' · ') || 'Assessment',
        about: String(inp.symptoms || res.summary || '').slice(0, 160),
      };
    });
    const images = (await db.all('SELECT id, mime, size, created_at FROM images WHERE user_id = ? ORDER BY created_at DESC LIMIT 200', u.id)).map((r) => ({ id: r.id, mime: r.mime, size: r.size, createdAt: r.created_at }));
    const visits = await db.all('SELECT date, count FROM visits WHERE user_id = ? ORDER BY date DESC LIMIT 400', u.id);
    return { checkins, assessments, images, visits };
  });
}
