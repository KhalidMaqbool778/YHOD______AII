// YHOD — cryptography helpers: password hashing, session tokens and
// AES-256-GCM encryption of health data at rest.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { config } from './config.js';
import { db } from './db.js';

const scrypt = promisify(crypto.scrypt);
const SCRYPT = { N: 1 << 15, r: 8, p: 1 };
const MAXMEM = 128 * 1024 * 1024;

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(String(password).normalize('NFKC'), salt, 64, { ...SCRYPT, maxmem: MAXMEM });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${hash.toString('base64')}`;
}

export async function verifyPassword(password, stored) {
  try {
    const [alg, N, r, p, saltB64, hashB64] = String(stored).split('$');
    if (alg !== 'scrypt') return false;
    const expected = Buffer.from(hashB64, 'base64');
    const actual = await scrypt(String(password).normalize('NFKC'), Buffer.from(saltB64, 'base64'), expected.length, { N: +N, r: +r, p: +p, maxmem: MAXMEM });
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

// A real hash to compare against when the e-mail is unknown, so that sign-in
// takes the same time whether or not an account exists.
let dummyHash = null;
export async function burnPasswordTime(password) {
  if (!dummyHash) dummyHash = await hashPassword(crypto.randomBytes(12).toString('hex'));
  await verifyPassword(password, dummyHash);
}

export const newId = () => crypto.randomUUID();
export const newToken = () => crypto.randomBytes(32).toString('base64url');
export const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

// ── encryption at rest ──────────────────────────────────────────────
// The 32-byte key comes from, in this order:
//   1. YHOD_DATA_KEY (an environment variable): the key is kept apart from the data — the strongest choice
//   2. with storage in a file:        data/secret.key, created on first start
//      with a remote database:        a row of that database, created on first use, so that every function
//                                     instance works with the same key
let KEY = null;
let keyFrom = '';
function parseKey(text, what) {
  const t = String(text).trim();
  const k = /^[0-9a-f]{64}$/i.test(t) ? Buffer.from(t, 'hex') : Buffer.from(t, 'base64');
  if (k.length !== 32) throw new Error(`${what} must be 32 bytes (base64 or hex).`);
  return k;
}
/** Load (or, the very first time, create) the key. Call once the database is open; calling again is harmless. */
export async function initDataKey() {
  if (KEY) return keyFrom;
  if (config.dataKey) {
    KEY = parseKey(config.dataKey, 'YHOD_DATA_KEY');
    keyFrom = 'environment';
  } else if (db.kind === 'remote') {
    // "INSERT OR IGNORE" then read back: if two instances start at the same moment, both end up with one key.
    await db.run("INSERT OR IGNORE INTO app_meta (key, value) VALUES ('data_key', ?)", crypto.randomBytes(32).toString('base64'));
    KEY = parseKey((await db.get("SELECT value FROM app_meta WHERE key = 'data_key'")).value, 'The data key stored in the database');
    keyFrom = 'database';
  } else {
    const file = path.join(config.dataDir, 'secret.key');
    if (fs.existsSync(file)) {
      KEY = parseKey(fs.readFileSync(file, 'utf8'), 'data/secret.key');
    } else {
      fs.mkdirSync(config.dataDir, { recursive: true, mode: 0o700 });
      KEY = crypto.randomBytes(32);
      fs.writeFileSync(file, KEY.toString('base64') + '\n', { mode: 0o600 });
    }
    keyFrom = 'file';
  }
  return keyFrom;
}
/** Where the key came from: 'environment', 'database' or 'file' ('' before it is loaded). Never the key itself. */
export const dataKeySource = () => keyFrom;
function dataKey() {
  if (!KEY) throw new Error('The data key is not loaded yet (await initDataKey() first).');
  return KEY;
}

/** Encrypt bytes. `aad` (the owner's user id) binds the ciphertext to its owner. */
export function encryptBytes(buf, aad) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', dataKey(), iv);
  if (aad) c.setAAD(Buffer.from(String(aad)));
  const ct = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]);
}

export function decryptBytes(payload, aad) {
  const b = Buffer.from(payload);
  const d = crypto.createDecipheriv('aes-256-gcm', dataKey(), b.subarray(0, 12));
  if (aad) d.setAAD(Buffer.from(String(aad)));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]);
}

export const encryptText = (text, aad) => 'v1.' + encryptBytes(Buffer.from(String(text), 'utf8'), aad).toString('base64');
export function decryptText(payload, aad) {
  const s = String(payload);
  if (!s.startsWith('v1.')) throw new Error('Unknown ciphertext format');
  return decryptBytes(Buffer.from(s.slice(3), 'base64'), aad).toString('utf8');
}
export const encJson = (obj, aad) => encryptText(JSON.stringify(obj), aad);
export const decJson = (payload, aad) => (payload ? JSON.parse(decryptText(payload, aad)) : null);

